#define WIN32_LEAN_AND_MEAN 1

typedef unsigned char BYTE; typedef unsigned short WORD; typedef unsigned int UINT; typedef unsigned long DWORD; typedef long LONG; typedef unsigned long ULONG; typedef unsigned long long ULONGLONG; typedef long long LONGLONG; typedef unsigned long long ULONG_PTR; typedef long long LONG_PTR; typedef int BOOL; typedef void* HANDLE; typedef void* HMODULE; typedef void* HINSTANCE; typedef const void* LPCVOID; typedef void* LPVOID; typedef unsigned short WCHAR; typedef WCHAR* LPWSTR; typedef const WCHAR* LPCWSTR; typedef char CHAR; typedef const CHAR* LPCSTR;
typedef union _LARGE_INTEGER { struct { DWORD LowPart; LONG HighPart; }; LONGLONG QuadPart; } LARGE_INTEGER;
typedef struct _FILETIME { DWORD dwLowDateTime; DWORD dwHighDateTime; } FILETIME;
typedef struct _WIN32_FIND_DATAW { DWORD dwFileAttributes; FILETIME ftCreationTime,ftLastAccessTime,ftLastWriteTime; DWORD nFileSizeHigh,nFileSizeLow,dwReserved0,dwReserved1; WCHAR cFileName[260]; WCHAR cAlternateFileName[14]; DWORD dwFileType,dwCreatorType; WORD wFinderFlags; } WIN32_FIND_DATAW;
typedef struct _STARTUPINFOW { DWORD cb; LPWSTR lpReserved; LPWSTR lpDesktop; LPWSTR lpTitle; DWORD dwX,dwY,dwXSize,dwYSize,dwXCountChars,dwYCountChars,dwFillAttribute,dwFlags; WORD wShowWindow,cbReserved2; BYTE* lpReserved2; HANDLE hStdInput,hStdOutput,hStdError; } STARTUPINFOW;
typedef struct _PROCESS_INFORMATION { HANDLE hProcess,hThread; DWORD dwProcessId,dwThreadId; } PROCESS_INFORMATION;
typedef ULONG_PTR HCRYPTPROV; typedef ULONG_PTR HCRYPTHASH;

#define WINAPI __stdcall
#define NULL ((void*)0)
#define TRUE 1
#define FALSE 0
#define INVALID_HANDLE_VALUE ((HANDLE)(LONG_PTR)-1)
#define GENERIC_READ 0x80000000UL
#define GENERIC_WRITE 0x40000000UL
#define FILE_SHARE_READ 0x1
#define FILE_SHARE_WRITE 0x2
#define OPEN_EXISTING 3
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_NORMAL 0x80
#define FILE_BEGIN 0
#define CREATE_NO_WINDOW 0x08000000
#define STARTF_USESHOWWINDOW 0x00000001
#define SW_HIDE 0
#define INFINITE 0xFFFFFFFFUL
#define MOVEFILE_REPLACE_EXISTING 0x00000001
#define MOVEFILE_WRITE_THROUGH 0x00000008
#define CP_UTF8 65001
#define PROV_RSA_AES 24
#define CRYPT_VERIFYCONTEXT 0xF0000000UL
#define CALG_SHA_256 0x0000800cUL
#define HP_HASHVAL 0x0002
#define FILE_FLAG_WRITE_THROUGH 0x80000000UL

__declspec(dllimport) HANDLE WINAPI CreateFileW(LPCWSTR,DWORD,DWORD,LPVOID,DWORD,DWORD,HANDLE);
__declspec(dllimport) BOOL WINAPI ReadFile(HANDLE,LPVOID,DWORD,DWORD*,LPVOID);
__declspec(dllimport) BOOL WINAPI WriteFile(HANDLE,LPCVOID,DWORD,DWORD*,LPVOID);
__declspec(dllimport) BOOL WINAPI SetFilePointerEx(HANDLE,LARGE_INTEGER,LARGE_INTEGER*,DWORD);
__declspec(dllimport) BOOL WINAPI GetFileSizeEx(HANDLE,LARGE_INTEGER*);
__declspec(dllimport) BOOL WINAPI SetEndOfFile(HANDLE);
__declspec(dllimport) BOOL WINAPI FlushFileBuffers(HANDLE);
__declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
__declspec(dllimport) BOOL WINAPI CreateDirectoryW(LPCWSTR,LPVOID);
__declspec(dllimport) BOOL WINAPI RemoveDirectoryW(LPCWSTR);
__declspec(dllimport) BOOL WINAPI DeleteFileW(LPCWSTR);
__declspec(dllimport) BOOL WINAPI CopyFileW(LPCWSTR,LPCWSTR,BOOL);
__declspec(dllimport) BOOL WINAPI MoveFileExW(LPCWSTR,LPCWSTR,DWORD);
__declspec(dllimport) DWORD WINAPI GetFileAttributesW(LPCWSTR);
__declspec(dllimport) HANDLE WINAPI FindFirstFileW(LPCWSTR,WIN32_FIND_DATAW*);
__declspec(dllimport) BOOL WINAPI FindNextFileW(HANDLE,WIN32_FIND_DATAW*);
__declspec(dllimport) BOOL WINAPI FindClose(HANDLE);
__declspec(dllimport) DWORD WINAPI GetLastError(void);
__declspec(dllimport) DWORD WINAPI GetTempPathW(DWORD,LPWSTR);
__declspec(dllimport) DWORD WINAPI GetCurrentProcessId(void);
__declspec(dllimport) DWORD WINAPI GetModuleFileNameW(HMODULE,LPWSTR,DWORD);
__declspec(dllimport) LPWSTR WINAPI GetCommandLineW(void);
__declspec(dllimport) HANDLE WINAPI GetProcessHeap(void);
__declspec(dllimport) LPVOID WINAPI HeapAlloc(HANDLE,DWORD,ULONG_PTR);
__declspec(dllimport) BOOL WINAPI HeapFree(HANDLE,DWORD,LPVOID);
__declspec(dllimport) BOOL WINAPI CreateProcessW(LPCWSTR,LPWSTR,LPVOID,LPVOID,BOOL,DWORD,LPVOID,LPCWSTR,STARTUPINFOW*,PROCESS_INFORMATION*);
__declspec(dllimport) DWORD WINAPI WaitForSingleObject(HANDLE,DWORD);
__declspec(dllimport) BOOL WINAPI GetExitCodeProcess(HANDLE,DWORD*);
__declspec(dllimport) void WINAPI ExitProcess(UINT);
__declspec(dllimport) int WINAPI WideCharToMultiByte(UINT,DWORD,LPCWSTR,int,CHAR*,int,LPCSTR,BOOL*);

__declspec(dllimport) BOOL WINAPI CryptAcquireContextW(HCRYPTPROV*,LPCWSTR,LPCWSTR,DWORD,DWORD);
__declspec(dllimport) BOOL WINAPI CryptCreateHash(HCRYPTPROV,DWORD,ULONG_PTR,DWORD,HCRYPTHASH*);
__declspec(dllimport) BOOL WINAPI CryptHashData(HCRYPTHASH,const BYTE*,DWORD,DWORD);
__declspec(dllimport) BOOL WINAPI CryptGetHashParam(HCRYPTHASH,DWORD,BYTE*,DWORD*,DWORD);
__declspec(dllimport) BOOL WINAPI CryptDestroyHash(HCRYPTHASH);
__declspec(dllimport) BOOL WINAPI CryptReleaseContext(HCRYPTPROV,DWORD);

void* memset(void* d,int c,ULONG_PTR n){BYTE*p=(BYTE*)d;while(n--)*p++=(BYTE)c;return d;}
void* memcpy(void* d,const void*s,ULONG_PTR n){BYTE*dd=(BYTE*)d;const BYTE*ss=(const BYTE*)s;while(n--)*dd++=*ss++;return d;}
int memcmp(const void*a,const void*b,ULONG_PTR n){const BYTE*x=(const BYTE*)a,*y=(const BYTE*)b;while(n--){if(*x!=*y)return *x<*y?-1:1;x++;y++;}return 0;}

static const WCHAR VERSION[] = L"V0.9.0 CORRECTIF CALIBRATION NON R1";
static const WCHAR MANIFEST_NAME[] = L"ff715342fa4b2d8f";
static const WCHAR MANIFEST_REL[] = L"_data\\5932408047\\rad16\\win10\\manifests\\ff715342fa4b2d8f";
static const WCHAR PACKAGES_REL[] = L"_data\\5932408047\\rad16\\win10\\packages";
static const WCHAR NATIVE_BACKUP_REL[] = L"LE2_FR_CAL_UI_PROBE_UNUSED";
static const WCHAR V090_STATE_REL[] = L"LE2_FR_V0.9.0_STATE.txt";
static const WCHAR V090_MAIN_MANIFEST_REL[] = L"_data\\5932408047\\rad16\\win10\\manifests\\ff715342fa4b2d8f";
static const WCHAR V090_MAIN_PACKAGE_REL[] = L"_data\\5932408047\\rad16\\win10\\packages\\ff715342fa4b2d8f_0";

typedef struct Target { DWORD chunk,record,pi,assetOff,assetSize,local,origPeSize; const char* origPeSha; } Target;
static const Target T[1] = {
 {7,252,0,0,0,0,0,""}
};
static const ULONGLONG REFERENCE_PKG_SIZE[1]={0};
typedef struct BackupState { BYTE magic[8]; ULONGLONG pkgSize[4]; BYTE manifestSha[32]; } BackupState;
static const BYTE BACKUP_MAGIC[8]={'L','E','2','P','R','B','0','1'};

static WCHAR gGame[4096], gReportRoot[4096], gExeDir[4096], gWork[4096], gReport[4096], gZstd[4096];

static ULONG_PTR wlen(LPCWSTR s){ULONG_PTR n=0;while(s&&s[n])n++;return n;}
static void wcopy(LPWSTR d,ULONG_PTR c,LPCWSTR s){ULONG_PTR i=0;if(!c)return;while(s&&s[i]&&i+1<c){d[i]=s[i];i++;}d[i]=0;}
static void wcat(LPWSTR d,ULONG_PTR c,LPCWSTR s){ULONG_PTR i=wlen(d),j=0;while(s&&s[j]&&i+1<c)d[i++]=s[j++];d[i]=0;}
static int weq(LPCWSTR a,LPCWSTR b){ULONG_PTR i=0;if(!a||!b)return 0;while(a[i]&&b[i]){if(a[i]!=b[i])return 0;i++;}return a[i]==b[i];}
static void join(LPWSTR o,ULONG_PTR c,LPCWSTR a,LPCWSTR b){wcopy(o,c,a);ULONG_PTR n=wlen(o);if(n&&o[n-1]!=L'\\')wcat(o,c,L"\\");wcat(o,c,b);}
static void parent(LPWSTR p){ULONG_PTR n=wlen(p);while(n){if(p[n-1]==L'\\'||p[n-1]==L'/'){p[n-1]=0;return;}n--;}p[0]=0;}
static void u64w(ULONGLONG v,LPWSTR o,ULONG_PTR c){WCHAR t[32];int n=0;if(!v){wcopy(o,c,L"0");return;}while(v&&n<31){t[n++]=(WCHAR)(L'0'+(v%10));v/=10;}int k=0;while(n&&k+1<(int)c)o[k++]=t[--n];o[k]=0;}
static void u32w(DWORD v,LPWSTR o,ULONG_PTR c){u64w(v,o,c);}
static int file_exists(LPCWSTR p){DWORD a=GetFileAttributesW(p);return a!=0xFFFFFFFFUL && !(a&0x10);}
static int dir_exists(LPCWSTR p){DWORD a=GetFileAttributesW(p);return a!=0xFFFFFFFFUL && (a&0x10);}
static DWORD rd32(const BYTE*b,DWORD p){return (DWORD)b[p]|((DWORD)b[p+1]<<8)|((DWORD)b[p+2]<<16)|((DWORD)b[p+3]<<24);}
static void wr32(BYTE*b,DWORD p,DWORD v){b[p]=(BYTE)v;b[p+1]=(BYTE)(v>>8);b[p+2]=(BYTE)(v>>16);b[p+3]=(BYTE)(v>>24);}
static int hex_eq(const BYTE* h,const char* s){static const char*x="0123456789abcdef";int i;for(i=0;i<32;i++){if(x[(h[i]>>4)&15]!=s[i*2]||x[h[i]&15]!=s[i*2+1])return 0;}return 1;}
static void hexstr(const BYTE*h,char*out){static const char*x="0123456789abcdef";int i;for(i=0;i<32;i++){out[i*2]=x[(h[i]>>4)&15];out[i*2+1]=x[h[i]&15];}out[64]=0;}

static void log_ascii(const char* s){
 HANDLE h=CreateFileW(gReport,GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL); if(h==INVALID_HANDLE_VALUE)h=CreateFileW(gReport,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL); if(h==INVALID_HANDLE_VALUE)return; LARGE_INTEGER sz,li; if(GetFileSizeEx(h,&sz)){li.QuadPart=sz.QuadPart;SetFilePointerEx(h,li,NULL,FILE_BEGIN);} DWORD n=0;while(s[n])n++;DWORD w;WriteFile(h,s,n,&w,NULL);WriteFile(h,"\r\n",2,&w,NULL);FlushFileBuffers(h);CloseHandle(h);
}
static void log_w(LPCWSTR ws){char* b=(char*)HeapAlloc(GetProcessHeap(),0,65536);if(!b)return;int n=WideCharToMultiByte(CP_UTF8,0,ws,-1,b,65535,NULL,NULL);if(n>0)log_ascii(b);HeapFree(GetProcessHeap(),0,b);}
static void log_num(const char* prefix,ULONGLONG v){WCHAR w[128],n[64];int i=0;while(prefix[i]&&i<60){w[i]=(WCHAR)(BYTE)prefix[i];i++;}w[i]=0;u64w(v,n,64);wcat(w,128,n);log_w(w);}

static int read_exact(HANDLE h,void* dst,DWORD n){BYTE*p=(BYTE*)dst;DWORD d=0,r;while(d<n){if(!ReadFile(h,p+d,n-d,&r,NULL)||!r)return 0;d+=r;}return 1;}
static int write_exact(HANDLE h,const void* src,DWORD n){const BYTE*p=(const BYTE*)src;DWORD d=0,w;while(d<n){if(!WriteFile(h,p+d,n-d,&w,NULL)||!w)return 0;d+=w;}return 1;}
static int seek64(HANDLE h,ULONGLONG o){LARGE_INTEGER li;li.QuadPart=(LONGLONG)o;return SetFilePointerEx(h,li,NULL,FILE_BEGIN);}
static int fsize(LPCWSTR p,ULONGLONG* out){HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);LARGE_INTEGER s;if(h==INVALID_HANDLE_VALUE)return 0;BOOL ok=GetFileSizeEx(h,&s);CloseHandle(h);if(ok)*out=(ULONGLONG)s.QuadPart;return ok?1:0;}
static BYTE* read_all(LPCWSTR p,DWORD* out){ULONGLONG s;if(!fsize(p,&s)||s>0x7fffffffULL)return NULL;HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return NULL;BYTE*b=(BYTE*)HeapAlloc(GetProcessHeap(),0,(ULONG_PTR)s+1);if(!b){CloseHandle(h);return NULL;}if(!read_exact(h,b,(DWORD)s)){HeapFree(GetProcessHeap(),0,b);CloseHandle(h);return NULL;}CloseHandle(h);*out=(DWORD)s;return b;}
static int write_all(LPCWSTR p,const BYTE*b,DWORD n){HANDLE h=CreateFileW(p,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);if(h==INVALID_HANDLE_VALUE)return 0;int ok=write_exact(h,b,n);FlushFileBuffers(h);CloseHandle(h);return ok;}
static BYTE* read_range(LPCWSTR p,ULONGLONG off,DWORD n){HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return NULL;BYTE*b=(BYTE*)HeapAlloc(GetProcessHeap(),0,n?n:1);if(!b){CloseHandle(h);return NULL;}if(!seek64(h,off)||!read_exact(h,b,n)){HeapFree(GetProcessHeap(),0,b);CloseHandle(h);return NULL;}CloseHandle(h);return b;}
static int append_bytes(LPCWSTR p,const BYTE*b,DWORD n,ULONGLONG expectedOff){HANDLE h=CreateFileW(p,GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);if(h==INVALID_HANDLE_VALUE)return 0;LARGE_INTEGER s;if(!GetFileSizeEx(h,&s)||(ULONGLONG)s.QuadPart!=expectedOff||!seek64(h,expectedOff)||!write_exact(h,b,n)){CloseHandle(h);return 0;}FlushFileBuffers(h);CloseHandle(h);return 1;}
static int truncate_file(LPCWSTR p,ULONGLONG n){HANDLE h=CreateFileW(p,GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);if(h==INVALID_HANDLE_VALUE)return 0;if(!seek64(h,n)||!SetEndOfFile(h)){CloseHandle(h);return 0;}FlushFileBuffers(h);CloseHandle(h);return 1;}
static int files_equal(LPCWSTR a,LPCWSTR b){ULONGLONG sa,sb;if(!fsize(a,&sa)||!fsize(b,&sb)||sa!=sb)return 0;HANDLE ha=CreateFileW(a,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL),hb=CreateFileW(b,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(ha==INVALID_HANDLE_VALUE||hb==INVALID_HANDLE_VALUE){if(ha!=INVALID_HANDLE_VALUE)CloseHandle(ha);if(hb!=INVALID_HANDLE_VALUE)CloseHandle(hb);return 0;}BYTE* x=(BYTE*)HeapAlloc(GetProcessHeap(),0,1024*1024),*y=(BYTE*)HeapAlloc(GetProcessHeap(),0,1024*1024);if(!x||!y){if(x)HeapFree(GetProcessHeap(),0,x);if(y)HeapFree(GetProcessHeap(),0,y);CloseHandle(ha);CloseHandle(hb);return 0;}ULONGLONG rem=sa;int ok=1;while(rem){DWORD n=rem>1024*1024?1024*1024:(DWORD)rem;if(!read_exact(ha,x,n)||!read_exact(hb,y,n)||memcmp(x,y,n)){ok=0;break;}rem-=n;}HeapFree(GetProcessHeap(),0,x);HeapFree(GetProcessHeap(),0,y);CloseHandle(ha);CloseHandle(hb);return ok;}
static int tail_equals_file(LPCWSTR pkg,ULONGLONG off,LPCWSTR tail){ULONGLONG ts,ps;if(!fsize(tail,&ts)||!fsize(pkg,&ps)||ps!=off+ts)return 0;HANDLE a=CreateFileW(pkg,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL),b=CreateFileW(tail,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(a==INVALID_HANDLE_VALUE||b==INVALID_HANDLE_VALUE){if(a!=INVALID_HANDLE_VALUE)CloseHandle(a);if(b!=INVALID_HANDLE_VALUE)CloseHandle(b);return 0;}if(!seek64(a,off)){CloseHandle(a);CloseHandle(b);return 0;}BYTE*x=(BYTE*)HeapAlloc(GetProcessHeap(),0,262144),*y=(BYTE*)HeapAlloc(GetProcessHeap(),0,262144);if(!x||!y){if(x)HeapFree(GetProcessHeap(),0,x);if(y)HeapFree(GetProcessHeap(),0,y);CloseHandle(a);CloseHandle(b);return 0;}ULONGLONG rem=ts;int ok=1;while(rem){DWORD n=rem>262144?262144:(DWORD)rem;if(!read_exact(a,x,n)||!read_exact(b,y,n)||memcmp(x,y,n)){ok=0;break;}rem-=n;}HeapFree(GetProcessHeap(),0,x);HeapFree(GetProcessHeap(),0,y);CloseHandle(a);CloseHandle(b);return ok;}

static int sha_bytes(const BYTE* d,DWORD n,BYTE out[32]){HCRYPTPROV p=0;HCRYPTHASH h=0;DWORD sz=32;int ok=0;if(!CryptAcquireContextW(&p,NULL,NULL,PROV_RSA_AES,CRYPT_VERIFYCONTEXT))goto done;if(!CryptCreateHash(p,CALG_SHA_256,0,0,&h))goto done;if(n&&!CryptHashData(h,d,n,0))goto done;if(!CryptGetHashParam(h,HP_HASHVAL,out,&sz,0)||sz!=32)goto done;ok=1;done:if(h)CryptDestroyHash(h);if(p)CryptReleaseContext(p,0);return ok;}
static int sha_file(LPCWSTR path,BYTE out[32]){HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return 0;HCRYPTPROV p=0;HCRYPTHASH h=0;BYTE*buf=NULL;DWORD r,sz=32;int ok=0;if(!CryptAcquireContextW(&p,NULL,NULL,PROV_RSA_AES,CRYPT_VERIFYCONTEXT))goto done;if(!CryptCreateHash(p,CALG_SHA_256,0,0,&h))goto done;buf=(BYTE*)HeapAlloc(GetProcessHeap(),0,1024*1024);if(!buf)goto done;for(;;){if(!ReadFile(f,buf,1024*1024,&r,NULL))goto done;if(!r)break;if(!CryptHashData(h,buf,r,0))goto done;}if(!CryptGetHashParam(h,HP_HASHVAL,out,&sz,0)||sz!=32)goto done;ok=1;done:if(buf)HeapFree(GetProcessHeap(),0,buf);if(h)CryptDestroyHash(h);if(p)CryptReleaseContext(p,0);CloseHandle(f);return ok;}

static int ensure_dir(LPCWSTR p){if(dir_exists(p))return 1;return CreateDirectoryW(p,NULL)?1:0;}
static void remove_simple_dir(LPCWSTR dir){WCHAR p[4096];const WCHAR* names[]={L"6242ff7e5bc499ee.original",L"chunk_PI2.zst",L"chunk_PI5.zst",L"chunk_PI7.zst",L"chunk_PI9.zst",L"baseline.bin",L"state.txt",L"state.json"};int i;for(i=0;i<8;i++){join(p,4096,dir,names[i]);DeleteFileW(p);}RemoveDirectoryW(dir);}
static int atomic_replace_from_file(LPCWSTR src,LPCWSTR dst){if(!CopyFileW(src,dst,FALSE))return 0;return files_equal(src,dst);}

static int run_process(LPWSTR cmd,LPCWSTR cwd){STARTUPINFOW si;PROCESS_INFORMATION pi;DWORD code=1;memset(&si,0,sizeof(si));memset(&pi,0,sizeof(pi));si.cb=sizeof(si);si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;if(!CreateProcessW(NULL,cmd,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,cwd,&si,&pi))return 0;WaitForSingleObject(pi.hProcess,INFINITE);GetExitCodeProcess(pi.hProcess,&code);CloseHandle(pi.hThread);CloseHandle(pi.hProcess);return code==0;}
static int zstd_decompress(LPCWSTR src,LPCWSTR out){WCHAR cmd[65536];wcopy(cmd,65536,L"\"");wcat(cmd,65536,gZstd);wcat(cmd,65536,L"\" -q -d -f \"");wcat(cmd,65536,src);wcat(cmd,65536,L"\" -o \"");wcat(cmd,65536,out);wcat(cmd,65536,L"\"");return run_process(cmd,gWork);}
static int zstd_compress(LPCWSTR src,LPCWSTR out){WCHAR cmd[65536];wcopy(cmd,65536,L"\"");wcat(cmd,65536,gZstd);wcat(cmd,65536,L"\" -q -19 -f \"");wcat(cmd,65536,src);wcat(cmd,65536,L"\" -o \"");wcat(cmd,65536,out);wcat(cmd,65536,L"\"");return run_process(cmd,gWork);}

static int expand_manifest(LPCWSTR manifest,LPCWSTR out){DWORD n=0;BYTE*b=read_all(manifest,&n);if(!b||n<28){if(b)HeapFree(GetProcessHeap(),0,b);return 0;}if(memcmp(b,"ZSTD",4)){HeapFree(GetProcessHeap(),0,b);return 0;}WCHAR frame[4096];wcopy(frame,4096,out);wcat(frame,4096,L".zst");int ok=write_all(frame,b+24,n-24)&&zstd_decompress(frame,out);HeapFree(GetProcessHeap(),0,b);return ok;}
static int parse_manifest(BYTE*b,DWORD n,DWORD*secA,DWORD*rowStart,DWORD*rowCount){if(n<216)return 0;DWORD secALen=rd32(b,24),c1=rd32(b,56),c2=rd32(b,64),secBLen=rd32(b,88),rc=rd32(b,184);ULONGLONG rs=200ULL+(ULONGLONG)secALen+(ULONGLONG)secBLen;log_num("MANIFEST_DIAG: decoded_size=",n);log_num("MANIFEST_DIAG: sectionA_len=",secALen);log_num("MANIFEST_DIAG: sectionA_count1=",c1);log_num("MANIFEST_DIAG: sectionA_count2=",c2);log_num("MANIFEST_DIAG: sectionB_len=",secBLen);log_num("MANIFEST_DIAG: row_count=",rc);if(secALen!=(ULONGLONG)c1*32ULL||c1!=c2||c1<1||c1>10000000UL||rc<1||rc>1000000UL||rs>(ULONGLONG)n||rs+(ULONGLONG)rc*16ULL>(ULONGLONG)n)return 0;*secA=200;*rowStart=(DWORD)rs;*rowCount=rc;return 1;}
static int build_manifest(LPCWSTR base,const BYTE*dec,DWORD decN,LPCWSTR frame,LPCWSTR out){DWORD bn=0,fn=0;BYTE*bb=read_all(base,&bn),*fb=read_all(frame,&fn);if(!bb||!fb||bn<24){if(bb)HeapFree(GetProcessHeap(),0,bb);if(fb)HeapFree(GetProcessHeap(),0,fb);return 0;}BYTE*o=(BYTE*)HeapAlloc(GetProcessHeap(),0,24+fn);if(!o){HeapFree(GetProcessHeap(),0,bb);HeapFree(GetProcessHeap(),0,fb);return 0;}memcpy(o,bb,24);wr32(o,8,decN);wr32(o,16,fn);memcpy(o+24,fb,fn);int ok=write_all(out,o,24+fn);HeapFree(GetProcessHeap(),0,o);HeapFree(GetProcessHeap(),0,bb);HeapFree(GetProcessHeap(),0,fb);return ok;}

static void package_path(DWORD pi,LPWSTR out){WCHAR dir[4096],n[128],num[32];join(dir,4096,gGame,PACKAGES_REL);wcopy(n,128,MANIFEST_NAME);wcat(n,128,L"_");u32w(pi,num,32);wcat(n,128,num);join(out,4096,dir,n);}
static void backup_chunk_path(LPCWSTR backup,DWORD pi,LPWSTR out){WCHAR n[64],num[32];wcopy(n,64,L"chunk_PI");u32w(pi,num,32);wcat(n,64,num);wcat(n,64,L".zst");join(out,4096,backup,n);}

static int save_backup_state(LPCWSTR backup,const ULONGLONG sizes[4],const BYTE manifestSha[32]){
 WCHAR p[4096];BackupState st;memset(&st,0,sizeof(st));memcpy(st.magic,BACKUP_MAGIC,8);int i;for(i=0;i<4;i++)st.pkgSize[i]=sizes[i];memcpy(st.manifestSha,manifestSha,32);join(p,4096,backup,L"baseline.bin");return write_all(p,(const BYTE*)&st,(DWORD)sizeof(st));
}
static int load_backup_state(LPCWSTR backup,BackupState* st){WCHAR p[4096];join(p,4096,backup,L"baseline.bin");DWORD n=0;BYTE*b=read_all(p,&n);if(!b||n!=sizeof(BackupState)){if(b)HeapFree(GetProcessHeap(),0,b);return 0;}memcpy(st,b,sizeof(BackupState));HeapFree(GetProcessHeap(),0,b);return memcmp(st->magic,BACKUP_MAGIC,8)==0;}
static void log_hash_line(const char* prefix,const BYTE h[32]){char hs[65];hexstr(h,hs);log_ascii(prefix);log_ascii(hs);}
static void log_target_diag(int i,DWORD pi,DWORD off,DWORD cs,DWORD us,DWORD rchunk,DWORD aoff,DWORD asz,DWORD flags,ULONGLONG pkgSize){
 log_num("CHECK target index=",(ULONGLONG)i);log_num("  chunk=",T[i].chunk);log_num("  record=",T[i].record);log_num("  manifest.pi.observed=",pi);log_num("  manifest.offset.observed=",off);log_num("  manifest.compressed_size.observed=",cs);log_num("  manifest.uncompressed_size.observed=",us);log_num("  record.chunk.observed=",rchunk);log_num("  record.asset_off.observed=",aoff);log_num("  record.asset_size.observed=",asz);log_num("  record.flags.observed=",flags);log_num("  package.size.observed=",pkgSize);log_num("  package.size.old_reference=",REFERENCE_PKG_SIZE[i]);
}
static int restore_backup_dir(LPCWSTR backup,int legacy){
 (void)legacy;WCHAR bm[4096],live[4096],pkg[4096],bc[4096];BackupState st;join(bm,4096,backup,L"6242ff7e5bc499ee.original");join(live,4096,gGame,MANIFEST_REL);if(!file_exists(bm)){log_ascii("RESTORE: backup manifest missing");return 0;}if(!load_backup_state(backup,&st)){log_ascii("RESTORE: baseline.bin missing or invalid");return 0;}BYTE bsha[32];if(!sha_file(bm,bsha)||memcmp(bsha,st.manifestSha,32)){log_ascii("RESTORE: backup manifest SHA does not match saved baseline");return 0;}
 int i;for(i=0;i<4;i++){package_path(T[i].pi,pkg);backup_chunk_path(backup,T[i].pi,bc);ULONGLONG ps=0,cs=0;if(!fsize(pkg,&ps)){log_ascii("RESTORE: package missing");return 0;}if(ps==st.pkgSize[i])continue;if(!fsize(bc,&cs)){log_ascii("RESTORE: appended chunk backup missing");return 0;}if(ps!=st.pkgSize[i]+cs){log_ascii("RESTORE: unexpected package size; refused");log_num("  observed=",ps);log_num("  expected_baseline=",st.pkgSize[i]);log_num("  expected_with_tail=",st.pkgSize[i]+cs);return 0;}if(!tail_equals_file(pkg,st.pkgSize[i],bc)){log_ascii("RESTORE: appended tail mismatch; refused");return 0;}}
 if(!files_equal(live,bm)){if(!atomic_replace_from_file(bm,live)){log_ascii("RESTORE: manifest replacement failed");return 0;}log_ascii("RESTORE: original manifest restored");}else log_ascii("RESTORE: live manifest already baseline");
 for(i=0;i<4;i++){package_path(T[i].pi,pkg);ULONGLONG ps=0;fsize(pkg,&ps);if(ps>st.pkgSize[i]){if(!truncate_file(pkg,st.pkgSize[i])){log_ascii("RESTORE: package truncation failed");return 0;}}}
 if(!files_equal(live,bm)){log_ascii("RESTORE: manifest verification failed");return 0;}for(i=0;i<4;i++){package_path(T[i].pi,pkg);ULONGLONG ps=0;if(!fsize(pkg,&ps)||ps!=st.pkgSize[i]){log_ascii("RESTORE: final package size mismatch");return 0;}}
 log_ascii("V090_READY_R4_RESTORE_OK");remove_simple_dir(backup);return 1;
}

static int contains_ascii(const BYTE*b,DWORD n,const char*q){DWORD qn=0,i,j;while(q[qn])qn++;if(!qn||qn>n)return 0;for(i=0;i+qn<=n;i++){for(j=0;j<qn&&b[i+j]==(BYTE)q[j];j++){;}if(j==qn)return 1;}return 0;}
static int contains_ascii_range(const BYTE*b,DWORD n,DWORD start,DWORD end,const char*q){DWORD qn=0,i,j;while(q[qn])qn++;if(!qn||start>=n)return 0;if(end>n)end=n;if(end<start||end-start<qn)return 0;for(i=start;i+qn<=end;i++){for(j=0;j<qn&&b[i+j]==(BYTE)q[j];j++){;}if(j==qn)return 1;}return 0;}
static DWORD count_bytes_range(const BYTE*b,DWORD n,DWORD start,DWORD end,const BYTE*pat,DWORD pn){DWORD i,c=0;if(!b||!pat||!pn||start>=n)return 0;if(end>n)end=n;if(end<start||end-start<pn)return 0;for(i=start;i+pn<=end;i++)if(!memcmp(b+i,pat,pn))c++;return c;}
static int verify_v090_install(void){WCHAR st[4096],mm[4096],mp[4096];join(st,4096,gGame,V090_STATE_REL);join(mm,4096,gGame,V090_MAIN_MANIFEST_REL);join(mp,4096,gGame,V090_MAIN_PACKAGE_REL);log_ascii("=== V0.9.0 PUBLIC INSTALL CHECK ===");if(!file_exists(st)){log_ascii("BASELINE_V090: marker missing: LE2_FR_V0.9.0_STATE.txt");return 0;}if(!file_exists(mm)){log_ascii("BASELINE_V090: ff715342fa4b2d8f manifest missing");return 0;}if(!file_exists(mp)){log_ascii("BASELINE_V090: ff715342fa4b2d8f_0 package missing");return 0;}DWORD n=0;BYTE*b=read_all(st,&n);if(!b){log_ascii("BASELINE_V090: state file unreadable");return 0;}int ok=contains_ascii(b,n,"Version=V0.9.0");HeapFree(GetProcessHeap(),0,b);if(!ok){log_ascii("BASELINE_V090: state file does not contain Version=V0.9.0");return 0;}BYTE h[32];if(sha_file(mm,h))log_hash_line("BASELINE_V090: main manifest SHA256 follows",h);if(sha_file(mp,h))log_hash_line("BASELINE_V090: main package SHA256 follows",h);log_ascii("BASELINE_V090: official V0.9.0 marker and main files detected");return 1;}

static void a_cat(char* d,DWORD cap,const char* s){DWORD i=0,j=0;while(d[i]&&i+1<cap)i++;while(s&&s[j]&&i+1<cap)d[i++]=s[j++];d[i]=0;}
static void a_u32(char* d,DWORD cap,DWORD v){char t[16];DWORD n=0;if(!v){a_cat(d,cap,"0");return;}while(v&&n<15){t[n++]=(char)('0'+(v%10));v/=10;}while(n){char c[2];c[0]=t[--n];c[1]=0;a_cat(d,cap,c);}}
static void a_hex8(char* d,DWORD cap,DWORD v){static const char*x="0123456789ABCDEF";char t[11];int i;t[0]='0';t[1]='x';for(i=0;i<8;i++)t[2+i]=x[(v>>(28-i*4))&15];t[10]=0;a_cat(d,cap,t);}
static int is_print(BYTE c){return c>=32&&c<=126;}
static DWORD count_pat(const BYTE*b,DWORD n,const BYTE*p,DWORD pn){DWORD i,c=0;if(!pn||pn>n)return 0;for(i=0;i+pn<=n;i++)if(!memcmp(b+i,p,pn))c++;return c;}
static void log_pat_count(const char* name,const BYTE*b,DWORD n,const BYTE*p,DWORD pn){char line[256];line[0]=0;a_cat(line,256,"PATTERN | ");a_cat(line,256,name);a_cat(line,256," | COUNT=");a_u32(line,256,count_pat(b,n,p,pn));log_ascii(line);}
static void hex_dump(const BYTE*b,DWORD n,DWORD center,DWORD radius){DWORD s=center>radius?center-radius:0,e=center+radius<n?center+radius:n;DWORD p;char line[512];for(p=s;p<e;p+=16){DWORD j;line[0]=0;a_cat(line,512,"HEX | OFF=");a_hex8(line,512,p);a_cat(line,512," | ");for(j=0;j<16&&p+j<e;j++){static const char*x="0123456789ABCDEF";char h[4];BYTE v=b[p+j];h[0]=x[v>>4];h[1]=x[v&15];h[2]=' ';h[3]=0;a_cat(line,512,h);}a_cat(line,512," | ");for(j=0;j<16&&p+j<e;j++){char c[2];BYTE v=b[p+j];c[0]=is_print(v)?(char)v:'.';c[1]=0;a_cat(line,512,c);}log_ascii(line);}}
static int str_contains(const char*s,const char*q){DWORD i,j,qn=0;while(q[qn])qn++;for(i=0;s[i];i++){for(j=0;j<qn&&s[i+j]&&s[i+j]==q[j];j++){} if(j==qn)return 1;}return 0;}
static int interesting(const char*s){const char* q[]={"No","Yes","Not","Incorrect","Unconvincing","reply","response","Reply","Response","ready","Ready","calib","Calib","menu","Menu","Continue","continue"};DWORD i;DWORD count=(DWORD)(sizeof(q)/sizeof(q[0]));for(i=0;i<count;i++)if(str_contains(s,q[i]))return 1;return 0;}
static void dump_strings(const BYTE*b,DWORD n,DWORD assetBase){DWORD i=0,count=0;log_ascii("-- NULL-TERMINATED PRINTABLE STRINGS (max 500) --");while(i<n&&count<500){if(is_print(b[i])&&(i==0||!is_print(b[i-1]))){DWORD j=i;while(j<n&&is_print(b[j])&&j-i<180)j++;if(j<n&&b[j]==0&&j-i>=2){char line[512],txt[200];DWORD k,L=j-i;if(L>180)L=180;for(k=0;k<L;k++)txt[k]=(char)b[i+k];txt[L]=0;line[0]=0;a_cat(line,512,"STR | ASSET_LOCAL=");a_u32(line,512,i);a_cat(line,512," | CHUNK_OFF=");a_u32(line,512,assetBase+i);a_cat(line,512," | ");a_cat(line,512,txt);log_ascii(line);if(interesting(txt)){log_ascii("  >>> INTERESTING_STRING_HEX_CONTEXT");hex_dump(b,n,i,96);}count++;i=j+1;continue;}}i++;}log_num("STRING_COUNT_LOGGED=",count);}
static void chunk_patterns(const BYTE*b,DWORD n){static const BYTE no0[]={'N','o',0};static const BYTE no00[]={'N','o',0,0};static const BYTE non0[]={'N','o','n',0};static const BYTE yes0[]={'Y','e','s',0};static const BYTE oui0[]={'O','u','i',0};static const BYTE utfno[]={'N',0,'o',0};static const BYTE utfnon[]={'N',0,'o',0,'n',0};static const BYTE utfyes[]={'Y',0,'e',0,'s',0};static const BYTE notyet[]={'N','o','t',' ','y','e','t',0};static const BYTE incorrect[]={'I','n','c','o','r','r','e','c','t',0};static const BYTE unconv[]={'U','n','c','o','n','v','i','n','c','i','n','g',0};log_pat_count("ASCII No\\0",b,n,no0,sizeof(no0));log_pat_count("ASCII No\\0\\0",b,n,no00,sizeof(no00));log_pat_count("ASCII Non\\0",b,n,non0,sizeof(non0));log_pat_count("ASCII Yes\\0",b,n,yes0,sizeof(yes0));log_pat_count("ASCII Oui\\0",b,n,oui0,sizeof(oui0));log_pat_count("UTF16LE No",b,n,utfno,sizeof(utfno));log_pat_count("UTF16LE Non",b,n,utfnon,sizeof(utfnon));log_pat_count("UTF16LE Yes",b,n,utfyes,sizeof(utfyes));log_pat_count("ASCII Not yet",b,n,notyet,sizeof(notyet));log_pat_count("ASCII Incorrect",b,n,incorrect,sizeof(incorrect));log_pat_count("ASCII Unconvincing",b,n,unconv,sizeof(unconv));}
static int extract_chunk(BYTE*mb,DWORD mn,DWORD rowStart,DWORD chunk,WCHAR*outDec,DWORD*outPi){DWORD rp=rowStart+chunk*16;if(rp+16>mn)return 0;DWORD pi=rd32(mb,rp),off=rd32(mb,rp+4),cs=rd32(mb,rp+8),us=rd32(mb,rp+12);WCHAR pkg[4096],z[4096],num[32];package_path(pi,pkg);u32w(chunk,num,32);join(z,4096,gWork,L"chunk_");wcat(z,4096,num);wcat(z,4096,L".zst");join(outDec,4096,gWork,L"chunk_");wcat(outDec,4096,num);wcat(outDec,4096,L".dec");char line[256];line[0]=0;a_cat(line,256,"CHUNK_META | CHUNK=");a_u32(line,256,chunk);a_cat(line,256," | PI=");a_u32(line,256,pi);a_cat(line,256," | OFFSET=");a_u32(line,256,off);a_cat(line,256," | CS=");a_u32(line,256,cs);a_cat(line,256," | US=");a_u32(line,256,us);log_ascii(line);BYTE*c=read_range(pkg,off,cs);if(!c||!write_all(z,c,cs)){if(c)HeapFree(GetProcessHeap(),0,c);return 0;}HeapFree(GetProcessHeap(),0,c);if(!zstd_decompress(z,outDec))return 0;DWORD dn=0;BYTE*db=read_all(outDec,&dn);if(!db)return 0;chunk_patterns(db,dn);HeapFree(GetProcessHeap(),0,db);if(outPi)*outPi=pi;return 1;}

static int is_alnum_ascii(BYTE c){return (c>='0'&&c<='9')||(c>='A'&&c<='Z')||(c>='a'&&c<='z')||c=='_';}
static DWORD count_token2(const BYTE*b,DWORD n,const char*tok){DWORD L=0,i,c=0;while(tok[L])L++;if(!L||L>n)return 0;for(i=0;i+L<=n;i++){if(memcmp(b+i,tok,L))continue;BYTE prev=i?b[i-1]:0,next=(i+L<n)?b[i+L]:0;if(!is_alnum_ascii(prev)&&!is_alnum_ascii(next))c++;}return c;}
static void log_token_count(const char*tok,const BYTE*b,DWORD n){char line[256];line[0]=0;a_cat(line,256,"TOKEN | ");a_cat(line,256,tok);a_cat(line,256," | COUNT=");a_u32(line,256,count_token2(b,n,tok));log_ascii(line);}
static void dump_token_hits(const BYTE*b,DWORD n,const char*tok,DWORD maxHits,DWORD radius){DWORD L=0,i,h=0;while(tok[L])L++;for(i=0;i+L<=n&&h<maxHits;i++){if(memcmp(b+i,tok,L))continue;BYTE prev=i?b[i-1]:0,next=(i+L<n)?b[i+L]:0;if(is_alnum_ascii(prev)||is_alnum_ascii(next))continue;char line[256];line[0]=0;a_cat(line,256,"TOKEN_HIT | ");a_cat(line,256,tok);a_cat(line,256," | OFF=");a_u32(line,256,i);log_ascii(line);hex_dump(b,n,i,radius);h++;}char sum[256];sum[0]=0;a_cat(sum,256,"TOKEN_HITS_LOGGED | ");a_cat(sum,256,tok);a_cat(sum,256," = ");a_u32(sum,256,h);log_ascii(sum);}
static void log_exact_ascii0(const char*label,const BYTE*b,DWORD n,const char*txt){DWORD L=0;while(txt[L])L++;BYTE pat[128];DWORD i;if(L+1>sizeof(pat))return;for(i=0;i<L;i++)pat[i]=(BYTE)txt[i];pat[L]=0;log_pat_count(label,b,n,pat,L+1);}
static void dump_ui_dictionary_counts(const BYTE*b,DWORD n){
 const char* labels[]={"No","Yes","Non","Oui","BACK","CLOSE","CONFIRM","CONTINUE","DEFAULT","DONE","NEXT","OFF","ON","OPEN","OPTIONS","QUIT","RESET","RESTART","SAVE","SKIP","START","Cancel","CANCEL","Back","Continue"};
 DWORD i,count=(DWORD)(sizeof(labels)/sizeof(labels[0]));
 log_ascii("=== UI DICTIONARY TOKEN COUNTS ===");
 for(i=0;i<count;i++)log_token_count(labels[i],b,n);
 log_ascii("=== UI DICTIONARY NULL-TERMINATED COUNTS ===");
 for(i=0;i<count;i++){char name[160];name[0]=0;a_cat(name,160,"ASCII ");a_cat(name,160,labels[i]);a_cat(name,160,"\\0");log_exact_ascii0(name,b,n,labels[i]);}
}
static void probe_known_ids(const BYTE*b,DWORD n){
 const char* ids[]={"ff6c7bd9a5af28ef","f594fe48ea1317b3","fe6d7bd9a5af28ef","e097e848ea1317b3"};
 const char* names[]={"No/Non","Yes/Oui","On","Off"}; DWORD i;
 log_ascii("=== KNOWN LOCALIZED-ID PROBE ===");
 for(i=0;i<4;i++){
   char line[256];line[0]=0;a_cat(line,256,"ID_ASCII | ");a_cat(line,256,names[i]);a_cat(line,256," | ");a_cat(line,256,ids[i]);a_cat(line,256," | COUNT=");a_u32(line,256,count_pat(b,n,(const BYTE*)ids[i],16));log_ascii(line);
   BYTE le[8];DWORD j;for(j=0;j<8;j++){char h1=ids[i][j*2],h2=ids[i][j*2+1];BYTE a=(BYTE)(h1>='a'?h1-'a'+10:h1-'0');BYTE c=(BYTE)(h2>='a'?h2-'a'+10:h2-'0');le[7-j]=(BYTE)((a<<4)|c);}line[0]=0;a_cat(line,256,"ID_LE64 | ");a_cat(line,256,names[i]);a_cat(line,256," | COUNT=");a_u32(line,256,count_pat(b,n,le,8));log_ascii(line);
 }
}
static void dump_no_yes_clusters(const BYTE*b,DWORD n){
 DWORD i,j,clusters=0;log_ascii("=== NO/YES PROXIMITY CLUSTERS (token-boundary, +/-512 bytes) ===");
 for(i=0;i+2<=n&&clusters<64;i++){
  if(b[i]!='N'||b[i+1]!='o')continue;BYTE p=i?b[i-1]:0,q=(i+2<n)?b[i+2]:0;if(is_alnum_ascii(p)||is_alnum_ascii(q))continue;
  DWORD s=i>512?i-512:0,e=i+512<n?i+512:n;int yes=0;for(j=s;j+3<=e;j++){if(b[j]=='Y'&&b[j+1]=='e'&&b[j+2]=='s'){BYTE p2=j?b[j-1]:0,q2=(j+3<n)?b[j+3]:0;if(!is_alnum_ascii(p2)&&!is_alnum_ascii(q2)){yes=1;break;}}}
  if(yes){char line[256];line[0]=0;a_cat(line,256,"PAIR_CLUSTER | NO_OFF=");a_u32(line,256,i);a_cat(line,256," | YES_NEAR_OFF=");a_u32(line,256,j);log_ascii(line);hex_dump(b,n,i,160);clusters++;}
 }
 log_num("PAIR_CLUSTER_COUNT_LOGGED=",clusters);
}
static int parse_string_table(const BYTE* b,DWORD n,DWORD* count,DWORD* offPos,DWORD* base){
 if(n<16)return 0;DWORD c=rd32(b,0);if(c<1||c>5000)return 0;ULONGLONG cp=4ULL+8ULL*c;if(cp+4>n)return 0;if(rd32(b,(DWORD)cp)!=c)return 0;ULONGLONG op=cp+4,bp=op+4ULL*(c+1);if(bp>n)return 0;DWORD prev=0,i;for(i=0;i<=c;i++){DWORD v=rd32(b,(DWORD)op+i*4);if(i==0&&v!=0)return 0;if(i&&v<=prev)return 0;prev=v;}if(bp+prev!=n)return 0;*count=c;*offPos=(DWORD)op;*base=(DWORD)bp;return 1;
}
static void idhex8(const BYTE*b,char*out){static const char*x="0123456789abcdef";DWORD i;for(i=0;i<8;i++){out[i*2]=x[b[i]>>4];out[i*2+1]=x[b[i]&15];}out[16]=0;}
static void dump_slot(const BYTE*asset,DWORD asz,DWORD count,DWORD offPos,DWORD base,DWORD slot){
 char line[768],id[17],txt[512];if(slot>=count)return;DWORD a=rd32(asset,offPos+slot*4),e=rd32(asset,offPos+(slot+1)*4);if(e<=a||base+e>asz)return;DWORD len=e-a-1;if(len>480)len=480;DWORD i;for(i=0;i<len;i++){BYTE c=asset[base+a+i];txt[i]=(c>=32&&c<=126)?(char)c:'?';}txt[len]=0;idhex8(asset+4+8*slot,id);line[0]=0;a_cat(line,768,"SLOT | ");a_u32(line,768,slot);a_cat(line,768," | ID=");a_cat(line,768,id);a_cat(line,768," | TEXT=");a_cat(line,768,txt);log_ascii(line);
}

static int is_dot_name(LPCWSTR n){return (n[0]==L'.'&&n[1]==0)||(n[0]==L'.'&&n[1]==L'.'&&n[2]==0);}
static void pkg_path_for(LPCWSTR manifestName,DWORD pi,LPWSTR out){WCHAR dir[4096],name[512],num[32];join(dir,4096,gGame,PACKAGES_REL);wcopy(name,512,manifestName);wcat(name,512,L"_");u32w(pi,num,32);wcat(name,512,num);join(out,4096,dir,name);}
static void make_temp_name(LPCWSTR prefix,DWORD a,DWORD b,LPWSTR out){WCHAR n[256],x[32];wcopy(n,256,prefix);u32w(a,x,32);wcat(n,256,x);wcat(n,256,L"_");u32w(b,x,32);wcat(n,256,x);join(out,4096,gWork,n);}
static int extract_chunk_for_manifest(LPCWSTR manifestName,const BYTE*mb,DWORD mn,DWORD rowStart,DWORD rowCount,DWORD chunk,WCHAR*outDec){
 if(chunk>=rowCount)return 0;DWORD rp=rowStart+chunk*16;if(rp+16>mn)return 0;DWORD pi=rd32(mb,rp),off=rd32(mb,rp+4),cs=rd32(mb,rp+8),us=rd32(mb,rp+12);if(!cs||!us||us>64*1024*1024UL)return 0;
 WCHAR pkg[4096],z[4096];pkg_path_for(manifestName,pi,pkg);if(!file_exists(pkg))return 0;make_temp_name(L"mchunk_",chunk,pi,z);wcat(z,4096,L".zst");make_temp_name(L"mchunk_",chunk,pi,outDec);wcat(outDec,4096,L".dec");BYTE*c=read_range(pkg,off,cs);if(!c)return 0;int ok=write_all(z,c,cs);HeapFree(GetProcessHeap(),0,c);if(!ok)return 0;int dz=zstd_decompress(z,outDec);DeleteFileW(z);return dz;
}
static int id_matches(const BYTE*p,const char*hex){static const char*x="0123456789abcdef";DWORD i;for(i=0;i<8;i++){char a=x[p[i]>>4],b=x[p[i]&15];if(a!=hex[i*2]||b!=hex[i*2+1])return 0;}return 1;}
static int table_find_id(const BYTE*asset,DWORD asz,const char*hex,DWORD*slotOut,char*txt,DWORD txtCap){DWORD count,offPos,base;if(!parse_string_table(asset,asz,&count,&offPos,&base))return 0;DWORD i;for(i=0;i<count;i++){if(id_matches(asset+4+8*i,hex)){DWORD a=rd32(asset,offPos+i*4),e=rd32(asset,offPos+(i+1)*4);if(e<=a||base+e>asz)return 0;DWORD L=e-a-1;if(L+1>txtCap)L=txtCap-1;DWORD j;for(j=0;j<L;j++){BYTE c=asset[base+a+j];txt[j]=(c>=32&&c<=126)?(char)c:'?';}txt[L]=0;*slotOut=i;return 1;}}return 0;}
static int table_label_score(const BYTE*asset,DWORD asz,DWORD*countOut){DWORD count,offPos,base;if(!parse_string_table(asset,asz,&count,&offPos,&base))return 0;DWORD score=0,i;for(i=0;i<count;i++){DWORD a=rd32(asset,offPos+i*4),e=rd32(asset,offPos+(i+1)*4);if(e<=a||base+e>asz)continue;DWORD L=e-a-1;const BYTE*t=asset+base+a;if((L==2&&t[0]=='N'&&t[1]=='o')||(L==3&&t[0]=='Y'&&t[1]=='e'&&t[2]=='s')||(L==3&&t[0]=='N'&&t[1]=='o'&&t[2]=='n')||(L==3&&t[0]=='O'&&t[1]=='u'&&t[2]=='i')||(L==2&&t[0]=='O'&&t[1]=='n')||(L==3&&t[0]=='O'&&t[1]=='f'&&t[2]=='f'))score++;}if(countOut)*countOut=count;return score;}
static void log_manifest_name(LPCWSTR name){char b[512];int n=WideCharToMultiByte(CP_UTF8,0,name,-1,b,511,NULL,NULL);if(n>0){char line[768];line[0]=0;a_cat(line,768,"MANIFEST | ");a_cat(line,768,b);log_ascii(line);}}
static int scan_manifest_file(LPCWSTR manifestName,LPCWSTR path,DWORD*manifestCount,DWORD*tableCount,DWORD*idHitCount,DWORD*labelTableCount){
 WCHAR dec[4096];DWORD mn=0,secA,rowStart,rowCount;make_temp_name(L"manifest_",*manifestCount,0,dec);wcat(dec,4096,L".dec");if(!expand_manifest(path,dec)){log_manifest_name(manifestName);log_ascii("  SKIP: decode failed");return 1;}BYTE*mb=read_all(dec,&mn);if(!mb)return 1;if(!parse_manifest(mb,mn,&secA,&rowStart,&rowCount)){log_manifest_name(manifestName);log_ascii("  SKIP: structure not recognized");HeapFree(GetProcessHeap(),0,mb);return 1;}(*manifestCount)++;
 DWORD recCount=rd32(mb,56);BYTE*need=(BYTE*)HeapAlloc(GetProcessHeap(),0,rowCount?rowCount:1);if(!need){HeapFree(GetProcessHeap(),0,mb);return 0;}memset(need,0,rowCount);DWORD r,candidateRecords=0;for(r=0;r<recCount;r++){DWORD p=secA+r*32;if(p+32>mn)break;DWORD chunk=rd32(mb,p+16),asz=rd32(mb,p+24),flags=rd32(mb,p+28);if(chunk<rowCount&&flags==16&&asz>=32&&asz<=262144){need[chunk]=1;candidateRecords++;}}
 char head[512];char m8[256];int wn=WideCharToMultiByte(CP_UTF8,0,manifestName,-1,m8,255,NULL,NULL);if(wn<=0)m8[0]=0;head[0]=0;a_cat(head,512,"SCAN_MANIFEST | ");a_cat(head,512,m8);a_cat(head,512," | records=");a_u32(head,512,recCount);a_cat(head,512," | candidate_small_records=");a_u32(head,512,candidateRecords);log_ascii(head);
 DWORD ch;for(ch=0;ch<rowCount;ch++){if(!need[ch])continue;WCHAR cdec[4096];if(!extract_chunk_for_manifest(manifestName,mb,mn,rowStart,rowCount,ch,cdec))continue;DWORD dn=0;BYTE*db=read_all(cdec,&dn);if(!db)continue;
   DWORD rawHits=0;const char* ids[4]={"ff6c7bd9a5af28ef","f594fe48ea1317b3","fe6d7bd9a5af28ef","e097e848ea1317b3"};DWORD ii;for(ii=0;ii<4;ii++){BYTE pat[8];DWORD j;for(j=0;j<8;j++){char h1=ids[ii][j*2],h2=ids[ii][j*2+1];BYTE a=(BYTE)(h1>='a'?h1-'a'+10:h1-'0');BYTE b=(BYTE)(h2>='a'?h2-'a'+10:h2-'0');pat[j]=(BYTE)((a<<4)|b);}rawHits+=count_pat(db,dn,pat,8);} 
   if(rawHits){char line[512];line[0]=0;a_cat(line,512,"CHUNK_ID_SIGNAL | manifest=");a_cat(line,512,m8);a_cat(line,512," | chunk=");a_u32(line,512,ch);a_cat(line,512," | raw_known_id_hits=");a_u32(line,512,rawHits);log_ascii(line);} 
   for(r=0;r<recCount;r++){DWORD p=secA+r*32;if(p+32>mn)break;if(rd32(mb,p+16)!=ch)continue;DWORD aoff=rd32(mb,p+20),asz=rd32(mb,p+24),flags=rd32(mb,p+28);if(flags!=16||asz<32||asz>262144||aoff>dn||asz>dn-aoff)continue;BYTE*asset=db+aoff;DWORD count=0,offPos=0,base=0;if(!parse_string_table(asset,asz,&count,&offPos,&base))continue;(*tableCount)++;DWORD score=table_label_score(asset,asz,NULL);if(score>=2){(*labelTableCount)++;char line[768];line[0]=0;a_cat(line,768,"LABEL_TABLE | manifest=");a_cat(line,768,m8);a_cat(line,768," | chunk=");a_u32(line,768,ch);a_cat(line,768," | record=");a_u32(line,768,r);a_cat(line,768," | strings=");a_u32(line,768,count);a_cat(line,768," | ui_label_score=");a_u32(line,768,score);log_ascii(line);} 
      for(ii=0;ii<4;ii++){DWORD slot;char txt[256];if(table_find_id(asset,asz,ids[ii],&slot,txt,256)){(*idHitCount)++;char line[1024];line[0]=0;a_cat(line,1024,"ID_TABLE_HIT | manifest=");a_cat(line,1024,m8);a_cat(line,1024," | chunk=");a_u32(line,1024,ch);a_cat(line,1024," | record=");a_u32(line,1024,r);a_cat(line,1024," | slot=");a_u32(line,1024,slot);a_cat(line,1024," | id=");a_cat(line,1024,ids[ii]);a_cat(line,1024," | text=");a_cat(line,1024,txt);log_ascii(line);}}
   }
   HeapFree(GetProcessHeap(),0,db);DeleteFileW(cdec);
 }
 HeapFree(GetProcessHeap(),0,need);HeapFree(GetProcessHeap(),0,mb);return 1;
}

static int exact_label_kind_bytes(const BYTE*t,DWORD L){
 if(L==2&&t[0]=='N'&&t[1]=='o')return 1;
 if(L==3&&t[0]=='Y'&&t[1]=='e'&&t[2]=='s')return 2;
 if(L==3&&t[0]=='N'&&t[1]=='o'&&t[2]=='n')return 3;
 if(L==3&&t[0]=='O'&&t[1]=='u'&&t[2]=='i')return 4;
 if(L==2&&t[0]=='O'&&t[1]=='n')return 5;
 if(L==3&&t[0]=='O'&&t[1]=='f'&&t[2]=='f')return 6;
 return 0;
}
static const char* label_kind_name(int k){
 if(k==1)return "NO_EN"; if(k==2)return "YES_EN"; if(k==3)return "NON_FR"; if(k==4)return "OUI_FR"; if(k==5)return "ON_EN"; if(k==6)return "OFF_EN"; return "";
}
static int dump_record185_manifest(LPCWSTR manifestName,LPCWSTR path,DWORD*parsed,DWORD*tables,DWORD*labels,DWORD*noHits){
 WCHAR dec[4096];DWORD mn=0,secA,rowStart,rowCount;make_temp_name(L"rec185_manifest_",*parsed,0,dec);wcat(dec,4096,L".dec");
 if(!expand_manifest(path,dec)){log_manifest_name(manifestName);log_ascii("  NO-ID_SKIP: manifest decode failed");return 1;}
 BYTE*mb=read_all(dec,&mn);if(!mb){DeleteFileW(dec);return 1;}
 if(!parse_manifest(mb,mn,&secA,&rowStart,&rowCount)){log_manifest_name(manifestName);log_ascii("  NO-ID_SKIP: manifest structure not recognized");HeapFree(GetProcessHeap(),0,mb);DeleteFileW(dec);return 1;}
 (*parsed)++;DWORD recCount=rd32(mb,56);char m8[256];int wn=WideCharToMultiByte(CP_UTF8,0,manifestName,-1,m8,255,NULL,NULL);if(wn<=0)m8[0]=0;
 if(recCount<=185){char sk[512];sk[0]=0;a_cat(sk,512,"NO-ID_SKIP | manifest=");a_cat(sk,512,m8);a_cat(sk,512," | records=");a_u32(sk,512,recCount);log_ascii(sk);HeapFree(GetProcessHeap(),0,mb);DeleteFileW(dec);return 1;}
 DWORD rp=secA+185*32;if(rp+32>mn){HeapFree(GetProcessHeap(),0,mb);DeleteFileW(dec);return 1;}
 DWORD chunk=rd32(mb,rp+16),aoff=rd32(mb,rp+20),asz=rd32(mb,rp+24),flags=rd32(mb,rp+28);
 char desc[1024];desc[0]=0;a_cat(desc,1024,"NO-ID_DESCRIPTOR | manifest=");a_cat(desc,1024,m8);a_cat(desc,1024," | record=185 | chunk=");a_u32(desc,1024,chunk);a_cat(desc,1024," | asset_off=");a_u32(desc,1024,aoff);a_cat(desc,1024," | asset_size=");a_u32(desc,1024,asz);a_cat(desc,1024," | flags=");a_u32(desc,1024,flags);log_ascii(desc);
 if(flags!=16||asz<32||asz>262144||chunk>=rowCount){log_ascii("NO-ID_NOT_STRING_TABLE_CANDIDATE");HeapFree(GetProcessHeap(),0,mb);DeleteFileW(dec);return 1;}
 WCHAR cdec[4096];if(!extract_chunk_for_manifest(manifestName,mb,mn,rowStart,rowCount,chunk,cdec)){log_ascii("NO-ID_CHUNK_EXTRACT_FAIL");HeapFree(GetProcessHeap(),0,mb);DeleteFileW(dec);return 1;}
 DWORD dn=0;BYTE*db=read_all(cdec,&dn);DeleteFileW(cdec);if(!db){HeapFree(GetProcessHeap(),0,mb);DeleteFileW(dec);return 1;}
 if(aoff>dn||asz>dn-aoff){log_ascii("NO-ID_ASSET_RANGE_INVALID");HeapFree(GetProcessHeap(),0,db);HeapFree(GetProcessHeap(),0,mb);DeleteFileW(dec);return 1;}
 BYTE*asset=db+aoff;DWORD count=0,offPos=0,base=0;if(!parse_string_table(asset,asz,&count,&offPos,&base)){log_ascii("NO-ID_PARSE_STRING_TABLE_FAIL");HeapFree(GetProcessHeap(),0,db);HeapFree(GetProcessHeap(),0,mb);DeleteFileW(dec);return 1;}
 (*tables)++;char head[800];head[0]=0;a_cat(head,800,"NO-ID_TABLE_FOUND | manifest=");a_cat(head,800,m8);a_cat(head,800," | chunk=");a_u32(head,800,chunk);a_cat(head,800," | record=185 | string_count=");a_u32(head,800,count);log_ascii(head);
 DWORD i,labelCount=0,noCount=0;for(i=0;i<count;i++){
   DWORD a=rd32(asset,offPos+i*4),e=rd32(asset,offPos+(i+1)*4);if(e<=a||base+e>asz)continue;DWORD L=e-a-1;const BYTE*t=asset+base+a;char hx[17],txt[1024],line[1800];idhex8(asset+4+8*i,hx);DWORD cp=L;if(cp>1000)cp=1000;DWORD j;for(j=0;j<cp;j++){BYTE c=t[j];txt[j]=(c>=32&&c<=126)?(char)c:'?';}txt[cp]=0;int kind=exact_label_kind_bytes(t,L);
   line[0]=0;a_cat(line,1800,"NO-ID_SLOT | manifest=");a_cat(line,1800,m8);a_cat(line,1800," | slot=");a_u32(line,1800,i);a_cat(line,1800," | id=");a_cat(line,1800,hx);a_cat(line,1800," | text=");a_cat(line,1800,txt);
   if(kind){a_cat(line,1800," | MARK=LABEL_CANDIDATE:");a_cat(line,1800,label_kind_name(kind));labelCount++;(*labels)++;if(kind==1){noCount++;(*noHits)++;}}
   if(!memcmp(hx,"ff6c7bd9a5af28ef",17))a_cat(line,1800," | MARK=KNOWN_NO_NON_ID");
   if(!memcmp(hx,"f594fe48ea1317b3",17))a_cat(line,1800," | MARK=KNOWN_YES_OUI_ID");
   if(!memcmp(hx,"fe6d7bd9a5af28ef",17))a_cat(line,1800," | MARK=KNOWN_ON_ID");
   if(!memcmp(hx,"e097e848ea1317b3",17))a_cat(line,1800," | MARK=KNOWN_OFF_ID");
   log_ascii(line);
 }
 char sum[800];sum[0]=0;a_cat(sum,800,"NO-ID_SUMMARY | manifest=");a_cat(sum,800,m8);a_cat(sum,800," | label_candidates=");a_u32(sum,800,labelCount);a_cat(sum,800," | exact_No=");a_u32(sum,800,noCount);log_ascii(sum);
 HeapFree(GetProcessHeap(),0,db);HeapFree(GetProcessHeap(),0,mb);DeleteFileW(dec);return 1;
}

#define MAX_NO_CANDIDATES 256

typedef struct LangResolution {
 int found;
 DWORD chunk,record,slot,hits;
 char text[192];
} LangResolution;

typedef struct NoCandidate {
 BYTE noId[8];
 BYTE yesId[8];
 int hasYesPair;
 DWORD esChunk,esRecord,esSlot,esYesSlot,esTableCount,esOccurrences;
 LangResolution deNo,legacyFrNo,currentFrNo;
 LangResolution deYes,legacyFrYes,currentFrYes;
 int score;
} NoCandidate;

static NoCandidate gNoCand[MAX_NO_CANDIDATES];
static DWORD gNoCandCount=0;

static int ascii_eq(const char*a,const char*b){DWORD i=0;if(!a||!b)return 0;while(a[i]&&b[i]){if(a[i]!=b[i])return 0;i++;}return a[i]==0&&b[i]==0;}
static int exact_ascii_raw(const BYTE*t,DWORD L,const char*s){DWORD i=0;while(s[i])i++;if(i!=L)return 0;return memcmp(t,s,L)==0;}
static int exact_spanish_yes(const BYTE*t,DWORD L){return (L==2&&t[0]=='S'&&t[1]=='i')||(L==3&&t[0]=='S'&&t[1]==0xC3&&t[2]==0xAD);}
static void slot_text_ascii(const BYTE*asset,DWORD asz,DWORD offPos,DWORD base,DWORD slot,char*out,DWORD cap){
 DWORD a=rd32(asset,offPos+slot*4),e=rd32(asset,offPos+(slot+1)*4),j,L;if(!cap){return;}out[0]=0;if(e<=a||base+e>asz)return;L=e-a-1;if(L+1>cap)L=cap-1;for(j=0;j<L;j++){BYTE c=asset[base+a+j];out[j]=(c>=32&&c<=126)?(char)c:'?';}out[L]=0;
}
static int find_candidate_by_noid(const BYTE*id){DWORD i;for(i=0;i<gNoCandCount;i++)if(!memcmp(gNoCand[i].noId,id,8))return (int)i;return -1;}
static void copy_resolve(LangResolution*r,DWORD chunk,DWORD record,DWORD slot,const char*txt){if(!r->found){r->found=1;r->chunk=chunk;r->record=record;r->slot=slot;DWORD i=0;while(txt[i]&&i+1<sizeof(r->text)){r->text[i]=txt[i];i++;}r->text[i]=0;}r->hits++;}
static void log_id_bytes(const BYTE*id,char*out){idhex8(id,out);}

static int discover_spanish_no(LPCWSTR manifestName,LPCWSTR path){
 WCHAR dec[4096];DWORD mn=0,secA,rowStart,rowCount;make_temp_name(L"es_no_manifest_",0,0,dec);wcat(dec,4096,L".dec");
 if(!expand_manifest(path,dec)){log_ascii("ES_FATAL: Spanish manifest decode failed");return 0;}BYTE*mb=read_all(dec,&mn);DeleteFileW(dec);if(!mb)return 0;
 if(!parse_manifest(mb,mn,&secA,&rowStart,&rowCount)){log_ascii("ES_FATAL: Spanish manifest structure not recognized");HeapFree(GetProcessHeap(),0,mb);return 0;}
 DWORD recCount=rd32(mb,56),r,ch;BYTE*need=(BYTE*)HeapAlloc(GetProcessHeap(),0,rowCount?rowCount:1);if(!need){HeapFree(GetProcessHeap(),0,mb);return 0;}memset(need,0,rowCount);
 for(r=0;r<recCount;r++){DWORD p=secA+r*32;if(p+32>mn)break;DWORD c=rd32(mb,p+16),asz=rd32(mb,p+24),flags=rd32(mb,p+28);if(c<rowCount&&flags==16&&asz>=32&&asz<=262144)need[c]=1;}
 log_ascii("=== PHASE 1: DISCOVER EXACT SPANISH 'No' IDS ===");
 for(ch=0;ch<rowCount;ch++){if(!need[ch])continue;WCHAR cdec[4096];if(!extract_chunk_for_manifest(manifestName,mb,mn,rowStart,rowCount,ch,cdec))continue;DWORD dn=0;BYTE*db=read_all(cdec,&dn);DeleteFileW(cdec);if(!db)continue;
  for(r=0;r<recCount;r++){DWORD p=secA+r*32;if(p+32>mn)break;if(rd32(mb,p+16)!=ch)continue;DWORD aoff=rd32(mb,p+20),asz=rd32(mb,p+24),flags=rd32(mb,p+28);if(flags!=16||asz<32||asz>262144||aoff>dn||asz>dn-aoff)continue;BYTE*asset=db+aoff;DWORD count,offPos,base;if(!parse_string_table(asset,asz,&count,&offPos,&base))continue;
   int yesSlot=-1;BYTE yesId[8];DWORD i;for(i=0;i<count;i++){DWORD a=rd32(asset,offPos+i*4),e=rd32(asset,offPos+(i+1)*4);if(e<=a||base+e>asz)continue;DWORD L=e-a-1;const BYTE*t=asset+base+a;if(exact_spanish_yes(t,L)){yesSlot=(int)i;memcpy(yesId,asset+4+8*i,8);break;}}
   for(i=0;i<count;i++){DWORD a=rd32(asset,offPos+i*4),e=rd32(asset,offPos+(i+1)*4);if(e<=a||base+e>asz)continue;DWORD L=e-a-1;const BYTE*t=asset+base+a;if(!(L==2&&t[0]=='N'&&t[1]=='o'))continue;BYTE*id=asset+4+8*i;int ci=find_candidate_by_noid(id);if(ci<0){if(gNoCandCount>=MAX_NO_CANDIDATES){log_ascii("ES_WARN: candidate capacity reached");continue;}ci=(int)gNoCandCount++;memset(&gNoCand[ci],0,sizeof(NoCandidate));memcpy(gNoCand[ci].noId,id,8);gNoCand[ci].esChunk=ch;gNoCand[ci].esRecord=r;gNoCand[ci].esSlot=i;gNoCand[ci].esTableCount=count;if(yesSlot>=0){gNoCand[ci].hasYesPair=1;memcpy(gNoCand[ci].yesId,yesId,8);gNoCand[ci].esYesSlot=(DWORD)yesSlot;}}
    gNoCand[ci].esOccurrences++;if(yesSlot>=0&&!gNoCand[ci].hasYesPair){gNoCand[ci].hasYesPair=1;memcpy(gNoCand[ci].yesId,yesId,8);gNoCand[ci].esYesSlot=(DWORD)yesSlot;}
    char noHx[17],yesHx[17],line[1200];log_id_bytes(gNoCand[ci].noId,noHx);line[0]=0;a_cat(line,1200,"ES_NO_FOUND | id=");a_cat(line,1200,noHx);a_cat(line,1200," | chunk=");a_u32(line,1200,ch);a_cat(line,1200," | record=");a_u32(line,1200,r);a_cat(line,1200," | slot=");a_u32(line,1200,i);a_cat(line,1200," | strings=");a_u32(line,1200,count);if(yesSlot>=0){log_id_bytes(yesId,yesHx);a_cat(line,1200," | SAME_TABLE_SI=1 | si_slot=");a_u32(line,1200,(DWORD)yesSlot);a_cat(line,1200," | si_id=");a_cat(line,1200,yesHx);}else a_cat(line,1200," | SAME_TABLE_SI=0");log_ascii(line);
    DWORD lo=i>2?i-2:0,hi=(i+2<count)?i+2:count-1,j;for(j=lo;j<=hi;j++){char tx[256],hx[17],ctx[900];slot_text_ascii(asset,asz,offPos,base,j,tx,256);idhex8(asset+4+8*j,hx);ctx[0]=0;a_cat(ctx,900,"ES_CONTEXT | no_id=");a_cat(ctx,900,noHx);a_cat(ctx,900," | slot=");a_u32(ctx,900,j);a_cat(ctx,900," | id=");a_cat(ctx,900,hx);a_cat(ctx,900," | text=");a_cat(ctx,900,tx);log_ascii(ctx);}
   }
  }
  HeapFree(GetProcessHeap(),0,db);
 }
 HeapFree(GetProcessHeap(),0,need);HeapFree(GetProcessHeap(),0,mb);log_num("ES_UNIQUE_NO_IDS=",gNoCandCount);return 1;
}

static int resolve_manifest_candidates(LPCWSTR manifestName,LPCWSTR path,int role,DWORD*exactCurrentNo){
 WCHAR dec[4096];DWORD mn=0,secA,rowStart,rowCount;make_temp_name(L"resolve_manifest_",(DWORD)role,0,dec);wcat(dec,4096,L".dec");if(!expand_manifest(path,dec)){log_ascii("RESOLVE_SKIP: manifest decode failed");return 0;}BYTE*mb=read_all(dec,&mn);DeleteFileW(dec);if(!mb)return 0;if(!parse_manifest(mb,mn,&secA,&rowStart,&rowCount)){HeapFree(GetProcessHeap(),0,mb);return 0;}
 DWORD recCount=rd32(mb,56),r,ch;BYTE*need=(BYTE*)HeapAlloc(GetProcessHeap(),0,rowCount?rowCount:1);if(!need){HeapFree(GetProcessHeap(),0,mb);return 0;}memset(need,0,rowCount);for(r=0;r<recCount;r++){DWORD p=secA+r*32;if(p+32>mn)break;DWORD c=rd32(mb,p+16),asz=rd32(mb,p+24),flags=rd32(mb,p+28);if(c<rowCount&&flags==16&&asz>=32&&asz<=262144)need[c]=1;}
 for(ch=0;ch<rowCount;ch++){if(!need[ch])continue;WCHAR cdec[4096];if(!extract_chunk_for_manifest(manifestName,mb,mn,rowStart,rowCount,ch,cdec))continue;DWORD dn=0;BYTE*db=read_all(cdec,&dn);DeleteFileW(cdec);if(!db)continue;
  for(r=0;r<recCount;r++){DWORD p=secA+r*32;if(p+32>mn)break;if(rd32(mb,p+16)!=ch)continue;DWORD aoff=rd32(mb,p+20),asz=rd32(mb,p+24),flags=rd32(mb,p+28);if(flags!=16||asz<32||asz>262144||aoff>dn||asz>dn-aoff)continue;BYTE*asset=db+aoff;DWORD count,offPos,base;if(!parse_string_table(asset,asz,&count,&offPos,&base))continue;DWORD i;for(i=0;i<count;i++){DWORD a=rd32(asset,offPos+i*4),e=rd32(asset,offPos+(i+1)*4);if(e<=a||base+e>asz)continue;DWORD L=e-a-1;const BYTE*t=asset+base+a;BYTE*id=asset+4+8*i;char tx[192];slot_text_ascii(asset,asz,offPos,base,i,tx,192);
    if(role==3&&L==2&&t[0]=='N'&&t[1]=='o'){(*exactCurrentNo)++;char hx[17],line[800];idhex8(id,hx);line[0]=0;a_cat(line,800,"CURRENT_FR_EXACT_NO_ANY | id=");a_cat(line,800,hx);a_cat(line,800," | chunk=");a_u32(line,800,ch);a_cat(line,800," | record=");a_u32(line,800,r);a_cat(line,800," | slot=");a_u32(line,800,i);log_ascii(line);}
    DWORD ci;for(ci=0;ci<gNoCandCount;ci++){NoCandidate*c=&gNoCand[ci];if(!memcmp(id,c->noId,8)){LangResolution*rr=(role==1)?&c->deNo:(role==2)?&c->legacyFrNo:&c->currentFrNo;copy_resolve(rr,ch,r,i,tx);}if(c->hasYesPair&&!memcmp(id,c->yesId,8)){LangResolution*rr=(role==1)?&c->deYes:(role==2)?&c->legacyFrYes:&c->currentFrYes;copy_resolve(rr,ch,r,i,tx);}}
  }}HeapFree(GetProcessHeap(),0,db);
 }
 HeapFree(GetProcessHeap(),0,need);HeapFree(GetProcessHeap(),0,mb);return 1;
}

static void append_res(char*line,DWORD cap,const char*name,const LangResolution*r){a_cat(line,cap," | ");a_cat(line,cap,name);a_cat(line,cap,"=");if(!r->found){a_cat(line,cap,"<MISSING>");return;}a_cat(line,cap,r->text);a_cat(line,cap,"@");a_u32(line,cap,r->chunk);a_cat(line,cap,"/");a_u32(line,cap,r->record);a_cat(line,cap,"/");a_u32(line,cap,r->slot);}
static int score_candidate(NoCandidate*c){int s=0;if(c->hasYesPair)s+=2;if(c->deNo.found&&ascii_eq(c->deNo.text,"Nein"))s+=4;if(c->legacyFrNo.found&&ascii_eq(c->legacyFrNo.text,"Non"))s+=4;if(c->currentFrNo.found&&ascii_eq(c->currentFrNo.text,"No"))s+=12;else if(!c->currentFrNo.found)s+=6;else if(ascii_eq(c->currentFrNo.text,"Non"))s-=8;if(c->hasYesPair&&c->currentFrYes.found&&ascii_eq(c->currentFrYes.text,"Oui"))s+=7;if(c->hasYesPair&&c->legacyFrYes.found&&ascii_eq(c->legacyFrYes.text,"Oui"))s+=2;if(c->hasYesPair&&c->deYes.found&&ascii_eq(c->deYes.text,"Ja"))s+=2;return s;}
static const char* cand_status(NoCandidate*c){if(c->currentFrNo.found&&ascii_eq(c->currentFrNo.text,"No"))return "DIRECT_BAD_NO_IN_CURRENT_FR";if(!c->currentFrNo.found&&c->hasYesPair&&c->currentFrYes.found&&ascii_eq(c->currentFrYes.text,"Oui"))return "MISSING_FR_NO_WITH_OUI_PAIR";if(!c->currentFrNo.found)return "MISSING_FR_NEGATIVE";if(ascii_eq(c->currentFrNo.text,"Non"))return "ALREADY_TRANSLATED_NON";return "OTHER";}


#define FILE_ATTRIBUTE_DIRECTORY 0x10
#define IMAGE_SCN_MEM_EXECUTE 0x20000000UL
#define MAX_RANKED 64

typedef struct XrefCandidate {
 int used,score,debugLike,ctxHits;
 DWORD size,noRaw,noRva,directXrefs,rvaRefs,vaRefs,funcBegin,funcEnd;
 char path[512],section[16];
} XrefCandidate;
static XrefCandidate gRanked[MAX_RANKED];
static DWORD gFilesScanned=0,gFilesReadable=0,gFilesWithExactNo=0,gPeParsed=0,gNoLiterals=0,gDirectXrefLiterals=0,gNoXrefLiterals=0,gNonDebugCodeXref=0;

static BYTE lower_ascii(BYTE c){if(c>='A'&&c<='Z')return (BYTE)(c+('a'-'A'));return c;}
static int contains_ascii_ci(const BYTE*b,DWORD n,const char*q){DWORD qn=0,i,j;while(q[qn])qn++;if(!qn||qn>n)return 0;for(i=0;i+qn<=n;i++){for(j=0;j<qn;j++)if(lower_ascii(b[i+j])!=lower_ascii((BYTE)q[j]))break;if(j==qn)return 1;}return 0;}
static int wends_ci(LPCWSTR s,LPCWSTR ext){ULONG_PTR ns=wlen(s),ne=wlen(ext),i;if(ns<ne)return 0;for(i=0;i<ne;i++){WCHAR a=s[ns-ne+i],b=ext[i];if(a>=L'A'&&a<=L'Z')a=(WCHAR)(a+32);if(b>=L'A'&&b<=L'Z')b=(WCHAR)(b+32);if(a!=b)return 0;}return 1;}
static void wide_to_ascii_path(LPCWSTR w,char*out,DWORD cap){if(!cap)return;int n=WideCharToMultiByte(CP_UTF8,0,w,-1,out,(int)cap,NULL,NULL);if(n<=0)out[0]=0;}
static ULONGLONG rd64le(const BYTE*b,DWORD p){ULONGLONG v=0;int i;for(i=7;i>=0;i--)v=(v<<8)|b[p+i];return v;}
static LONG s32(const BYTE*b,DWORD p){return (LONG)rd32(b,p);}

static int pe_info(const BYTE*b,DWORD n,DWORD*pe,DWORD*sec,DWORD*nsec,ULONGLONG*imageBase){
 if(n<0x100||b[0]!='M'||b[1]!='Z')return 0;DWORD e=rd32(b,0x3c);if(e+0x80>n||memcmp(b+e,"PE\0\0",4))return 0;DWORD ns=(DWORD)b[e+6]|((DWORD)b[e+7]<<8),os=(DWORD)b[e+20]|((DWORD)b[e+21]<<8);DWORD op=e+24;if(op+os>n||os<32)return 0;ULONGLONG ib=rd64le(b,op+24);DWORD st=op+os;if(st+ns*40>n)return 0;*pe=e;*sec=st;*nsec=ns;*imageBase=ib;return 1;
}
static int section_name_for_raw(const BYTE*b,DWORD n,DWORD raw,char*out,DWORD cap,DWORD*charsOut){DWORD pe,st,ns,i;ULONGLONG ib;if(!pe_info(b,n,&pe,&st,&ns,&ib))return 0;for(i=0;i<ns;i++){DWORD q=st+i*40,rs=rd32(b,q+16),rp=rd32(b,q+20),vs=rd32(b,q+8);DWORD span=rs>vs?rs:vs;if(raw>=rp&&raw<rp+span){DWORD j=0;while(j<8&&b[q+j]&&j+1<cap){out[j]=(char)b[q+j];j++;}out[j]=0;if(charsOut)*charsOut=rd32(b,q+36);return 1;}}return 0;}
static int raw_to_rva(const BYTE*b,DWORD n,DWORD raw,DWORD*out){DWORD pe,st,ns,i;ULONGLONG ib;if(!pe_info(b,n,&pe,&st,&ns,&ib))return 0;for(i=0;i<ns;i++){DWORD q=st+i*40,rs=rd32(b,q+16),rp=rd32(b,q+20),va=rd32(b,q+12),vs=rd32(b,q+8);DWORD span=rs>vs?rs:vs;if(raw>=rp&&raw<rp+span){*out=va+(raw-rp);return 1;}}return 0;}
static int rva_to_raw(const BYTE*b,DWORD n,DWORD rva,DWORD*out){DWORD pe,st,ns,i;ULONGLONG ib;if(!pe_info(b,n,&pe,&st,&ns,&ib))return 0;for(i=0;i<ns;i++){DWORD q=st+i*40,rs=rd32(b,q+16),rp=rd32(b,q+20),va=rd32(b,q+12),vs=rd32(b,q+8);DWORD span=rs>vs?rs:vs;if(rva>=va&&rva<va+span){DWORD raw=rp+(rva-va);if(raw<n){*out=raw;return 1;}return 0;}}return 0;}
static int get_named_section(const BYTE*b,DWORD n,const char*name,DWORD*raw,DWORD*rs,DWORD*rva,DWORD*chars){DWORD pe,st,ns,i,j;ULONGLONG ib;if(!pe_info(b,n,&pe,&st,&ns,&ib))return 0;for(i=0;i<ns;i++){DWORD q=st+i*40;int ok=1;for(j=0;j<8;j++){char c=(char)b[q+j],d=name[j];if(!d){if(c!=0&&c!=' ')ok=0;break;}if(c!=d){ok=0;break;}}if(ok){*rva=rd32(b,q+12);*rs=rd32(b,q+16);*raw=rd32(b,q+20);if(chars)*chars=rd32(b,q+36);return 1;}}return 0;}
static int printable_cstr_at(const BYTE*b,DWORD n,DWORD raw,char*out,DWORD cap){if(raw>=n||!is_print(b[raw]))return 0;DWORD i=raw,L=0;while(i<n&&is_print(b[i])&&L+1<cap&&L<180){out[L++]=(char)b[i++];}if(i>=n||b[i]!=0||L<2)return 0;out[L]=0;return 1;}
static int str_eq(const char*a,const char*b){DWORD i=0;while(a[i]&&b[i]){if(a[i]!=b[i])return 0;i++;}return a[i]==0&&b[i]==0;}
static int str_has_ci(const char*s,const char*q){DWORD i,j,qn=0;while(q[qn])qn++;if(!qn)return 0;for(i=0;s[i];i++){for(j=0;j<qn&&s[i+j];j++)if(lower_ascii((BYTE)s[i+j])!=lower_ascii((BYTE)q[j]))break;if(j==qn)return 1;}return 0;}
static int function_for_rva(const BYTE*b,DWORD n,DWORD irva,DWORD*beg,DWORD*end){DWORD pr,ps,pv,pc;if(!get_named_section(b,n,".pdata",&pr,&ps,&pv,&pc))return 0;DWORD off;for(off=0;off+12<=ps&&pr+off+12<=n;off+=12){DWORD a=rd32(b,pr+off),e=rd32(b,pr+off+4);if(a&&e>a&&irva>=a&&irva<e){*beg=a;*end=e;return 1;}}return 0;}
static DWORD count_rva32_refs(const BYTE*b,DWORD n,DWORD rva){DWORD i,c=0;for(i=0;i+4<=n;i++)if(rd32(b,i)==rva)c++;return c;}
static DWORD count_va64_refs(const BYTE*b,DWORD n,ULONGLONG va){DWORD i,c=0;for(i=0;i+8<=n;i++)if(rd64le(b,i)==va)c++;return c;}

static int ripref_target_at(const BYTE*b,DWORD n,DWORD x,DWORD textRaw,DWORD textRva,DWORD*targetRva,DWORD*ilen){
 if(x+7<=n&&(b[x]&0xF0)==0x40&&(b[x+1]==0x8D||b[x+1]==0x8B)&&((b[x+2]&0xC7)==0x05)){LONG d=s32(b,x+3);DWORD irva=textRva+(x-textRaw);*targetRva=(DWORD)((LONG)(irva+7)+d);*ilen=7;return 1;}
 if(x+6<=n&&(b[x]==0x8D||b[x]==0x8B)&&((b[x+1]&0xC7)==0x05)){LONG d=s32(b,x+2);DWORD irva=textRva+(x-textRaw);*targetRva=(DWORD)((LONG)(irva+6)+d);*ilen=6;return 1;}
 return 0;
}
static void add_ranked(const char*path,int score,int dbg,int ctx,DWORD size,DWORD noRaw,DWORD noRva,DWORD dx,DWORD rr,DWORD vr,DWORD fb,DWORD fe,const char*sec){
 int slot=-1,minScore=2147483647,minSlot=0,i;for(i=0;i<MAX_RANKED;i++){if(!gRanked[i].used){slot=i;break;}if(gRanked[i].score<minScore){minScore=gRanked[i].score;minSlot=i;}}
 if(slot<0){if(score<=minScore)return;slot=minSlot;}XrefCandidate*c=&gRanked[slot];memset(c,0,sizeof(*c));c->used=1;c->score=score;c->debugLike=dbg;c->ctxHits=ctx;c->size=size;c->noRaw=noRaw;c->noRva=noRva;c->directXrefs=dx;c->rvaRefs=rr;c->vaRefs=vr;c->funcBegin=fb;c->funcEnd=fe;DWORD k=0;while(path[k]&&k+1<sizeof(c->path)){c->path[k]=path[k];k++;}c->path[k]=0;k=0;while(sec[k]&&k+1<sizeof(c->section)){c->section[k]=sec[k];k++;}c->section[k]=0;
}
static int is_debug_string(const char*s){return str_has_ci(s,"%s(%x)")||str_has_ci(s,"Allow Null Free")||str_has_ci(s,"Total Memory")||str_has_ci(s,"Heap Start Address")||str_has_ci(s,"allocations")||str_has_ci(s,"Logging Heap");}
static int is_context_string(const char*s){return str_has_ci(s,"calib")||str_has_ci(s,"reply")||str_has_ci(s,"response")||str_has_ci(s,"choice")||str_has_ci(s,"localizedtext")||str_has_ci(s,"menu")||str_has_ci(s,"What do you think, Jack")||str_has_ci(s,"That won't be necessary")||str_has_ci(s,"Sorry Juno")||str_has_ci(s,"Excellent. I'll queue")||str_has_ci(s,"Shall I run the calibration");}
static void inspect_function_strings(const BYTE*b,DWORD n,DWORD fb,DWORD fe,int*debugLike,int*ctxHits,int*yesRef,int*noRef){
 DWORD tr,ts,tv,tc;if(!get_named_section(b,n,".text",&tr,&ts,&tv,&tc))return;DWORD fr,er;if(!rva_to_raw(b,n,fb,&fr)||!rva_to_raw(b,n,fe-1,&er))return;er++;if(fr<tr||er>tr+ts||er>n||er<=fr)return;DWORD x,logged=0;char seen[32][181];DWORD seenN=0;log_ascii("    FUNCTION_REFERENCED_STRINGS_BEGIN");
 for(x=fr;x<er;){DWORD target,ilen;if(ripref_target_at(b,n,x,tr,tv,&target,&ilen)){DWORD raw;if(rva_to_raw(b,n,target,&raw)){char txt[181];if(printable_cstr_at(b,n,raw,txt,181)){int dup=0;DWORD z;for(z=0;z<seenN;z++)if(str_eq(seen[z],txt)){dup=1;break;}if(!dup){if(seenN<32){DWORD j=0;while(txt[j]&&j<180){seen[seenN][j]=txt[j];j++;}seen[seenN][j]=0;seenN++;}if(is_debug_string(txt))*debugLike=1;if(is_context_string(txt))(*ctxHits)++;if(str_eq(txt,"Yes"))*yesRef=1;if(str_eq(txt,"No"))*noRef=1;if(logged<32){char line[512];line[0]=0;a_cat(line,512,"    FSTR | target_rva=");a_hex8(line,512,target);a_cat(line,512," | ");a_cat(line,512,txt);log_ascii(line);logged++;}}}}x+=ilen;continue;}x++;}
 log_ascii("    FUNCTION_REFERENCED_STRINGS_END");
}
static DWORD find_direct_xrefs(const BYTE*b,DWORD n,DWORD targetRva,DWORD*firstRaw,DWORD*firstRva,DWORD*fb,DWORD*fe,int*dbg,int*ctx,int*yesRef,int*noRef){
 DWORD tr,ts,tv,tc;if(!get_named_section(b,n,".text",&tr,&ts,&tv,&tc)||tr+ts>n)return 0;DWORD x,c=0;for(x=tr;x<tr+ts;){DWORD trg,ilen;if(ripref_target_at(b,n,x,tr,tv,&trg,&ilen)){if(trg==targetRva){DWORD irva=tv+(x-tr),a=0,e=0;char line[512];line[0]=0;a_cat(line,512,"  DIRECT_RIPREL_XREF | raw=");a_hex8(line,512,x);a_cat(line,512," | rva=");a_hex8(line,512,irva);if(function_for_rva(b,n,irva,&a,&e)){a_cat(line,512," | function=");a_hex8(line,512,a);a_cat(line,512,"..");a_hex8(line,512,e);}else a_cat(line,512," | function=<unknown>");log_ascii(line);if(!c){*firstRaw=x;*firstRva=irva;*fb=a;*fe=e;if(a&&e)inspect_function_strings(b,n,a,e,dbg,ctx,yesRef,noRef);}c++;}x+=ilen;continue;}x++;}return c;
}
static void classify_no_literal(const BYTE*b,DWORD n,const char*path,DWORD noRaw,ULONGLONG imageBase){
 DWORD noRva=0,chars=0;char sec[16];sec[0]=0;int mapped=raw_to_rva(b,n,noRaw,&noRva);section_name_for_raw(b,n,noRaw,sec,16,&chars);gNoLiterals++;
 char line[1400];line[0]=0;a_cat(line,1400,"NO_LITERAL | file=");a_cat(line,1400,path);a_cat(line,1400," | raw=");a_hex8(line,1400,noRaw);a_cat(line,1400," | rva=");if(mapped)a_hex8(line,1400,noRva);else a_cat(line,1400,"<unmapped>");a_cat(line,1400," | section=");a_cat(line,1400,sec[0]?sec:"<none>");a_cat(line,1400," | section_exec=");a_u32(line,1400,(chars&IMAGE_SCN_MEM_EXECUTE)?1:0);log_ascii(line);
 if(!mapped){gNoXrefLiterals++;return;}DWORD firstRaw=0,firstRva=0,fb=0,fe=0;int dbg=0,ctx=0,yesRef=0,noRef=0;DWORD dx=find_direct_xrefs(b,n,noRva,&firstRaw,&firstRva,&fb,&fe,&dbg,&ctx,&yesRef,&noRef);DWORD rr=count_rva32_refs(b,n,noRva);DWORD vr=count_va64_refs(b,n,imageBase+(ULONGLONG)noRva);
 int score=0;if(dx)score+=60+(int)(dx>5?25:dx*5);if(rr)score+=rr>8?8:(int)rr;if(vr)score+=vr>8?8:(int)vr;if(sec[0]&&!(chars&IMAGE_SCN_MEM_EXECUTE))score+=5;if(yesRef)score+=20;if(ctx)score+=ctx*15;if(dbg)score-=55;if(chars&IMAGE_SCN_MEM_EXECUTE)score-=15;
 line[0]=0;a_cat(line,1400,"NO_XREF_SUMMARY | file=");a_cat(line,1400,path);a_cat(line,1400," | raw=");a_hex8(line,1400,noRaw);a_cat(line,1400," | direct_riprel=");a_u32(line,1400,dx);a_cat(line,1400," | rva32_refs_all=");a_u32(line,1400,rr);a_cat(line,1400," | va64_refs_all=");a_u32(line,1400,vr);a_cat(line,1400," | function_ctx_hits=");a_u32(line,1400,(DWORD)ctx);a_cat(line,1400," | function_yes_ref=");a_u32(line,1400,(DWORD)yesRef);a_cat(line,1400," | debug_like=");a_u32(line,1400,(DWORD)dbg);a_cat(line,1400," | score=");a_u32(line,1400,(DWORD)(score<0?0:score));log_ascii(line);
 if(dx){gDirectXrefLiterals++;if(!dbg){gNonDebugCodeXref++;log_ascii("  >>> NONDEBUG_CODE_XREF_CANDIDATE");}}else{gNoXrefLiterals++;log_ascii("  >>> NO_DIRECT_CODE_XREF");}
 add_ranked(path,score,dbg,ctx,n,noRaw,noRva,dx,rr,vr,fb,fe,sec);
}
static int scan_live_binary_xrefs(LPCWSTR path){ULONGLONG sz64=0;if(!fsize(path,&sz64)||!sz64||sz64>48ULL*1024ULL*1024ULL)return 1;gFilesScanned++;DWORD n=0;BYTE*b=read_all(path,&n);if(!b)return 1;gFilesReadable++;static const BYTE no0[]={'N','o',0};DWORD count=count_pat(b,n,no0,3);if(!count){HeapFree(GetProcessHeap(),0,b);return 1;}gFilesWithExactNo++;char p8[512];wide_to_ascii_path(path,p8,512);DWORD pe,st,ns;ULONGLONG ib=0;if(!pe_info(b,n,&pe,&st,&ns,&ib)){char l[800];l[0]=0;a_cat(l,800,"PE_PARSE_FAIL_WITH_NO | file=");a_cat(l,800,p8);a_cat(l,800," | count=");a_u32(l,800,count);log_ascii(l);HeapFree(GetProcessHeap(),0,b);return 1;}gPeParsed++;char h[1000];h[0]=0;a_cat(h,1000,"=== PE_NO_FILE | ");a_cat(h,1000,p8);a_cat(h,1000," | size=");a_u32(h,1000,n);a_cat(h,1000," | exact_No0=");a_u32(h,1000,count);a_cat(h,1000," ===");log_ascii(h);DWORD i;for(i=0;i+3<=n;i++)if(!memcmp(b+i,no0,3))classify_no_literal(b,n,p8,i,ib);HeapFree(GetProcessHeap(),0,b);return 1;}
static void scan_dir_recursive_xref(LPCWSTR dir,int depth){if(depth<0)return;WCHAR pat[4096];join(pat,4096,dir,L"*");WIN32_FIND_DATAW fd;HANDLE h=FindFirstFileW(pat,&fd);if(h==INVALID_HANDLE_VALUE)return;do{if(is_dot_name(fd.cFileName))continue;WCHAR p[4096];join(p,4096,dir,fd.cFileName);if(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY){if(depth>0)scan_dir_recursive_xref(p,depth-1);}else if(wends_ci(fd.cFileName,L".dll")||wends_ci(fd.cFileName,L".exe")){scan_live_binary_xrefs(p);}}while(FindNextFileW(h,&fd));FindClose(h);}
static void log_ranking(void){int pass,i;log_ascii("=== TOP NO XREF CANDIDATES ===");for(pass=0;pass<MAX_RANKED;pass++){int best=-1,bs=-2147483647;for(i=0;i<MAX_RANKED;i++)if(gRanked[i].used&&gRanked[i].score>bs){bs=gRanked[i].score;best=i;}if(best<0)break;XrefCandidate*c=&gRanked[best];char line[1600];line[0]=0;a_cat(line,1600,"TOP_XREF_CANDIDATE | score=");a_u32(line,1600,(DWORD)(c->score<0?0:c->score));a_cat(line,1600," | debug_like=");a_u32(line,1600,(DWORD)c->debugLike);a_cat(line,1600," | ctx_hits=");a_u32(line,1600,(DWORD)c->ctxHits);a_cat(line,1600," | direct_riprel=");a_u32(line,1600,c->directXrefs);a_cat(line,1600," | file=");a_cat(line,1600,c->path);a_cat(line,1600," | no_raw=");a_hex8(line,1600,c->noRaw);a_cat(line,1600," | no_rva=");a_hex8(line,1600,c->noRva);a_cat(line,1600," | section=");a_cat(line,1600,c->section);if(c->funcBegin){a_cat(line,1600," | function=");a_hex8(line,1600,c->funcBegin);a_cat(line,1600,"..");a_hex8(line,1600,c->funcEnd);}log_ascii(line);c->used=0;}}



typedef struct MarkerTarget { const WCHAR* file; ULONGLONG size; ULONGLONG raw; BYTE a,b; const char* tag; const char* origSha; } MarkerTarget;
static const MarkerTarget MT[4] = {
 {L"479eb4f3820b04cf.dll",421376ULL,0x0005AF74ULL,'A','1',"A1","291d458803a5b5001abe48f16c3e87a472616bd675669e9c24de3b3ee733bced"},
 {L"4f1ae4956a2ee501.dll",340480ULL,0x000496B4ULL,'B','2',"B2","e398672409ebfa81806e55391b0d6d93406a6e40f096a8411eb25768b4aba860"},
 {L"8ab1694a0629cb9d.dll",347136ULL,0x0004C4D4ULL,'C','3',"C3","ab5d0577521334aa8af4ddfcc46f65f9e1843046cba35956aae4d03e3c829660"},
 {L"925ff81cd4955ba5.dll", 52224ULL,0x0000A884ULL,'D','4',"D4","a2e9812953a6339b2c7ff3703c2ee678c7ec656638f2c8e01576084e0cdb0d0a"}
};
static const WCHAR MARKER_BACKUP_REL[] = L"LE2_FR_Backup_CAL_REPLY_ROUTE_MARKER_R1";
static const WCHAR FINAL_BACKUP_REL[] = L"LE2_FR_Backup_CALIBRATION_NON_R1";
static const int FINAL_IDX=3;

static void live_path(int i,LPWSTR out){WCHAR d[4096];join(d,4096,gGame,L"bin\\win10\\scripts");join(out,4096,d,MT[i].file);} 
static void marker_backup_dir(LPWSTR out){join(out,4096,gGame,MARKER_BACKUP_REL);} 
static void marker_backup_path(int i,LPWSTR out){WCHAR d[4096],n[512];marker_backup_dir(d);wcopy(n,512,MT[i].file);wcat(n,512,L".original");join(out,4096,d,n);} 
static void final_backup_dir(LPWSTR out){join(out,4096,gGame,FINAL_BACKUP_REL);} 
static void final_backup_path(LPWSTR out){WCHAR d[4096],n[512];final_backup_dir(d);wcopy(n,512,MT[FINAL_IDX].file);wcat(n,512,L".original");join(out,4096,d,n);} 
static int bytes_at4(LPCWSTR path,ULONGLONG off,BYTE out[4]){HANDLE h=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return 0;if(!seek64(h,off)){CloseHandle(h);return 0;}int ok=read_exact(h,out,4);CloseHandle(h);return ok;}
static int patch4(LPCWSTR path,ULONGLONG off,const BYTE v[4]){HANDLE h=CreateFileW(path,GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return 0;if(!seek64(h,off)){CloseHandle(h);return 0;}int ok=write_exact(h,v,4);if(ok)ok=FlushFileBuffers(h)?1:0;CloseHandle(h);return ok;}
static void log_target_line(const char* pre,int i,LPCWSTR path){char a[1024],p8[700];wide_to_ascii_path(path,p8,700);a[0]=0;a_cat(a,1024,pre);a_cat(a,1024," | marker=");a_cat(a,1024,MT[i].tag);a_cat(a,1024," | file=");a_cat(a,1024,p8);a_cat(a,1024," | raw=");a_hex8(a,1024,(DWORD)MT[i].raw);log_ascii(a);} 

static int restore_pending_route_markers(void){
 WCHAR bd[4096]; marker_backup_dir(bd); if(!dir_exists(bd)){log_ascii("ROUTE_MARKER_STATE: no pending marker backup detected.");return 1;}
 log_ascii("ROUTE_MARKER_STATE: pending A1/B2/C3/D4 test detected; restoring all four originals before final calibration fix.");
 int i; for(i=0;i<4;i++){WCHAR b[4096],l[4096];ULONGLONG sz=0;BYTE h[32],v[4];marker_backup_path(i,b);live_path(i,l);
   if(!file_exists(b)||!fsize(b,&sz)||sz!=MT[i].size||!sha_file(b,h)||!hex_eq(h,MT[i].origSha)||!bytes_at4(b,MT[i].raw,v)||v[0]!='N'||v[1]!='o'||v[2]!=0){log_target_line("ROUTE_MARKER_BACKUP_INVALID",i,b);return 0;}
 }
 for(i=0;i<4;i++){WCHAR b[4096],l[4096];BYTE a[32],c[32];marker_backup_path(i,b);live_path(i,l);if(!CopyFileW(b,l,FALSE)){log_target_line("ROUTE_MARKER_RESTORE_FAIL",i,l);return 0;}if(!sha_file(b,a)||!sha_file(l,c)||memcmp(a,c,32)){log_target_line("ROUTE_MARKER_RESTORE_VERIFY_FAIL",i,l);return 0;}log_target_line("ROUTE_MARKER_RESTORED",i,l);}
 for(i=0;i<4;i++){WCHAR b[4096];marker_backup_path(i,b);DeleteFileW(b);}RemoveDirectoryW(bd);log_ascii("ROUTE_MARKER_RESTORE_COMPLETE: all four test DLLs restored and marker backup removed.");return 1;
}

static int detect_orphan_markers(void){int i;for(i=0;i<4;i++){WCHAR l[4096];BYTE v[4];live_path(i,l);if(bytes_at4(l,MT[i].raw,v)&&v[0]==MT[i].a&&v[1]==MT[i].b&&v[2]==0){log_target_line("FATAL_ORPHAN_ROUTE_MARKER",i,l);return 1;}}return 0;}

static int apply_final_fix(void){
 WCHAR bd[4096],bp[4096],live[4096];BYTE v[4],h[32];ULONGLONG sz=0;final_backup_dir(bd);final_backup_path(bp);live_path(FINAL_IDX,live);
 if(dir_exists(bd)){
   if(bytes_at4(live,MT[FINAL_IDX].raw,v)&&v[0]=='N'&&v[1]=='o'&&v[2]=='n'&&v[3]==0){log_ascii("INSTALL_OK_ALREADY: calibration reply already reads Non; existing final backup preserved.");return 1;}
   log_ascii("FATAL: final calibration backup already exists but live bytes are not the expected patched Non. Use RESTAURER L'ORIGINAL first.");return 0;
 }
 if(!restore_pending_route_markers())return 0;
 if(detect_orphan_markers()){log_ascii("FATAL: an A1/B2/C3/D4 marker remains but its backup is missing. Restore the route-marker test before installing this final fix.");return 0;}
 if(!fsize(live,&sz)||sz!=MT[FINAL_IDX].size){log_ascii("FATAL: target DLL size mismatch.");return 0;}
 if(!sha_file(live,h)||!hex_eq(h,MT[FINAL_IDX].origSha)){log_ascii("FATAL: target DLL hash is not the validated V0.9.0 original. No write performed.");if(sha_file(live,h))log_hash_line("LIVE_SHA256",h);return 0;}
 if(!bytes_at4(live,MT[FINAL_IDX].raw,v)||v[0]!='N'||v[1]!='o'||v[2]!=0||v[3]!=0){log_ascii("FATAL: exact D4 route bytes are not No\\0\\0. No write performed.");return 0;}
 if(!ensure_dir(bd)){log_ascii("FATAL: cannot create final backup directory.");return 0;}
 if(!CopyFileW(live,bp,TRUE)){log_ascii("FATAL: cannot create exact target DLL backup.");RemoveDirectoryW(bd);return 0;}
 BYTE bh[32];if(!sha_file(bp,bh)||!hex_eq(bh,MT[FINAL_IDX].origSha)){log_ascii("FATAL: final backup verification failed.");DeleteFileW(bp);RemoveDirectoryW(bd);return 0;}log_hash_line("BACKUP_SHA256",bh);
 {const BYTE nv[4]={'N','o','n',0};if(!patch4(live,MT[FINAL_IDX].raw,nv)){log_ascii("PATCH_FAIL: restoring exact backup.");CopyFileW(bp,live,FALSE);return 0;}}
 if(!bytes_at4(live,MT[FINAL_IDX].raw,v)||v[0]!='N'||v[1]!='o'||v[2]!='n'||v[3]!=0){log_ascii("VERIFY_FAIL: restoring exact backup.");CopyFileW(bp,live,FALSE);return 0;}
 if(sha_file(live,h))log_hash_line("PATCHED_SHA256",h);
 log_ascii("TARGET_PROVEN_BY_ROUTE_MARKER: D4 = 925ff81cd4955ba5.dll @ raw 0x0000A884.");
 log_ascii("PATCH_APPLIED: bytes No\\0\\0 -> Non\\0 using existing 4-byte aligned storage; no PE growth and no relocation required.");
 log_ascii("INSTALL_OK: calibration reply label corrected from No to Non. READY R4 and RATIONS untouched.");
 return 1;
}

static int restore_final_fix(void){
 WCHAR bd[4096],bp[4096],live[4096];BYTE h[32],v[4];ULONGLONG sz=0;final_backup_dir(bd);final_backup_path(bp);live_path(FINAL_IDX,live);
 if(!dir_exists(bd)||!file_exists(bp)){log_ascii("RESTORE_NOT_NEEDED: final calibration backup not found.");return 1;}
 if(!fsize(bp,&sz)||sz!=MT[FINAL_IDX].size||!sha_file(bp,h)||!hex_eq(h,MT[FINAL_IDX].origSha)){log_ascii("FATAL: final backup is invalid; refusing restore.");return 0;}
 if(!CopyFileW(bp,live,FALSE)){log_ascii("FATAL: could not restore target DLL.");return 0;}
 BYTE lh[32];if(!sha_file(live,lh)||memcmp(h,lh,32)){log_ascii("FATAL: restored DLL hash verification failed.");return 0;}
 if(!bytes_at4(live,MT[FINAL_IDX].raw,v)||v[0]!='N'||v[1]!='o'||v[2]!=0){log_ascii("FATAL: restored target bytes are not original No.");return 0;}
 DeleteFileW(bp);RemoveDirectoryW(bd);log_ascii("RESTORE_OK: original V0.9.0 target DLL restored exactly; calibration correction removed.");return 1;
}

static int do_probe(int restore){
 log_ascii("LONE ECHO II - FINAL CALIBRATION NON FIX FOR PUBLIC V0.9.0 - R1");
 log_ascii("MODE: TARGETED REVERSIBLE FIX / PROVEN D4 ROUTE");
 log_ascii("OBJECTIVE: replace the exact rendered calibration reply fallback 'No' with 'Non'.");
 log_ascii("PROOF: route marker test rendered D4, mapping directly to 925ff81cd4955ba5.dll raw 0x0000A884.");
 log_ascii("SAFETY: pending A1/B2/C3/D4 markers are auto-restored first; exact DLL backup is made before final write. READY R4 and RATIONS untouched.");
 if(!verify_v090_install()){log_ascii("FATAL: public V0.9.0 installation not detected. No file modified.");return 0;}
 if(restore){log_ascii("CHECKPOINT 03: RESTORE_BEGIN");int ok=restore_final_fix();log_ascii(ok?"CHECKPOINT 04: RESTORE_END_OK":"CHECKPOINT 04: RESTORE_END_FAIL");return ok;}
 log_ascii("CHECKPOINT 03: FINAL_FIX_BEGIN");int ok=apply_final_fix();log_ascii(ok?"CHECKPOINT 04: FINAL_FIX_END_OK":"CHECKPOINT 04: FINAL_FIX_END_FAIL");return ok;
}
static int parse_args(int* restore){LPWSTR c=GetCommandLineW();*restore=0;gGame[0]=0;gReportRoot[0]=0;while(*c){while(*c==L' ')c++;if(!*c)break;WCHAR tok[4096];int k=0,q=0;if(*c==L'\"'){q=1;c++;}while(*c&&((q&&*c!=L'\"')||(!q&&*c!=L' '))&&k<4095)tok[k++]=*c++;tok[k]=0;if(q&&*c==L'\"')c++;if(weq(tok,L"--restore")){*restore=1;continue;}if(weq(tok,L"--game")){while(*c==L' ')c++;k=0;q=0;if(*c==L'\"'){q=1;c++;}while(*c&&((q&&*c!=L'\"')||(!q&&*c!=L' '))&&k<4095)gGame[k++]=*c++;gGame[k]=0;if(q&&*c==L'\"')c++;continue;}if(weq(tok,L"--report-root")){while(*c==L' ')c++;k=0;q=0;if(*c==L'\"'){q=1;c++;}while(*c&&((q&&*c!=L'\"')||(!q&&*c!=L' '))&&k<4095)gReportRoot[k++]=*c++;gReportRoot[k]=0;if(q&&*c==L'\"')c++;continue;}}return gGame[0]&&gReportRoot[0];}
int WINAPI WinMainCRTStartup(void){int restore=0;WCHAR exe[4096],tmp[4096],pid[32];GetModuleFileNameW(NULL,exe,4096);wcopy(gExeDir,4096,exe);parent(gExeDir);join(gZstd,4096,gExeDir,L"zstd.exe");if(!parse_args(&restore))ExitProcess(2);ensure_dir(gReportRoot);join(gReport,4096,gReportRoot,L"Rapport_LoneEcho2_FR_Correctif_Calibration_NON_V0.9.0_R1.txt");DeleteFileW(gReport);log_ascii("CHECKPOINT 01: ENGINE_STARTED");GetTempPathW(4096,tmp);wcopy(gWork,4096,tmp);wcat(gWork,4096,L"LE2FR_V090_CAL_NON_R1_");u32w(GetCurrentProcessId(),pid,32);wcat(gWork,4096,pid);ensure_dir(gWork);if(!file_exists(gZstd)){log_ascii("FATAL: zstd.exe missing from native payload");ExitProcess(3);}log_ascii("CHECKPOINT 02: BEFORE_OPERATION");int ok=do_probe(restore);ExitProcess(ok?0:1);return 0;}
