#define WIN32_LEAN_AND_MEAN 1

typedef unsigned char BYTE; typedef unsigned short WORD; typedef unsigned int UINT; typedef unsigned long DWORD; typedef long LONG; typedef unsigned long ULONG; typedef unsigned long long ULONGLONG; typedef long long LONGLONG; typedef unsigned long long ULONG_PTR; typedef long long LONG_PTR; typedef int BOOL; typedef void* HANDLE; typedef void* HMODULE; typedef void* HINSTANCE; typedef const void* LPCVOID; typedef void* LPVOID; typedef unsigned short WCHAR; typedef WCHAR* LPWSTR; typedef const WCHAR* LPCWSTR; typedef char CHAR; typedef const CHAR* LPCSTR;
typedef union _LARGE_INTEGER { struct { DWORD LowPart; LONG HighPart; }; LONGLONG QuadPart; } LARGE_INTEGER;
typedef struct _STARTUPINFOW { DWORD cb; LPWSTR lpReserved; LPWSTR lpDesktop; LPWSTR lpTitle; DWORD dwX,dwY,dwXSize,dwYSize,dwXCountChars,dwYCountChars,dwFillAttribute,dwFlags; WORD wShowWindow,cbReserved2; BYTE* lpReserved2; HANDLE hStdInput,hStdOutput,hStdError; } STARTUPINFOW;
typedef struct _PROCESS_INFORMATION { HANDLE hProcess,hThread; DWORD dwProcessId,dwThreadId; } PROCESS_INFORMATION;
typedef ULONG_PTR HCRYPTPROV; typedef ULONG_PTR HCRYPTHASH;

#define WINAPI __stdcall
#define NULL ((void*)0)
#define TRUE 1
#define FALSE 0
#define INVALID_HANDLE_VALUE ((HANDLE)(LONG_PTR)-1)
#define GENERIC_READ 0x80000000UL
#define GENERIC_WRITE 0x40000000UL
#define FILE_SHARE_READ 0x1
#define FILE_SHARE_WRITE 0x2
#define OPEN_EXISTING 3
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_NORMAL 0x80
#define FILE_BEGIN 0
#define CREATE_NO_WINDOW 0x08000000
#define STARTF_USESHOWWINDOW 0x00000001
#define SW_HIDE 0
#define INFINITE 0xFFFFFFFFUL
#define MOVEFILE_REPLACE_EXISTING 0x00000001
#define MOVEFILE_WRITE_THROUGH 0x00000008
#define CP_UTF8 65001
#define PROV_RSA_AES 24
#define CRYPT_VERIFYCONTEXT 0xF0000000UL
#define CALG_SHA_256 0x0000800cUL
#define HP_HASHVAL 0x0002
#define FILE_FLAG_WRITE_THROUGH 0x80000000UL

__declspec(dllimport) HANDLE WINAPI CreateFileW(LPCWSTR,DWORD,DWORD,LPVOID,DWORD,DWORD,HANDLE);
__declspec(dllimport) BOOL WINAPI ReadFile(HANDLE,LPVOID,DWORD,DWORD*,LPVOID);
__declspec(dllimport) BOOL WINAPI WriteFile(HANDLE,LPCVOID,DWORD,DWORD*,LPVOID);
__declspec(dllimport) BOOL WINAPI SetFilePointerEx(HANDLE,LARGE_INTEGER,LARGE_INTEGER*,DWORD);
__declspec(dllimport) BOOL WINAPI GetFileSizeEx(HANDLE,LARGE_INTEGER*);
__declspec(dllimport) BOOL WINAPI SetEndOfFile(HANDLE);
__declspec(dllimport) BOOL WINAPI FlushFileBuffers(HANDLE);
__declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
__declspec(dllimport) BOOL WINAPI CreateDirectoryW(LPCWSTR,LPVOID);
__declspec(dllimport) BOOL WINAPI RemoveDirectoryW(LPCWSTR);
__declspec(dllimport) BOOL WINAPI DeleteFileW(LPCWSTR);
__declspec(dllimport) BOOL WINAPI CopyFileW(LPCWSTR,LPCWSTR,BOOL);
__declspec(dllimport) BOOL WINAPI MoveFileExW(LPCWSTR,LPCWSTR,DWORD);
__declspec(dllimport) DWORD WINAPI GetFileAttributesW(LPCWSTR);
__declspec(dllimport) DWORD WINAPI GetLastError(void);
__declspec(dllimport) DWORD WINAPI GetTempPathW(DWORD,LPWSTR);
__declspec(dllimport) DWORD WINAPI GetCurrentProcessId(void);
__declspec(dllimport) DWORD WINAPI GetModuleFileNameW(HMODULE,LPWSTR,DWORD);
__declspec(dllimport) LPWSTR WINAPI GetCommandLineW(void);
__declspec(dllimport) HANDLE WINAPI GetProcessHeap(void);
__declspec(dllimport) LPVOID WINAPI HeapAlloc(HANDLE,DWORD,ULONG_PTR);
__declspec(dllimport) BOOL WINAPI HeapFree(HANDLE,DWORD,LPVOID);
__declspec(dllimport) BOOL WINAPI CreateProcessW(LPCWSTR,LPWSTR,LPVOID,LPVOID,BOOL,DWORD,LPVOID,LPCWSTR,STARTUPINFOW*,PROCESS_INFORMATION*);
__declspec(dllimport) DWORD WINAPI WaitForSingleObject(HANDLE,DWORD);
__declspec(dllimport) BOOL WINAPI GetExitCodeProcess(HANDLE,DWORD*);
__declspec(dllimport) void WINAPI ExitProcess(UINT);
__declspec(dllimport) int WINAPI WideCharToMultiByte(UINT,DWORD,LPCWSTR,int,CHAR*,int,LPCSTR,BOOL*);

__declspec(dllimport) BOOL WINAPI CryptAcquireContextW(HCRYPTPROV*,LPCWSTR,LPCWSTR,DWORD,DWORD);
__declspec(dllimport) BOOL WINAPI CryptCreateHash(HCRYPTPROV,DWORD,ULONG_PTR,DWORD,HCRYPTHASH*);
__declspec(dllimport) BOOL WINAPI CryptHashData(HCRYPTHASH,const BYTE*,DWORD,DWORD);
__declspec(dllimport) BOOL WINAPI CryptGetHashParam(HCRYPTHASH,DWORD,BYTE*,DWORD*,DWORD);
__declspec(dllimport) BOOL WINAPI CryptDestroyHash(HCRYPTHASH);
__declspec(dllimport) BOOL WINAPI CryptReleaseContext(HCRYPTPROV,DWORD);

void* memset(void* d,int c,ULONG_PTR n){BYTE*p=(BYTE*)d;while(n--)*p++=(BYTE)c;return d;}
void* memcpy(void* d,const void*s,ULONG_PTR n){BYTE*dd=(BYTE*)d;const BYTE*ss=(const BYTE*)s;while(n--)*dd++=*ss++;return d;}
int memcmp(const void*a,const void*b,ULONG_PTR n){const BYTE*x=(const BYTE*)a,*y=(const BYTE*)b;while(n--){if(*x!=*y)return *x<*y?-1:1;x++;y++;}return 0;}

static const WCHAR VERSION[] = L"V0.9.0 RESIDUS FINAUX R2";
static const WCHAR MANIFEST_NAME[] = L"ff715342fa4b2d8f";
static const WCHAR MANIFEST_REL[] = L"_data\\5932408047\\rad16\\win10\\manifests\\ff715342fa4b2d8f";
static const WCHAR PACKAGES_REL[] = L"_data\\5932408047\\rad16\\win10\\packages";
static const WCHAR NATIVE_BACKUP_REL[] = L"LE2_FR_V090_RESIDUS_FINAUX_R1_BACKUP";
static const WCHAR V090_STATE_REL[] = L"LE2_FR_V0.9.0_STATE.txt";
static const BYTE BACKUP_MAGIC[8]={'L','E','2','F','R','R','0','1'};

typedef struct PatchTarget { DWORD chunk,record,slot; const char* idhex; const char* oldText; const char* newText; } PatchTarget;
static const PatchTarget T[15] = {
 {31,79,7,"f4fe446fda231fc8","Continue","Continuer"},
 {38,30,42,"80993080368dcf1e","Stop.","Arr\xC3\xAAtez."},
 {38,204,265,"e0feb9b2afa42a0c","Stop.","Arr\xC3\xAAtez."},
 {58,81,168,"0e55fe42336cf2f1","Continue","Continuer"},
 {58,117,0,"8215e747d9d59784","PRIMARY BOOSTERS","PROPULSEURS PRINCIPAUX"},
 {58,117,1,"4687e39a9eb3d68f","MANEUVERING THRUSTERS","PROPULSEURS DE MANOEUVRE"},
 {58,117,3,"56b775650aa24ca8","MANUAL DEXTERITY","DEXTERITE MANUELLE"},
 {58,117,4,"c08b36cb304a1bac","BASIC MOTOR FUNCTIONS","FONCTIONS MOTRICES DE BASE"},
 {58,117,7,"b066eb30682ce9e3","BRAKING THRUSTERS","PROPULSEURS DE FREINAGE"},
 {58,117,10,"0ccd00cc01029d2b","DATA INTERFACES","INTERFACES DE DONNEES"},
 {80,69,85,"038985cac13244bf","Stop.","Arr\xC3\xAAtez."},
 {80,148,238,"247302f08d3febd4","Stop.","Arr\xC3\xAAtez."},
 {119,91,34,"06c654c1367ac568","Interfaces data","Interfaces de donn\xC3\xA9" "es"},
 {134,40,55,"cfbef66e7edc5f21","Oh?","Oh ?"},
 {134,151,41,"bd44d47b5c2d9f9c","Stop.","Arr\xC3\xAAtez."}
};
static const DWORD CHUNKS[6]={31,38,58,80,119,134};
typedef struct BackupState { BYTE magic[8]; ULONGLONG pkgSize; BYTE manifestSha[32]; } BackupState;

static WCHAR gGame[4096], gReportRoot[4096], gExeDir[4096], gWork[4096], gReport[4096], gZstd[4096];

static ULONG_PTR wlen(LPCWSTR s){ULONG_PTR n=0;while(s&&s[n])n++;return n;}
static void wcopy(LPWSTR d,ULONG_PTR c,LPCWSTR s){ULONG_PTR i=0;if(!c)return;while(s&&s[i]&&i+1<c){d[i]=s[i];i++;}d[i]=0;}
static void wcat(LPWSTR d,ULONG_PTR c,LPCWSTR s){ULONG_PTR i=wlen(d),j=0;while(s&&s[j]&&i+1<c)d[i++]=s[j++];d[i]=0;}
static int weq(LPCWSTR a,LPCWSTR b){ULONG_PTR i=0;if(!a||!b)return 0;while(a[i]&&b[i]){if(a[i]!=b[i])return 0;i++;}return a[i]==b[i];}
static void join(LPWSTR o,ULONG_PTR c,LPCWSTR a,LPCWSTR b){wcopy(o,c,a);ULONG_PTR n=wlen(o);if(n&&o[n-1]!=L'\\')wcat(o,c,L"\\");wcat(o,c,b);}
static void parent(LPWSTR p){ULONG_PTR n=wlen(p);while(n){if(p[n-1]==L'\\'||p[n-1]==L'/'){p[n-1]=0;return;}n--;}p[0]=0;}
static void u64w(ULONGLONG v,LPWSTR o,ULONG_PTR c){WCHAR t[32];int n=0;if(!v){wcopy(o,c,L"0");return;}while(v&&n<31){t[n++]=(WCHAR)(L'0'+(v%10));v/=10;}int k=0;while(n&&k+1<(int)c)o[k++]=t[--n];o[k]=0;}
static void u32w(DWORD v,LPWSTR o,ULONG_PTR c){u64w(v,o,c);}
static int file_exists(LPCWSTR p){DWORD a=GetFileAttributesW(p);return a!=0xFFFFFFFFUL && !(a&0x10);}
static int dir_exists(LPCWSTR p){DWORD a=GetFileAttributesW(p);return a!=0xFFFFFFFFUL && (a&0x10);}
static DWORD rd32(const BYTE*b,DWORD p){return (DWORD)b[p]|((DWORD)b[p+1]<<8)|((DWORD)b[p+2]<<16)|((DWORD)b[p+3]<<24);}
static void wr32(BYTE*b,DWORD p,DWORD v){b[p]=(BYTE)v;b[p+1]=(BYTE)(v>>8);b[p+2]=(BYTE)(v>>16);b[p+3]=(BYTE)(v>>24);}
static int hex_eq(const BYTE* h,const char* s){static const char*x="0123456789abcdef";int i;for(i=0;i<32;i++){if(x[(h[i]>>4)&15]!=s[i*2]||x[h[i]&15]!=s[i*2+1])return 0;}return 1;}
static void hexstr(const BYTE*h,char*out){static const char*x="0123456789abcdef";int i;for(i=0;i<32;i++){out[i*2]=x[(h[i]>>4)&15];out[i*2+1]=x[h[i]&15];}out[64]=0;}

static void log_ascii(const char* s){
 HANDLE h=CreateFileW(gReport,GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL); if(h==INVALID_HANDLE_VALUE)h=CreateFileW(gReport,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL); if(h==INVALID_HANDLE_VALUE)return; LARGE_INTEGER sz,li; if(GetFileSizeEx(h,&sz)){li.QuadPart=sz.QuadPart;SetFilePointerEx(h,li,NULL,FILE_BEGIN);} DWORD n=0;while(s[n])n++;DWORD w;WriteFile(h,s,n,&w,NULL);WriteFile(h,"\r\n",2,&w,NULL);FlushFileBuffers(h);CloseHandle(h);
}
static void log_w(LPCWSTR ws){char* b=(char*)HeapAlloc(GetProcessHeap(),0,65536);if(!b)return;int n=WideCharToMultiByte(CP_UTF8,0,ws,-1,b,65535,NULL,NULL);if(n>0)log_ascii(b);HeapFree(GetProcessHeap(),0,b);}
static void log_num(const char* prefix,ULONGLONG v){WCHAR w[128],n[64];int i=0;while(prefix[i]&&i<60){w[i]=(WCHAR)(BYTE)prefix[i];i++;}w[i]=0;u64w(v,n,64);wcat(w,128,n);log_w(w);}

static int read_exact(HANDLE h,void* dst,DWORD n){BYTE*p=(BYTE*)dst;DWORD d=0,r;while(d<n){if(!ReadFile(h,p+d,n-d,&r,NULL)||!r)return 0;d+=r;}return 1;}
static int write_exact(HANDLE h,const void* src,DWORD n){const BYTE*p=(const BYTE*)src;DWORD d=0,w;while(d<n){if(!WriteFile(h,p+d,n-d,&w,NULL)||!w)return 0;d+=w;}return 1;}
static int seek64(HANDLE h,ULONGLONG o){LARGE_INTEGER li;li.QuadPart=(LONGLONG)o;return SetFilePointerEx(h,li,NULL,FILE_BEGIN);}
static int fsize(LPCWSTR p,ULONGLONG* out){HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);LARGE_INTEGER s;if(h==INVALID_HANDLE_VALUE)return 0;BOOL ok=GetFileSizeEx(h,&s);CloseHandle(h);if(ok)*out=(ULONGLONG)s.QuadPart;return ok?1:0;}
static BYTE* read_all(LPCWSTR p,DWORD* out){ULONGLONG s;if(!fsize(p,&s)||s>0x7fffffffULL)return NULL;HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return NULL;BYTE*b=(BYTE*)HeapAlloc(GetProcessHeap(),0,(ULONG_PTR)s+1);if(!b){CloseHandle(h);return NULL;}if(!read_exact(h,b,(DWORD)s)){HeapFree(GetProcessHeap(),0,b);CloseHandle(h);return NULL;}CloseHandle(h);*out=(DWORD)s;return b;}
static int write_all(LPCWSTR p,const BYTE*b,DWORD n){HANDLE h=CreateFileW(p,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);if(h==INVALID_HANDLE_VALUE)return 0;int ok=write_exact(h,b,n);FlushFileBuffers(h);CloseHandle(h);return ok;}
static BYTE* read_range(LPCWSTR p,ULONGLONG off,DWORD n){HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return NULL;BYTE*b=(BYTE*)HeapAlloc(GetProcessHeap(),0,n?n:1);if(!b){CloseHandle(h);return NULL;}if(!seek64(h,off)||!read_exact(h,b,n)){HeapFree(GetProcessHeap(),0,b);CloseHandle(h);return NULL;}CloseHandle(h);return b;}
static int append_bytes(LPCWSTR p,const BYTE*b,DWORD n,ULONGLONG expectedOff){HANDLE h=CreateFileW(p,GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);if(h==INVALID_HANDLE_VALUE)return 0;LARGE_INTEGER s;if(!GetFileSizeEx(h,&s)||(ULONGLONG)s.QuadPart!=expectedOff||!seek64(h,expectedOff)||!write_exact(h,b,n)){CloseHandle(h);return 0;}FlushFileBuffers(h);CloseHandle(h);return 1;}
static int truncate_file(LPCWSTR p,ULONGLONG n){HANDLE h=CreateFileW(p,GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);if(h==INVALID_HANDLE_VALUE)return 0;if(!seek64(h,n)||!SetEndOfFile(h)){CloseHandle(h);return 0;}FlushFileBuffers(h);CloseHandle(h);return 1;}
static int files_equal(LPCWSTR a,LPCWSTR b){ULONGLONG sa,sb;if(!fsize(a,&sa)||!fsize(b,&sb)||sa!=sb)return 0;HANDLE ha=CreateFileW(a,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL),hb=CreateFileW(b,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(ha==INVALID_HANDLE_VALUE||hb==INVALID_HANDLE_VALUE){if(ha!=INVALID_HANDLE_VALUE)CloseHandle(ha);if(hb!=INVALID_HANDLE_VALUE)CloseHandle(hb);return 0;}BYTE* x=(BYTE*)HeapAlloc(GetProcessHeap(),0,1024*1024),*y=(BYTE*)HeapAlloc(GetProcessHeap(),0,1024*1024);if(!x||!y){if(x)HeapFree(GetProcessHeap(),0,x);if(y)HeapFree(GetProcessHeap(),0,y);CloseHandle(ha);CloseHandle(hb);return 0;}ULONGLONG rem=sa;int ok=1;while(rem){DWORD n=rem>1024*1024?1024*1024:(DWORD)rem;if(!read_exact(ha,x,n)||!read_exact(hb,y,n)||memcmp(x,y,n)){ok=0;break;}rem-=n;}HeapFree(GetProcessHeap(),0,x);HeapFree(GetProcessHeap(),0,y);CloseHandle(ha);CloseHandle(hb);return ok;}
static int tail_equals_file(LPCWSTR pkg,ULONGLONG off,LPCWSTR tail){ULONGLONG ts,ps;if(!fsize(tail,&ts)||!fsize(pkg,&ps)||ps!=off+ts)return 0;HANDLE a=CreateFileW(pkg,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL),b=CreateFileW(tail,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(a==INVALID_HANDLE_VALUE||b==INVALID_HANDLE_VALUE){if(a!=INVALID_HANDLE_VALUE)CloseHandle(a);if(b!=INVALID_HANDLE_VALUE)CloseHandle(b);return 0;}if(!seek64(a,off)){CloseHandle(a);CloseHandle(b);return 0;}BYTE*x=(BYTE*)HeapAlloc(GetProcessHeap(),0,262144),*y=(BYTE*)HeapAlloc(GetProcessHeap(),0,262144);if(!x||!y){if(x)HeapFree(GetProcessHeap(),0,x);if(y)HeapFree(GetProcessHeap(),0,y);CloseHandle(a);CloseHandle(b);return 0;}ULONGLONG rem=ts;int ok=1;while(rem){DWORD n=rem>262144?262144:(DWORD)rem;if(!read_exact(a,x,n)||!read_exact(b,y,n)||memcmp(x,y,n)){ok=0;break;}rem-=n;}HeapFree(GetProcessHeap(),0,x);HeapFree(GetProcessHeap(),0,y);CloseHandle(a);CloseHandle(b);return ok;}

static int sha_bytes(const BYTE* d,DWORD n,BYTE out[32]){HCRYPTPROV p=0;HCRYPTHASH h=0;DWORD sz=32;int ok=0;if(!CryptAcquireContextW(&p,NULL,NULL,PROV_RSA_AES,CRYPT_VERIFYCONTEXT))goto done;if(!CryptCreateHash(p,CALG_SHA_256,0,0,&h))goto done;if(n&&!CryptHashData(h,d,n,0))goto done;if(!CryptGetHashParam(h,HP_HASHVAL,out,&sz,0)||sz!=32)goto done;ok=1;done:if(h)CryptDestroyHash(h);if(p)CryptReleaseContext(p,0);return ok;}
static int sha_file(LPCWSTR path,BYTE out[32]){HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return 0;HCRYPTPROV p=0;HCRYPTHASH h=0;BYTE*buf=NULL;DWORD r,sz=32;int ok=0;if(!CryptAcquireContextW(&p,NULL,NULL,PROV_RSA_AES,CRYPT_VERIFYCONTEXT))goto done;if(!CryptCreateHash(p,CALG_SHA_256,0,0,&h))goto done;buf=(BYTE*)HeapAlloc(GetProcessHeap(),0,1024*1024);if(!buf)goto done;for(;;){if(!ReadFile(f,buf,1024*1024,&r,NULL))goto done;if(!r)break;if(!CryptHashData(h,buf,r,0))goto done;}if(!CryptGetHashParam(h,HP_HASHVAL,out,&sz,0)||sz!=32)goto done;ok=1;done:if(buf)HeapFree(GetProcessHeap(),0,buf);if(h)CryptDestroyHash(h);if(p)CryptReleaseContext(p,0);CloseHandle(f);return ok;}

static int ensure_dir(LPCWSTR p){if(dir_exists(p))return 1;return CreateDirectoryW(p,NULL)?1:0;}
static void remove_simple_dir(LPCWSTR dir){WCHAR p[4096];const WCHAR* names[]={L"ff715342fa4b2d8f.original",L"baseline.bin",L"state.txt"};int i;for(i=0;i<3;i++){join(p,4096,dir,names[i]);DeleteFileW(p);}RemoveDirectoryW(dir);}
static int atomic_replace_from_file(LPCWSTR src,LPCWSTR dst){if(!CopyFileW(src,dst,FALSE))return 0;return files_equal(src,dst);}

static int run_process(LPWSTR cmd,LPCWSTR cwd){STARTUPINFOW si;PROCESS_INFORMATION pi;DWORD code=1;memset(&si,0,sizeof(si));memset(&pi,0,sizeof(pi));si.cb=sizeof(si);si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;if(!CreateProcessW(NULL,cmd,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,cwd,&si,&pi))return 0;WaitForSingleObject(pi.hProcess,INFINITE);GetExitCodeProcess(pi.hProcess,&code);CloseHandle(pi.hThread);CloseHandle(pi.hProcess);return code==0;}
static int zstd_decompress(LPCWSTR src,LPCWSTR out){WCHAR cmd[65536];wcopy(cmd,65536,L"\"");wcat(cmd,65536,gZstd);wcat(cmd,65536,L"\" -q -d -f \"");wcat(cmd,65536,src);wcat(cmd,65536,L"\" -o \"");wcat(cmd,65536,out);wcat(cmd,65536,L"\"");return run_process(cmd,gWork);}
static int zstd_compress(LPCWSTR src,LPCWSTR out){WCHAR cmd[65536];wcopy(cmd,65536,L"\"");wcat(cmd,65536,gZstd);wcat(cmd,65536,L"\" -q -19 -f \"");wcat(cmd,65536,src);wcat(cmd,65536,L"\" -o \"");wcat(cmd,65536,out);wcat(cmd,65536,L"\"");return run_process(cmd,gWork);}

static int expand_manifest(LPCWSTR manifest,LPCWSTR out){DWORD n=0;BYTE*b=read_all(manifest,&n);if(!b||n<28){if(b)HeapFree(GetProcessHeap(),0,b);return 0;}if(memcmp(b,"ZSTD",4)){HeapFree(GetProcessHeap(),0,b);return 0;}WCHAR frame[4096];wcopy(frame,4096,out);wcat(frame,4096,L".zst");int ok=write_all(frame,b+24,n-24)&&zstd_decompress(frame,out);HeapFree(GetProcessHeap(),0,b);return ok;}
static int parse_manifest(BYTE*b,DWORD n,DWORD*secA,DWORD*rowStart,DWORD*rowCount){if(n<216)return 0;DWORD secALen=rd32(b,24),c1=rd32(b,56),c2=rd32(b,64),secBLen=rd32(b,88),rc=rd32(b,184);ULONGLONG rs=200ULL+secALen+secBLen;if(secALen!=c1*32||c1!=c2||c1!=382||rc!=155||rs+(ULONGLONG)rc*16>n)return 0;*secA=200;*rowStart=(DWORD)rs;*rowCount=rc;return 1;}
static int build_manifest(LPCWSTR base,const BYTE*dec,DWORD decN,LPCWSTR frame,LPCWSTR out){DWORD bn=0,fn=0;BYTE*bb=read_all(base,&bn),*fb=read_all(frame,&fn);if(!bb||!fb||bn<24){if(bb)HeapFree(GetProcessHeap(),0,bb);if(fb)HeapFree(GetProcessHeap(),0,fb);return 0;}BYTE*o=(BYTE*)HeapAlloc(GetProcessHeap(),0,24+fn);if(!o){HeapFree(GetProcessHeap(),0,bb);HeapFree(GetProcessHeap(),0,fb);return 0;}memcpy(o,bb,24);wr32(o,8,decN);wr32(o,16,fn);memcpy(o+24,fb,fn);int ok=write_all(out,o,24+fn);HeapFree(GetProcessHeap(),0,o);HeapFree(GetProcessHeap(),0,bb);HeapFree(GetProcessHeap(),0,fb);return ok;}

static ULONG_PTR alen(const char*s){ULONG_PTR n=0;while(s&&s[n])n++;return n;}
static int aeqn(const BYTE*b,DWORD n,const char*s){ULONG_PTR m=alen(s);return m==n && (n==0 || memcmp(b,s,n)==0);}
static int hexval(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;}
static int id_eq_hex(const BYTE*id,const char*hex){int i;for(i=0;i<8;i++){int a=hexval(hex[i*2]),b=hexval(hex[i*2+1]);if(a<0||b<0||id[i]!=(BYTE)((a<<4)|b))return 0;}return hex[16]==0;}
static int contains_ascii(const BYTE*b,DWORD n,const char*s){DWORD m=(DWORD)alen(s),i;if(!m||m>n)return 0;for(i=0;i+m<=n;i++)if(!memcmp(b+i,s,m))return 1;return 0;}

static void package_path(DWORD pi,LPWSTR out){WCHAR dir[4096],n[128],num[32];join(dir,4096,gGame,PACKAGES_REL);wcopy(n,128,MANIFEST_NAME);wcat(n,128,L"_");u32w(pi,num,32);wcat(n,128,num);join(out,4096,dir,n);}
static int save_backup_state(LPCWSTR backup,ULONGLONG pkgSize,const BYTE manifestSha[32]){WCHAR p[4096];BackupState st;memset(&st,0,sizeof(st));memcpy(st.magic,BACKUP_MAGIC,8);st.pkgSize=pkgSize;memcpy(st.manifestSha,manifestSha,32);join(p,4096,backup,L"baseline.bin");return write_all(p,(const BYTE*)&st,(DWORD)sizeof(st));}
static int load_backup_state(LPCWSTR backup,BackupState* st){WCHAR p[4096];DWORD n=0;BYTE*b;join(p,4096,backup,L"baseline.bin");b=read_all(p,&n);if(!b||n!=sizeof(BackupState)){if(b)HeapFree(GetProcessHeap(),0,b);return 0;}memcpy(st,b,sizeof(*st));HeapFree(GetProcessHeap(),0,b);return memcmp(st->magic,BACKUP_MAGIC,8)==0;}

static int parse_table(const BYTE*a,DWORD as,DWORD*n,DWORD*offsetPos,DWORD*base){DWORD nn,c2,op,bb,i,prev=0;if(as<16)return 0;nn=rd32(a,0);if(nn<1||nn>5000)return 0;c2=4+8*nn;if(c2+4>as||rd32(a,c2)!=nn)return 0;op=c2+4;bb=op+4*(nn+1);if(bb>as)return 0;for(i=0;i<=nn;i++){DWORD o=rd32(a,op+4*i);if(i==0&&o!=0)return 0;if(i>0&&o<=prev)return 0;prev=o;}if((ULONGLONG)bb+(ULONGLONG)prev!=(ULONGLONG)as)return 0;*n=nn;*offsetPos=op;*base=bb;return 1;}
static int table_slot(const BYTE*a,DWORD as,DWORD n,DWORD op,DWORD base,DWORD slot,const BYTE**txt,DWORD*len){DWORD s,e;if(slot>=n)return 0;s=rd32(a,op+4*slot);e=rd32(a,op+4*(slot+1));if(e<=s||base+e>as||a[base+e-1]!=0)return 0;*txt=a+base+s;*len=e-s-1;return 1;}
static const PatchTarget* target_for_slot(DWORD chunk,DWORD rec,DWORD slot){int i;for(i=0;i<15;i++)if(T[i].chunk==chunk&&T[i].record==rec&&T[i].slot==slot)return &T[i];return NULL;}
static int expected_for_record(DWORD chunk,DWORD rec){int i,n=0;for(i=0;i<15;i++)if(T[i].chunk==chunk&&T[i].record==rec)n++;return n;}

static int rebuild_table(const BYTE*a,DWORD as,DWORD chunk,DWORD rec,BYTE**out,DWORD*outN){DWORD n,op,base,i,newPool=0,newSize,cursor;BYTE*o;int expect=expected_for_record(chunk,rec),seen=0;if(expect<1)return 0;if(!parse_table(a,as,&n,&op,&base)){log_ascii("FATAL: target record is not a valid compact string table");return 0;}
 for(i=0;i<n;i++){const BYTE*t;DWORD tl;const PatchTarget*p=target_for_slot(chunk,rec,i);if(!table_slot(a,as,n,op,base,i,&t,&tl))return 0;if(p){if(!id_eq_hex(a+4+8*i,p->idhex)){log_ascii("FATAL: target ID mismatch");return 0;}if(!aeqn(t,tl,p->oldText)){log_ascii("FATAL: target current text mismatch");return 0;}newPool+=(DWORD)alen(p->newText)+1;seen++;}else newPool+=tl+1;}
 if(seen!=expect){log_ascii("FATAL: not all expected slots were found in target record");return 0;}if((ULONGLONG)base+newPool>0x7fffffffULL)return 0;newSize=base+newPool;o=(BYTE*)HeapAlloc(GetProcessHeap(),0,newSize);if(!o)return 0;memset(o,0,newSize);memcpy(o,a,op);cursor=0;for(i=0;i<n;i++){const BYTE*t;DWORD tl;const PatchTarget*p=target_for_slot(chunk,rec,i);table_slot(a,as,n,op,base,i,&t,&tl);wr32(o,op+4*i,cursor);if(p){DWORD l=(DWORD)alen(p->newText);memcpy(o+base+cursor,p->newText,l);o[base+cursor+l]=0;cursor+=l+1;}else{memcpy(o+base+cursor,t,tl);o[base+cursor+tl]=0;cursor+=tl+1;}}wr32(o,op+4*n,cursor);if(base+cursor!=newSize){HeapFree(GetProcessHeap(),0,o);return 0;}*out=o;*outN=newSize;return 1;}

static int write_chunk_source(LPCWSTR pkg,DWORD off,DWORD cs,LPCWSTR zst){BYTE*b=read_range(pkg,off,cs);int ok;if(!b)return 0;ok=write_all(zst,b,cs);HeapFree(GetProcessHeap(),0,b);return ok;}

static int prepare_chunk(BYTE*mb,DWORD mn,DWORD secA,DWORD rowStart,DWORD rowCount,DWORD chunk,ULONGLONG appendOff,LPCWSTR outZst,DWORD*outCS,DWORD*outUS){DWORD rowp,pi,co,cs,us,dn=0,r,recCount=0,i;WCHAR pkg[4096],srcZ[4096],srcD[4096],newD[4096];BYTE*db=NULL,*nb=NULL;ULONGLONG psz=0,cap,cursor;struct RP{DWORD rec,off,sz,newSz;BYTE*newA;} rp[8];if(chunk>=rowCount)return 0;rowp=rowStart+chunk*16;pi=rd32(mb,rowp);co=rd32(mb,rowp+4);cs=rd32(mb,rowp+8);us=rd32(mb,rowp+12);if(pi!=0){log_ascii("FATAL: target ff715 chunk is not in package index 0");return 0;}package_path(pi,pkg);if(!fsize(pkg,&psz)||(ULONGLONG)co+cs>psz||!cs||!us)return 0;join(srcZ,4096,gWork,L"src_chunk.zst");join(srcD,4096,gWork,L"src_chunk.dec");join(newD,4096,gWork,L"new_chunk.dec");DeleteFileW(srcZ);DeleteFileW(srcD);DeleteFileW(newD);if(!write_chunk_source(pkg,co,cs,srcZ)||!zstd_decompress(srcZ,srcD)){log_ascii("FATAL: target chunk decompression failed");return 0;}db=read_all(srcD,&dn);if(!db||dn!=us){if(db)HeapFree(GetProcessHeap(),0,db);log_ascii("FATAL: target chunk uncompressed size mismatch");return 0;}
 for(r=0;r<382;r++){DWORD d=secA+r*32,rc=rd32(mb,d+16);int wanted=0;if(rc!=chunk)continue;for(i=0;i<15;i++)if(T[i].chunk==chunk&&T[i].record==r){wanted=1;break;}if(!wanted)continue;if(recCount>=8){HeapFree(GetProcessHeap(),0,db);return 0;}rp[recCount].rec=r;rp[recCount].off=rd32(mb,d+20);rp[recCount].sz=rd32(mb,d+24);rp[recCount].newA=NULL;rp[recCount].newSz=0;if(!rp[recCount].sz||(ULONGLONG)rp[recCount].off+rp[recCount].sz>dn){HeapFree(GetProcessHeap(),0,db);log_ascii("FATAL: target asset range invalid");return 0;}if(!rebuild_table(db+rp[recCount].off,rp[recCount].sz,chunk,r,&rp[recCount].newA,&rp[recCount].newSz)){for(i=0;i<recCount;i++)if(rp[i].newA)HeapFree(GetProcessHeap(),0,rp[i].newA);HeapFree(GetProcessHeap(),0,db);return 0;}recCount++;}
 if(recCount==0){HeapFree(GetProcessHeap(),0,db);log_ascii("FATAL: no target records found for expected chunk");return 0;}cap=dn+32;for(i=0;i<recCount;i++)cap+=(ULONGLONG)rp[i].newSz+16;if(cap>0x7fffffffULL){for(i=0;i<recCount;i++)HeapFree(GetProcessHeap(),0,rp[i].newA);HeapFree(GetProcessHeap(),0,db);return 0;}nb=(BYTE*)HeapAlloc(GetProcessHeap(),0,(ULONG_PTR)cap);if(!nb){for(i=0;i<recCount;i++)HeapFree(GetProcessHeap(),0,rp[i].newA);HeapFree(GetProcessHeap(),0,db);return 0;}memset(nb,0,(ULONG_PTR)cap);memcpy(nb,db,dn);cursor=dn;for(i=0;i<recCount;i++){DWORD d;cursor=(cursor+15ULL)&~15ULL;if(cursor+rp[i].newSz>cap){HeapFree(GetProcessHeap(),0,nb);for(r=0;r<recCount;r++)HeapFree(GetProcessHeap(),0,rp[r].newA);HeapFree(GetProcessHeap(),0,db);return 0;}memcpy(nb+(DWORD)cursor,rp[i].newA,rp[i].newSz);d=secA+rp[i].rec*32;wr32(mb,d+20,(DWORD)cursor);wr32(mb,d+24,rp[i].newSz);log_num("  relocated record=",rp[i].rec);log_num("    new_asset_off=",cursor);log_num("    new_asset_size=",rp[i].newSz);cursor+=rp[i].newSz;}
 *outUS=(DWORD)cursor;if(!write_all(newD,nb,*outUS)||!zstd_compress(newD,outZst)){HeapFree(GetProcessHeap(),0,nb);for(i=0;i<recCount;i++)HeapFree(GetProcessHeap(),0,rp[i].newA);HeapFree(GetProcessHeap(),0,db);return 0;}if(!fsize(outZst,&psz)||psz>0xffffffffULL){HeapFree(GetProcessHeap(),0,nb);for(i=0;i<recCount;i++)HeapFree(GetProcessHeap(),0,rp[i].newA);HeapFree(GetProcessHeap(),0,db);return 0;}*outCS=(DWORD)psz;if(appendOff+*outCS>0xffffffffULL){HeapFree(GetProcessHeap(),0,nb);for(i=0;i<recCount;i++)HeapFree(GetProcessHeap(),0,rp[i].newA);HeapFree(GetProcessHeap(),0,db);return 0;}wr32(mb,rowp+4,(DWORD)appendOff);wr32(mb,rowp+8,*outCS);wr32(mb,rowp+12,*outUS);HeapFree(GetProcessHeap(),0,nb);for(i=0;i<recCount;i++)HeapFree(GetProcessHeap(),0,rp[i].newA);HeapFree(GetProcessHeap(),0,db);DeleteFileW(srcZ);DeleteFileW(srcD);DeleteFileW(newD);return 1;}

static int verify_chunk_targets(BYTE*mb,DWORD secA,DWORD rowStart,DWORD rowCount,DWORD chunk){DWORD rowp,pi,co,cs,us,dn=0,i;WCHAR pkg[4096],z[4096],d[4096];BYTE*db=NULL;if(chunk>=rowCount)return 0;rowp=rowStart+chunk*16;pi=rd32(mb,rowp);co=rd32(mb,rowp+4);cs=rd32(mb,rowp+8);us=rd32(mb,rowp+12);package_path(pi,pkg);join(z,4096,gWork,L"verify_chunk.zst");join(d,4096,gWork,L"verify_chunk.dec");DeleteFileW(z);DeleteFileW(d);if(!write_chunk_source(pkg,co,cs,z)||!zstd_decompress(z,d))return 0;db=read_all(d,&dn);if(!db||dn!=us){if(db)HeapFree(GetProcessHeap(),0,db);return 0;}for(i=0;i<15;i++){DWORD rd,ao,az,n,op,base;const BYTE*t;DWORD tl;if(T[i].chunk!=chunk)continue;rd=secA+T[i].record*32;if(rd+32>0x7fffffffU){HeapFree(GetProcessHeap(),0,db);return 0;}if(rd32(mb,rd+16)!=chunk){HeapFree(GetProcessHeap(),0,db);return 0;}ao=rd32(mb,rd+20);az=rd32(mb,rd+24);if(!az||(ULONGLONG)ao+az>dn||!parse_table(db+ao,az,&n,&op,&base)||T[i].slot>=n||!id_eq_hex(db+ao+4+8*T[i].slot,T[i].idhex)||!table_slot(db+ao,az,n,op,base,T[i].slot,&t,&tl)||!aeqn(t,tl,T[i].newText)){HeapFree(GetProcessHeap(),0,db);log_ascii("VERIFY_FAIL: one patched slot did not match expected French text");return 0;}}
 HeapFree(GetProcessHeap(),0,db);DeleteFileW(z);DeleteFileW(d);return 1;}

static int restore_backup_dir(LPCWSTR backup,int removeAfter){BackupState st;WCHAR bm[4096],liveM[4096],pkg[4096];BYTE h[32];ULONGLONG s=0;if(!load_backup_state(backup,&st)){log_ascii("RESTORE_FATAL: backup state invalid");return 0;}join(bm,4096,backup,L"ff715342fa4b2d8f.original");join(liveM,4096,gGame,MANIFEST_REL);package_path(0,pkg);if(!file_exists(bm)||!truncate_file(pkg,st.pkgSize)){log_ascii("RESTORE_FATAL: package truncate failed");return 0;}if(!CopyFileW(bm,liveM,FALSE)||!files_equal(bm,liveM)){log_ascii("RESTORE_FATAL: manifest restore failed");return 0;}if(!fsize(pkg,&s)||s!=st.pkgSize){log_ascii("RESTORE_FATAL: restored package size mismatch");return 0;}if(!sha_file(liveM,h)||memcmp(h,st.manifestSha,32)){log_ascii("RESTORE_FATAL: restored manifest hash mismatch");return 0;}if(removeAfter)remove_simple_dir(backup);return 1;}

static int validate_state(void){WCHAR p[4096];DWORD n=0;BYTE*b;join(p,4096,gGame,V090_STATE_REL);if(!file_exists(p))return 0;b=read_all(p,&n);if(!b)return 0;int ok=contains_ascii(b,n,"Version=V0.9.0");HeapFree(GetProcessHeap(),0,b);return ok;}

static int verify_live_install(LPCWSTR liveM){
 WCHAR vd[4096];DWORD vn=0,va,vr,vc,i;BYTE*vb;
 join(vd,4096,gWork,L"verify_existing_manifest.dec");DeleteFileW(vd);
 if(!expand_manifest(liveM,vd)){log_ascii("VERIFY_EXISTING_FAIL: manifest decompress failed");return 0;}
 vb=read_all(vd,&vn);if(!vb||!parse_manifest(vb,vn,&va,&vr,&vc)){if(vb)HeapFree(GetProcessHeap(),0,vb);log_ascii("VERIFY_EXISTING_FAIL: manifest structure failed");return 0;}
 for(i=0;i<6;i++)if(!verify_chunk_targets(vb,va,vr,vc,CHUNKS[i])){HeapFree(GetProcessHeap(),0,vb);log_ascii("VERIFY_EXISTING_FAIL: at least one of the 15 live targets is not patched as expected");return 0;}
 HeapFree(GetProcessHeap(),0,vb);log_ascii("ALREADY_INSTALLED_OK: 15/15 corrections are already present and verified live. No game file rewritten by R2.");return 1;
}

static int do_install(void){WCHAR liveM[4096],pkg[4096],decM[4096],newDecM[4096],newFrame[4096],newM[4096],backup[4096],bm[4096],stp[4096];BYTE*mb=NULL;DWORD mn=0,secA,rowStart,rowCount,i,newCS[6],newUS[6];WCHAR newZ[6][4096];ULONGLONG pkgBase=0,appendOff;BYTE manifestSha[32];int wrote=0;log_ascii("LONE ECHO II - CORRECTIF RESIDUS FINAUX V0.9.0 R2");log_ascii("15 corrections sûres / ff715 uniquement / RATIONS exclu / READY et Calibration Non intacts");if(!validate_state()){log_ascii("FATAL: marqueur V0.9.0 absent ou incompatible");return 0;}join(liveM,4096,gGame,MANIFEST_REL);package_path(0,pkg);join(backup,4096,gGame,NATIVE_BACKUP_REL);if(dir_exists(backup)){log_ascii("INFO: sauvegarde R1/R2 détectée; vérification idempotente de l'installation existante.");if(!file_exists(liveM)||!file_exists(pkg)){log_ascii("FATAL: ff715 manifest/package introuvable");return 0;}return verify_live_install(liveM);}if(!file_exists(liveM)||!file_exists(pkg)||!fsize(pkg,&pkgBase)||pkgBase>0xffffffffULL){log_ascii("FATAL: ff715 manifest/package introuvable ou taille incompatible");return 0;}if(!sha_file(liveM,manifestSha)){log_ascii("FATAL: hash manifest impossible");return 0;}join(decM,4096,gWork,L"ff715_manifest.dec");join(newDecM,4096,gWork,L"ff715_manifest_new.dec");join(newFrame,4096,gWork,L"ff715_manifest_new.zst");join(newM,4096,gWork,L"ff715342fa4b2d8f.new");if(!expand_manifest(liveM,decM)){log_ascii("FATAL: décompression du manifest ff715 impossible");return 0;}mb=read_all(decM,&mn);if(!mb||!parse_manifest(mb,mn,&secA,&rowStart,&rowCount)){if(mb)HeapFree(GetProcessHeap(),0,mb);log_ascii("FATAL: structure ff715 inattendue (attendu 382 records / 155 chunks)");return 0;}appendOff=pkgBase;log_num("BASE_PACKAGE_SIZE=",pkgBase);for(i=0;i<6;i++){WCHAR num[32];u32w(CHUNKS[i],num,32);join(newZ[i],4096,gWork,L"patched_chunk_");wcat(newZ[i],4096,num);wcat(newZ[i],4096,L".zst");DeleteFileW(newZ[i]);log_num("PREPARE_CHUNK=",CHUNKS[i]);if(!prepare_chunk(mb,mn,secA,rowStart,rowCount,CHUNKS[i],appendOff,newZ[i],&newCS[i],&newUS[i])){log_ascii("FATAL: préparation d'un chunk cible échouée. Aucun fichier jeu modifié.");goto fail;}appendOff+=newCS[i];}
 if(!write_all(newDecM,mb,mn)||!zstd_compress(newDecM,newFrame)||!build_manifest(liveM,mb,mn,newFrame,newM)){log_ascii("FATAL: préparation du nouveau manifest échouée. Aucun fichier jeu modifié.");goto fail;}if(!ensure_dir(backup)){log_ascii("FATAL: création sauvegarde impossible");goto fail;}join(bm,4096,backup,L"ff715342fa4b2d8f.original");if(!CopyFileW(liveM,bm,FALSE)||!files_equal(liveM,bm)||!save_backup_state(backup,pkgBase,manifestSha)){log_ascii("FATAL: sauvegarde baseline échouée");goto fail_backup;}join(stp,4096,backup,L"state.txt");{const char*s="Lone Echo II Final Residual Fix V0.9.0 R2 (R1-compatible backup)\r\nTargets=15 safe visible/localized residues\r\nManifest=ff715342fa4b2d8f\r\nRestore=original manifest + package truncation\r\nRATIONS=untouched\r\n";write_all(stp,(const BYTE*)s,(DWORD)alen(s));}
 log_ascii("BACKUP_OK: début des écritures append-only package");appendOff=pkgBase;for(i=0;i<6;i++){DWORD n=0;BYTE*b=read_all(newZ[i],&n);if(!b||n!=newCS[i]||!append_bytes(pkg,b,n,appendOff)){if(b)HeapFree(GetProcessHeap(),0,b);log_ascii("INSTALL_ERROR: append chunk échoué");goto rollback;}HeapFree(GetProcessHeap(),0,b);appendOff+=n;wrote=1;}if(!atomic_replace_from_file(newM,liveM)){log_ascii("INSTALL_ERROR: commit manifest échoué");goto rollback;}log_ascii("MANIFEST_COMMIT_OK");
 {WCHAR vd[4096];DWORD vn=0,va,vr,vc;BYTE*vb;join(vd,4096,gWork,L"verify_manifest.dec");if(!expand_manifest(liveM,vd)){log_ascii("INSTALL_ERROR: verify manifest decompress failed");goto rollback;}vb=read_all(vd,&vn);if(!vb||!parse_manifest(vb,vn,&va,&vr,&vc)){if(vb)HeapFree(GetProcessHeap(),0,vb);log_ascii("INSTALL_ERROR: verify manifest structure failed");goto rollback;}for(i=0;i<6;i++)if(!verify_chunk_targets(vb,va,vr,vc,CHUNKS[i])){HeapFree(GetProcessHeap(),0,vb);log_ascii("INSTALL_ERROR: vérification live d'un chunk échouée");goto rollback;}HeapFree(GetProcessHeap(),0,vb);}
 HeapFree(GetProcessHeap(),0,mb);log_ascii("INSTALL_OK: 15/15 corrections vérifiées dans les tables françaises actives.");log_ascii("UNCHANGED: Calibration Non R1, READY/6242, RATIONS, DLL scripts.");return 1;
rollback: log_ascii("ROLLBACK: restauration baseline ff715 en cours");if(dir_exists(backup)&&restore_backup_dir(backup,0))log_ascii("ROLLBACK_OK");else log_ascii("ROLLBACK_ERROR: sauvegarde conservée pour restauration manuelle");goto fail;
fail_backup: remove_simple_dir(backup);
fail: if(mb)HeapFree(GetProcessHeap(),0,mb);(void)wrote;return 0;}

static int do_restore(void){WCHAR b[4096];log_ascii("LONE ECHO II - RESTAURATION CORRECTIF RESIDUS FINAUX R2");join(b,4096,gGame,NATIVE_BACKUP_REL);if(!dir_exists(b)){log_ascii("RESTORE_FATAL: sauvegarde R1/R2 introuvable");return 0;}if(!restore_backup_dir(b,1))return 0;log_ascii("RESTORE_OK: ff715 restauré exactement dans son état pré-correctif. Calibration Non et autres correctifs externes sont inchangés.");return 1;}

static int parse_args(int* restore){LPWSTR c=GetCommandLineW();*restore=0;gGame[0]=0;gReportRoot[0]=0;while(*c){while(*c==L' ')c++;if(!*c)break;WCHAR tok[4096];int k=0,q=0;if(*c==L'\"'){q=1;c++;}while(*c&&((q&&*c!=L'\"')||(!q&&*c!=L' '))&&k<4095)tok[k++]=*c++;tok[k]=0;if(q&&*c==L'\"')c++;if(weq(tok,L"--restore")){*restore=1;continue;}if(weq(tok,L"--game")){while(*c==L' ')c++;k=0;q=0;if(*c==L'\"'){q=1;c++;}while(*c&&((q&&*c!=L'\"')||(!q&&*c!=L' '))&&k<4095)gGame[k++]=*c++;gGame[k]=0;if(q&&*c==L'\"')c++;continue;}if(weq(tok,L"--report-root")){while(*c==L' ')c++;k=0;q=0;if(*c==L'\"'){q=1;c++;}while(*c&&((q&&*c!=L'\"')||(!q&&*c!=L' '))&&k<4095)gReportRoot[k++]=*c++;gReportRoot[k]=0;if(q&&*c==L'\"')c++;continue;}}return gGame[0]&&gReportRoot[0];}

int WINAPI WinMainCRTStartup(void){int restore=0;WCHAR exe[4096],tmp[4096],pid[32];GetModuleFileNameW(NULL,exe,4096);wcopy(gExeDir,4096,exe);parent(gExeDir);join(gZstd,4096,gExeDir,L"zstd.exe");if(!parse_args(&restore))ExitProcess(2);ensure_dir(gReportRoot);join(gReport,4096,gReportRoot,L"Rapport_LoneEcho2_FR_Correctif_ResidusFinaux_V0.9.0_R2.txt");DeleteFileW(gReport);GetTempPathW(4096,tmp);wcopy(gWork,4096,tmp);wcat(gWork,4096,L"LE2FR_V090_RESIDUS_R2_");u32w(GetCurrentProcessId(),pid,32);wcat(gWork,4096,pid);ensure_dir(gWork);if(!file_exists(gZstd)){log_ascii("FATAL: zstd.exe manquant du payload");ExitProcess(3);}int ok=restore?do_restore():do_install();ExitProcess(ok?0:1);return 0;}
