# Lone Echo II — Correctif Résidus finaux V0.9.0 R2

Correctif ciblé construit à partir de l'audit `ActiveFrenchTableResidualAudit V0.9.0 R3`.

Il corrige uniquement 15 résidus validés dans `ff715342fa4b2d8f`, répartis sur 10 records / 6 chunks. Les chaînes internes ou développeur hors corpus ne sont pas modifiées. RATIONS, READY/6242 et les DLL scripts sont hors périmètre.

Architecture : EXE portable Win32 x64 + moteur natif x64 + zstd. Les assets reconstruits sont appendus aux chunks, les chunks sont appendus au package, et le manifest est redirigé après sauvegarde. Aucun ancien asset n'est écrasé en place.


R2 corrige le bug du launcher R1 qui cherchait le nom de rapport du correctif Calibration Non. Si R1 est déjà installé, R2 ne réapplique rien : il vérifie les 15/15 cibles en live et produit le rapport normal. La sauvegarde R1 est volontairement réutilisée pour compatibilité et restauration exacte.
