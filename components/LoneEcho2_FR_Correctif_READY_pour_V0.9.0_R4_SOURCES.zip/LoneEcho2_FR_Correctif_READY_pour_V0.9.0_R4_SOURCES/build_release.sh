#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$ROOT/build"
mkdir -p "$BUILD"
for d in kernel32 advapi32 user32 gdi32 shell32 ole32; do
  lld-link /dll /noentry /machine:x64 /def:"$ROOT/defs/$d.def" /out:"$BUILD/$d-dummy.dll" /implib:"$BUILD/$d.lib"
done
clang-cl --target=x86_64-pc-windows-msvc /c /O2 /GS- /utf-8 /Fo:"$BUILD/native_engine.obj" "$ROOT/src/native_engine.c"
clang --target=x86_64-pc-windows-msvc -c "$ROOT/src/chkstk.s" -o "$BUILD/chkstk.obj"
lld-link /out:"$ROOT/payload/LE2FR_ReadyFix_V0.9.0_R4_Engine.exe" /subsystem:windows /entry:WinMainCRTStartup /nodefaultlib /machine:x64 /stack:4194304 /opt:ref /opt:icf "$BUILD/native_engine.obj" "$BUILD/chkstk.obj" "$BUILD/kernel32.lib" "$BUILD/advapi32.lib"
cp "$ROOT/assets/ui_skin_1672x941.bgra" "$BUILD/skin.bgra"
( cd "$BUILD" && objcopy -I binary -O pe-x86-64 -B i386:x86-64 skin.bgra skin.obj )
clang-cl --target=x86_64-pc-windows-msvc /c /O2 /GS- /utf-8 /Fo:"$BUILD/portable_ui.obj" "$ROOT/src/portable_ui.c"
clang --target=x86_64-pc-windows-msvc -c "$ROOT/src/chkstk.s" -o "$BUILD/chkstk_ui.obj"
lld-link /out:"$BUILD/stub.exe" /subsystem:windows /entry:WinMainCRTStartup /nodefaultlib /machine:x64 /stack:4194304 /opt:ref /opt:icf "$BUILD/portable_ui.obj" "$BUILD/chkstk_ui.obj" "$BUILD/skin.obj" "$BUILD/kernel32.lib" "$BUILD/user32.lib" "$BUILD/gdi32.lib" "$BUILD/shell32.lib" "$BUILD/advapi32.lib" "$BUILD/ole32.lib"
python "$ROOT/tools/pack_payload.py" "$BUILD/stub.exe" "$ROOT/payload" "$BUILD/LoneEcho2_FR_Correctif_READY_pour_V0.9.0_R4.exe"
sha256sum "$BUILD/LoneEcho2_FR_Correctif_READY_pour_V0.9.0_R4.exe"
