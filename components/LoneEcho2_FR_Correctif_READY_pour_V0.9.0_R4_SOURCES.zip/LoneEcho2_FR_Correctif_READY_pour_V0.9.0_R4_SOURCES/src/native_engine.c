#define WIN32_LEAN_AND_MEAN 1

typedef unsigned char BYTE; typedef unsigned short WORD; typedef unsigned int UINT; typedef unsigned long DWORD; typedef long LONG; typedef unsigned long ULONG; typedef unsigned long long ULONGLONG; typedef long long LONGLONG; typedef unsigned long long ULONG_PTR; typedef long long LONG_PTR; typedef int BOOL; typedef void* HANDLE; typedef void* HMODULE; typedef void* HINSTANCE; typedef const void* LPCVOID; typedef void* LPVOID; typedef unsigned short WCHAR; typedef WCHAR* LPWSTR; typedef const WCHAR* LPCWSTR; typedef char CHAR; typedef const CHAR* LPCSTR;
typedef union _LARGE_INTEGER { struct { DWORD LowPart; LONG HighPart; }; LONGLONG QuadPart; } LARGE_INTEGER;
typedef struct _STARTUPINFOW { DWORD cb; LPWSTR lpReserved; LPWSTR lpDesktop; LPWSTR lpTitle; DWORD dwX,dwY,dwXSize,dwYSize,dwXCountChars,dwYCountChars,dwFillAttribute,dwFlags; WORD wShowWindow,cbReserved2; BYTE* lpReserved2; HANDLE hStdInput,hStdOutput,hStdError; } STARTUPINFOW;
typedef struct _PROCESS_INFORMATION { HANDLE hProcess,hThread; DWORD dwProcessId,dwThreadId; } PROCESS_INFORMATION;
typedef ULONG_PTR HCRYPTPROV; typedef ULONG_PTR HCRYPTHASH;

#define WINAPI __stdcall
#define NULL ((void*)0)
#define TRUE 1
#define FALSE 0
#define INVALID_HANDLE_VALUE ((HANDLE)(LONG_PTR)-1)
#define GENERIC_READ 0x80000000UL
#define GENERIC_WRITE 0x40000000UL
#define FILE_SHARE_READ 0x1
#define FILE_SHARE_WRITE 0x2
#define OPEN_EXISTING 3
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_NORMAL 0x80
#define FILE_BEGIN 0
#define CREATE_NO_WINDOW 0x08000000
#define STARTF_USESHOWWINDOW 0x00000001
#define SW_HIDE 0
#define INFINITE 0xFFFFFFFFUL
#define MOVEFILE_REPLACE_EXISTING 0x00000001
#define MOVEFILE_WRITE_THROUGH 0x00000008
#define CP_UTF8 65001
#define PROV_RSA_AES 24
#define CRYPT_VERIFYCONTEXT 0xF0000000UL
#define CALG_SHA_256 0x0000800cUL
#define HP_HASHVAL 0x0002
#define FILE_FLAG_WRITE_THROUGH 0x80000000UL

__declspec(dllimport) HANDLE WINAPI CreateFileW(LPCWSTR,DWORD,DWORD,LPVOID,DWORD,DWORD,HANDLE);
__declspec(dllimport) BOOL WINAPI ReadFile(HANDLE,LPVOID,DWORD,DWORD*,LPVOID);
__declspec(dllimport) BOOL WINAPI WriteFile(HANDLE,LPCVOID,DWORD,DWORD*,LPVOID);
__declspec(dllimport) BOOL WINAPI SetFilePointerEx(HANDLE,LARGE_INTEGER,LARGE_INTEGER*,DWORD);
__declspec(dllimport) BOOL WINAPI GetFileSizeEx(HANDLE,LARGE_INTEGER*);
__declspec(dllimport) BOOL WINAPI SetEndOfFile(HANDLE);
__declspec(dllimport) BOOL WINAPI FlushFileBuffers(HANDLE);
__declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
__declspec(dllimport) BOOL WINAPI CreateDirectoryW(LPCWSTR,LPVOID);
__declspec(dllimport) BOOL WINAPI RemoveDirectoryW(LPCWSTR);
__declspec(dllimport) BOOL WINAPI DeleteFileW(LPCWSTR);
__declspec(dllimport) BOOL WINAPI CopyFileW(LPCWSTR,LPCWSTR,BOOL);
__declspec(dllimport) BOOL WINAPI MoveFileExW(LPCWSTR,LPCWSTR,DWORD);
__declspec(dllimport) DWORD WINAPI GetFileAttributesW(LPCWSTR);
__declspec(dllimport) DWORD WINAPI GetLastError(void);
__declspec(dllimport) DWORD WINAPI GetTempPathW(DWORD,LPWSTR);
__declspec(dllimport) DWORD WINAPI GetCurrentProcessId(void);
__declspec(dllimport) DWORD WINAPI GetModuleFileNameW(HMODULE,LPWSTR,DWORD);
__declspec(dllimport) LPWSTR WINAPI GetCommandLineW(void);
__declspec(dllimport) HANDLE WINAPI GetProcessHeap(void);
__declspec(dllimport) LPVOID WINAPI HeapAlloc(HANDLE,DWORD,ULONG_PTR);
__declspec(dllimport) BOOL WINAPI HeapFree(HANDLE,DWORD,LPVOID);
__declspec(dllimport) BOOL WINAPI CreateProcessW(LPCWSTR,LPWSTR,LPVOID,LPVOID,BOOL,DWORD,LPVOID,LPCWSTR,STARTUPINFOW*,PROCESS_INFORMATION*);
__declspec(dllimport) DWORD WINAPI WaitForSingleObject(HANDLE,DWORD);
__declspec(dllimport) BOOL WINAPI GetExitCodeProcess(HANDLE,DWORD*);
__declspec(dllimport) void WINAPI ExitProcess(UINT);
__declspec(dllimport) int WINAPI WideCharToMultiByte(UINT,DWORD,LPCWSTR,int,CHAR*,int,LPCSTR,BOOL*);

__declspec(dllimport) BOOL WINAPI CryptAcquireContextW(HCRYPTPROV*,LPCWSTR,LPCWSTR,DWORD,DWORD);
__declspec(dllimport) BOOL WINAPI CryptCreateHash(HCRYPTPROV,DWORD,ULONG_PTR,DWORD,HCRYPTHASH*);
__declspec(dllimport) BOOL WINAPI CryptHashData(HCRYPTHASH,const BYTE*,DWORD,DWORD);
__declspec(dllimport) BOOL WINAPI CryptGetHashParam(HCRYPTHASH,DWORD,BYTE*,DWORD*,DWORD);
__declspec(dllimport) BOOL WINAPI CryptDestroyHash(HCRYPTHASH);
__declspec(dllimport) BOOL WINAPI CryptReleaseContext(HCRYPTPROV,DWORD);

void* memset(void* d,int c,ULONG_PTR n){BYTE*p=(BYTE*)d;while(n--)*p++=(BYTE)c;return d;}
void* memcpy(void* d,const void*s,ULONG_PTR n){BYTE*dd=(BYTE*)d;const BYTE*ss=(const BYTE*)s;while(n--)*dd++=*ss++;return d;}
int memcmp(const void*a,const void*b,ULONG_PTR n){const BYTE*x=(const BYTE*)a,*y=(const BYTE*)b;while(n--){if(*x!=*y)return *x<*y?-1:1;x++;y++;}return 0;}

static const WCHAR VERSION[] = L"V0.9.0 READY R4";
static const WCHAR MANIFEST_NAME[] = L"6242ff7e5bc499ee";
static const WCHAR MANIFEST_REL[] = L"_data\\5932408047\\rad16\\win10\\manifests\\6242ff7e5bc499ee";
static const WCHAR PACKAGES_REL[] = L"_data\\5932408047\\rad16\\win10\\packages";
static const WCHAR NATIVE_BACKUP_REL[] = L"LE2_FR_READY_V090_R4_BACKUP";
static const WCHAR V090_STATE_REL[] = L"LE2_FR_V0.9.0_STATE.txt";
static const WCHAR V090_MAIN_MANIFEST_REL[] = L"_data\\5932408047\\rad16\\win10\\manifests\\ff715342fa4b2d8f";
static const WCHAR V090_MAIN_PACKAGE_REL[] = L"_data\\5932408047\\rad16\\win10\\packages\\ff715342fa4b2d8f_0";
static const BYTE EN_READY[17]={'R','e','a','d','y',' ','t','o',' ','m','o','v','e',' ','o','n','?'};
static const BYTE FR_READY[13]={'O','n',' ','c','o','n','t','i','n','u','e',' ','?'};

typedef struct Target { DWORD chunk,record,pi,assetOff,assetSize,local,origPeSize; const char* origPeSha; } Target;
static const Target T[4] = {
 {10400,147504,2,203728,194584,28364,35840,"ed674853736356a9cdea46dc206f5b9de180c08d156716dec17620383716b8c9"},
 {17893,149631,5,196120,165912,25292,31744,"8e6806456a0623472044a559c8b7434af40fa05afe28f804713d085982081c2d"},
 {24183,148672,7,222232,175128,25804,4096,"9d6888ced2c83801fc1b7d00dd1d26f0f945ac680534a9db8983e794c5f67c17"},
 {31521,149928,9,0,174104,24780,31744,"0bfa70481de6c7b7c95f4e257f378b4efc395fb8b97c488fbacdc9ac5949b9c3"}
};
static const ULONGLONG REFERENCE_PKG_SIZE[4]={2139978849ULL,2123871680ULL,2147355574ULL,1945049316ULL};
typedef struct BackupState { BYTE magic[8]; ULONGLONG pkgSize[4]; BYTE manifestSha[32]; } BackupState;
static const BYTE BACKUP_MAGIC[8]={'L','E','2','R','2','B','0','1'};

static WCHAR gGame[4096], gReportRoot[4096], gExeDir[4096], gWork[4096], gReport[4096], gZstd[4096];

static ULONG_PTR wlen(LPCWSTR s){ULONG_PTR n=0;while(s&&s[n])n++;return n;}
static void wcopy(LPWSTR d,ULONG_PTR c,LPCWSTR s){ULONG_PTR i=0;if(!c)return;while(s&&s[i]&&i+1<c){d[i]=s[i];i++;}d[i]=0;}
static void wcat(LPWSTR d,ULONG_PTR c,LPCWSTR s){ULONG_PTR i=wlen(d),j=0;while(s&&s[j]&&i+1<c)d[i++]=s[j++];d[i]=0;}
static int weq(LPCWSTR a,LPCWSTR b){ULONG_PTR i=0;if(!a||!b)return 0;while(a[i]&&b[i]){if(a[i]!=b[i])return 0;i++;}return a[i]==b[i];}
static void join(LPWSTR o,ULONG_PTR c,LPCWSTR a,LPCWSTR b){wcopy(o,c,a);ULONG_PTR n=wlen(o);if(n&&o[n-1]!=L'\\')wcat(o,c,L"\\");wcat(o,c,b);}
static void parent(LPWSTR p){ULONG_PTR n=wlen(p);while(n){if(p[n-1]==L'\\'||p[n-1]==L'/'){p[n-1]=0;return;}n--;}p[0]=0;}
static void u64w(ULONGLONG v,LPWSTR o,ULONG_PTR c){WCHAR t[32];int n=0;if(!v){wcopy(o,c,L"0");return;}while(v&&n<31){t[n++]=(WCHAR)(L'0'+(v%10));v/=10;}int k=0;while(n&&k+1<(int)c)o[k++]=t[--n];o[k]=0;}
static void u32w(DWORD v,LPWSTR o,ULONG_PTR c){u64w(v,o,c);}
static int file_exists(LPCWSTR p){DWORD a=GetFileAttributesW(p);return a!=0xFFFFFFFFUL && !(a&0x10);}
static int dir_exists(LPCWSTR p){DWORD a=GetFileAttributesW(p);return a!=0xFFFFFFFFUL && (a&0x10);}
static DWORD rd32(const BYTE*b,DWORD p){return (DWORD)b[p]|((DWORD)b[p+1]<<8)|((DWORD)b[p+2]<<16)|((DWORD)b[p+3]<<24);}
static void wr32(BYTE*b,DWORD p,DWORD v){b[p]=(BYTE)v;b[p+1]=(BYTE)(v>>8);b[p+2]=(BYTE)(v>>16);b[p+3]=(BYTE)(v>>24);}
static int hex_eq(const BYTE* h,const char* s){static const char*x="0123456789abcdef";int i;for(i=0;i<32;i++){if(x[(h[i]>>4)&15]!=s[i*2]||x[h[i]&15]!=s[i*2+1])return 0;}return 1;}
static void hexstr(const BYTE*h,char*out){static const char*x="0123456789abcdef";int i;for(i=0;i<32;i++){out[i*2]=x[(h[i]>>4)&15];out[i*2+1]=x[h[i]&15];}out[64]=0;}

static void log_ascii(const char* s){
 HANDLE h=CreateFileW(gReport,GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL); if(h==INVALID_HANDLE_VALUE)h=CreateFileW(gReport,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL); if(h==INVALID_HANDLE_VALUE)return; LARGE_INTEGER sz,li; if(GetFileSizeEx(h,&sz)){li.QuadPart=sz.QuadPart;SetFilePointerEx(h,li,NULL,FILE_BEGIN);} DWORD n=0;while(s[n])n++;DWORD w;WriteFile(h,s,n,&w,NULL);WriteFile(h,"\r\n",2,&w,NULL);FlushFileBuffers(h);CloseHandle(h);
}
static void log_w(LPCWSTR ws){char* b=(char*)HeapAlloc(GetProcessHeap(),0,65536);if(!b)return;int n=WideCharToMultiByte(CP_UTF8,0,ws,-1,b,65535,NULL,NULL);if(n>0)log_ascii(b);HeapFree(GetProcessHeap(),0,b);}
static void log_num(const char* prefix,ULONGLONG v){WCHAR w[128],n[64];int i=0;while(prefix[i]&&i<60){w[i]=(WCHAR)(BYTE)prefix[i];i++;}w[i]=0;u64w(v,n,64);wcat(w,128,n);log_w(w);}

static int read_exact(HANDLE h,void* dst,DWORD n){BYTE*p=(BYTE*)dst;DWORD d=0,r;while(d<n){if(!ReadFile(h,p+d,n-d,&r,NULL)||!r)return 0;d+=r;}return 1;}
static int write_exact(HANDLE h,const void* src,DWORD n){const BYTE*p=(const BYTE*)src;DWORD d=0,w;while(d<n){if(!WriteFile(h,p+d,n-d,&w,NULL)||!w)return 0;d+=w;}return 1;}
static int seek64(HANDLE h,ULONGLONG o){LARGE_INTEGER li;li.QuadPart=(LONGLONG)o;return SetFilePointerEx(h,li,NULL,FILE_BEGIN);}
static int fsize(LPCWSTR p,ULONGLONG* out){HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);LARGE_INTEGER s;if(h==INVALID_HANDLE_VALUE)return 0;BOOL ok=GetFileSizeEx(h,&s);CloseHandle(h);if(ok)*out=(ULONGLONG)s.QuadPart;return ok?1:0;}
static BYTE* read_all(LPCWSTR p,DWORD* out){ULONGLONG s;if(!fsize(p,&s)||s>0x7fffffffULL)return NULL;HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return NULL;BYTE*b=(BYTE*)HeapAlloc(GetProcessHeap(),0,(ULONG_PTR)s+1);if(!b){CloseHandle(h);return NULL;}if(!read_exact(h,b,(DWORD)s)){HeapFree(GetProcessHeap(),0,b);CloseHandle(h);return NULL;}CloseHandle(h);*out=(DWORD)s;return b;}
static int write_all(LPCWSTR p,const BYTE*b,DWORD n){HANDLE h=CreateFileW(p,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);if(h==INVALID_HANDLE_VALUE)return 0;int ok=write_exact(h,b,n);FlushFileBuffers(h);CloseHandle(h);return ok;}
static BYTE* read_range(LPCWSTR p,ULONGLONG off,DWORD n){HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return NULL;BYTE*b=(BYTE*)HeapAlloc(GetProcessHeap(),0,n?n:1);if(!b){CloseHandle(h);return NULL;}if(!seek64(h,off)||!read_exact(h,b,n)){HeapFree(GetProcessHeap(),0,b);CloseHandle(h);return NULL;}CloseHandle(h);return b;}
static int append_bytes(LPCWSTR p,const BYTE*b,DWORD n,ULONGLONG expectedOff){HANDLE h=CreateFileW(p,GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);if(h==INVALID_HANDLE_VALUE)return 0;LARGE_INTEGER s;if(!GetFileSizeEx(h,&s)||(ULONGLONG)s.QuadPart!=expectedOff||!seek64(h,expectedOff)||!write_exact(h,b,n)){CloseHandle(h);return 0;}FlushFileBuffers(h);CloseHandle(h);return 1;}
static int truncate_file(LPCWSTR p,ULONGLONG n){HANDLE h=CreateFileW(p,GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);if(h==INVALID_HANDLE_VALUE)return 0;if(!seek64(h,n)||!SetEndOfFile(h)){CloseHandle(h);return 0;}FlushFileBuffers(h);CloseHandle(h);return 1;}
static int files_equal(LPCWSTR a,LPCWSTR b){ULONGLONG sa,sb;if(!fsize(a,&sa)||!fsize(b,&sb)||sa!=sb)return 0;HANDLE ha=CreateFileW(a,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL),hb=CreateFileW(b,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(ha==INVALID_HANDLE_VALUE||hb==INVALID_HANDLE_VALUE){if(ha!=INVALID_HANDLE_VALUE)CloseHandle(ha);if(hb!=INVALID_HANDLE_VALUE)CloseHandle(hb);return 0;}BYTE* x=(BYTE*)HeapAlloc(GetProcessHeap(),0,1024*1024),*y=(BYTE*)HeapAlloc(GetProcessHeap(),0,1024*1024);if(!x||!y){if(x)HeapFree(GetProcessHeap(),0,x);if(y)HeapFree(GetProcessHeap(),0,y);CloseHandle(ha);CloseHandle(hb);return 0;}ULONGLONG rem=sa;int ok=1;while(rem){DWORD n=rem>1024*1024?1024*1024:(DWORD)rem;if(!read_exact(ha,x,n)||!read_exact(hb,y,n)||memcmp(x,y,n)){ok=0;break;}rem-=n;}HeapFree(GetProcessHeap(),0,x);HeapFree(GetProcessHeap(),0,y);CloseHandle(ha);CloseHandle(hb);return ok;}
static int tail_equals_file(LPCWSTR pkg,ULONGLONG off,LPCWSTR tail){ULONGLONG ts,ps;if(!fsize(tail,&ts)||!fsize(pkg,&ps)||ps!=off+ts)return 0;HANDLE a=CreateFileW(pkg,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL),b=CreateFileW(tail,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(a==INVALID_HANDLE_VALUE||b==INVALID_HANDLE_VALUE){if(a!=INVALID_HANDLE_VALUE)CloseHandle(a);if(b!=INVALID_HANDLE_VALUE)CloseHandle(b);return 0;}if(!seek64(a,off)){CloseHandle(a);CloseHandle(b);return 0;}BYTE*x=(BYTE*)HeapAlloc(GetProcessHeap(),0,262144),*y=(BYTE*)HeapAlloc(GetProcessHeap(),0,262144);if(!x||!y){if(x)HeapFree(GetProcessHeap(),0,x);if(y)HeapFree(GetProcessHeap(),0,y);CloseHandle(a);CloseHandle(b);return 0;}ULONGLONG rem=ts;int ok=1;while(rem){DWORD n=rem>262144?262144:(DWORD)rem;if(!read_exact(a,x,n)||!read_exact(b,y,n)||memcmp(x,y,n)){ok=0;break;}rem-=n;}HeapFree(GetProcessHeap(),0,x);HeapFree(GetProcessHeap(),0,y);CloseHandle(a);CloseHandle(b);return ok;}

static int sha_bytes(const BYTE* d,DWORD n,BYTE out[32]){HCRYPTPROV p=0;HCRYPTHASH h=0;DWORD sz=32;int ok=0;if(!CryptAcquireContextW(&p,NULL,NULL,PROV_RSA_AES,CRYPT_VERIFYCONTEXT))goto done;if(!CryptCreateHash(p,CALG_SHA_256,0,0,&h))goto done;if(n&&!CryptHashData(h,d,n,0))goto done;if(!CryptGetHashParam(h,HP_HASHVAL,out,&sz,0)||sz!=32)goto done;ok=1;done:if(h)CryptDestroyHash(h);if(p)CryptReleaseContext(p,0);return ok;}
static int sha_file(LPCWSTR path,BYTE out[32]){HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return 0;HCRYPTPROV p=0;HCRYPTHASH h=0;BYTE*buf=NULL;DWORD r,sz=32;int ok=0;if(!CryptAcquireContextW(&p,NULL,NULL,PROV_RSA_AES,CRYPT_VERIFYCONTEXT))goto done;if(!CryptCreateHash(p,CALG_SHA_256,0,0,&h))goto done;buf=(BYTE*)HeapAlloc(GetProcessHeap(),0,1024*1024);if(!buf)goto done;for(;;){if(!ReadFile(f,buf,1024*1024,&r,NULL))goto done;if(!r)break;if(!CryptHashData(h,buf,r,0))goto done;}if(!CryptGetHashParam(h,HP_HASHVAL,out,&sz,0)||sz!=32)goto done;ok=1;done:if(buf)HeapFree(GetProcessHeap(),0,buf);if(h)CryptDestroyHash(h);if(p)CryptReleaseContext(p,0);CloseHandle(f);return ok;}

static int ensure_dir(LPCWSTR p){if(dir_exists(p))return 1;return CreateDirectoryW(p,NULL)?1:0;}
static void remove_simple_dir(LPCWSTR dir){WCHAR p[4096];const WCHAR* names[]={L"6242ff7e5bc499ee.original",L"chunk_PI2.zst",L"chunk_PI5.zst",L"chunk_PI7.zst",L"chunk_PI9.zst",L"baseline.bin",L"state.txt",L"state.json"};int i;for(i=0;i<8;i++){join(p,4096,dir,names[i]);DeleteFileW(p);}RemoveDirectoryW(dir);}
static int atomic_replace_from_file(LPCWSTR src,LPCWSTR dst){if(!CopyFileW(src,dst,FALSE))return 0;return files_equal(src,dst);}

static int run_process(LPWSTR cmd,LPCWSTR cwd){STARTUPINFOW si;PROCESS_INFORMATION pi;DWORD code=1;memset(&si,0,sizeof(si));memset(&pi,0,sizeof(pi));si.cb=sizeof(si);si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;if(!CreateProcessW(NULL,cmd,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,cwd,&si,&pi))return 0;WaitForSingleObject(pi.hProcess,INFINITE);GetExitCodeProcess(pi.hProcess,&code);CloseHandle(pi.hThread);CloseHandle(pi.hProcess);return code==0;}
static int zstd_decompress(LPCWSTR src,LPCWSTR out){WCHAR cmd[65536];wcopy(cmd,65536,L"\"");wcat(cmd,65536,gZstd);wcat(cmd,65536,L"\" -q -d -f \"");wcat(cmd,65536,src);wcat(cmd,65536,L"\" -o \"");wcat(cmd,65536,out);wcat(cmd,65536,L"\"");return run_process(cmd,gWork);}
static int zstd_compress(LPCWSTR src,LPCWSTR out){WCHAR cmd[65536];wcopy(cmd,65536,L"\"");wcat(cmd,65536,gZstd);wcat(cmd,65536,L"\" -q -19 -f \"");wcat(cmd,65536,src);wcat(cmd,65536,L"\" -o \"");wcat(cmd,65536,out);wcat(cmd,65536,L"\"");return run_process(cmd,gWork);}

static int expand_manifest(LPCWSTR manifest,LPCWSTR out){DWORD n=0;BYTE*b=read_all(manifest,&n);if(!b||n<28){if(b)HeapFree(GetProcessHeap(),0,b);return 0;}if(memcmp(b,"ZSTD",4)){HeapFree(GetProcessHeap(),0,b);return 0;}WCHAR frame[4096];wcopy(frame,4096,out);wcat(frame,4096,L".zst");int ok=write_all(frame,b+24,n-24)&&zstd_decompress(frame,out);HeapFree(GetProcessHeap(),0,b);return ok;}
static int parse_manifest(BYTE*b,DWORD n,DWORD*secA,DWORD*rowStart,DWORD*rowCount){if(n<216)return 0;DWORD secALen=rd32(b,24),c1=rd32(b,56),c2=rd32(b,64),secBLen=rd32(b,88),rc=rd32(b,184);ULONGLONG rs=200ULL+secALen+secBLen;if(secALen!=c1*32||c1!=c2||c1!=236777||rc!=31941||rs+(ULONGLONG)rc*16>n)return 0;*secA=200;*rowStart=(DWORD)rs;*rowCount=rc;return 1;}
static int build_manifest(LPCWSTR base,const BYTE*dec,DWORD decN,LPCWSTR frame,LPCWSTR out){DWORD bn=0,fn=0;BYTE*bb=read_all(base,&bn),*fb=read_all(frame,&fn);if(!bb||!fb||bn<24){if(bb)HeapFree(GetProcessHeap(),0,bb);if(fb)HeapFree(GetProcessHeap(),0,fb);return 0;}BYTE*o=(BYTE*)HeapAlloc(GetProcessHeap(),0,24+fn);if(!o){HeapFree(GetProcessHeap(),0,bb);HeapFree(GetProcessHeap(),0,fb);return 0;}memcpy(o,bb,24);wr32(o,8,decN);wr32(o,16,fn);memcpy(o+24,fb,fn);int ok=write_all(out,o,24+fn);HeapFree(GetProcessHeap(),0,o);HeapFree(GetProcessHeap(),0,bb);HeapFree(GetProcessHeap(),0,fb);return ok;}

static void package_path(DWORD pi,LPWSTR out){WCHAR dir[4096],n[128],num[32];join(dir,4096,gGame,PACKAGES_REL);wcopy(n,128,MANIFEST_NAME);wcat(n,128,L"_");u32w(pi,num,32);wcat(n,128,num);join(out,4096,dir,n);}
static void backup_chunk_path(LPCWSTR backup,DWORD pi,LPWSTR out){WCHAR n[64],num[32];wcopy(n,64,L"chunk_PI");u32w(pi,num,32);wcat(n,64,num);wcat(n,64,L".zst");join(out,4096,backup,n);}

static int save_backup_state(LPCWSTR backup,const ULONGLONG sizes[4],const BYTE manifestSha[32]){
 WCHAR p[4096];BackupState st;memset(&st,0,sizeof(st));memcpy(st.magic,BACKUP_MAGIC,8);int i;for(i=0;i<4;i++)st.pkgSize[i]=sizes[i];memcpy(st.manifestSha,manifestSha,32);join(p,4096,backup,L"baseline.bin");return write_all(p,(const BYTE*)&st,(DWORD)sizeof(st));
}
static int load_backup_state(LPCWSTR backup,BackupState* st){WCHAR p[4096];join(p,4096,backup,L"baseline.bin");DWORD n=0;BYTE*b=read_all(p,&n);if(!b||n!=sizeof(BackupState)){if(b)HeapFree(GetProcessHeap(),0,b);return 0;}memcpy(st,b,sizeof(BackupState));HeapFree(GetProcessHeap(),0,b);return memcmp(st->magic,BACKUP_MAGIC,8)==0;}
static void log_hash_line(const char* prefix,const BYTE h[32]){char hs[65];hexstr(h,hs);log_ascii(prefix);log_ascii(hs);}
static void log_target_diag(int i,DWORD pi,DWORD off,DWORD cs,DWORD us,DWORD rchunk,DWORD aoff,DWORD asz,DWORD flags,ULONGLONG pkgSize){
 log_num("CHECK target index=",(ULONGLONG)i);log_num("  chunk=",T[i].chunk);log_num("  record=",T[i].record);log_num("  manifest.pi.observed=",pi);log_num("  manifest.offset.observed=",off);log_num("  manifest.compressed_size.observed=",cs);log_num("  manifest.uncompressed_size.observed=",us);log_num("  record.chunk.observed=",rchunk);log_num("  record.asset_off.observed=",aoff);log_num("  record.asset_size.observed=",asz);log_num("  record.flags.observed=",flags);log_num("  package.size.observed=",pkgSize);log_num("  package.size.old_reference=",REFERENCE_PKG_SIZE[i]);
}
static int restore_backup_dir(LPCWSTR backup,int legacy){
 (void)legacy;WCHAR bm[4096],live[4096],pkg[4096],bc[4096];BackupState st;join(bm,4096,backup,L"6242ff7e5bc499ee.original");join(live,4096,gGame,MANIFEST_REL);if(!file_exists(bm)){log_ascii("RESTORE: backup manifest missing");return 0;}if(!load_backup_state(backup,&st)){log_ascii("RESTORE: baseline.bin missing or invalid");return 0;}BYTE bsha[32];if(!sha_file(bm,bsha)||memcmp(bsha,st.manifestSha,32)){log_ascii("RESTORE: backup manifest SHA does not match saved baseline");return 0;}
 int i;for(i=0;i<4;i++){package_path(T[i].pi,pkg);backup_chunk_path(backup,T[i].pi,bc);ULONGLONG ps=0,cs=0;if(!fsize(pkg,&ps)){log_ascii("RESTORE: package missing");return 0;}if(ps==st.pkgSize[i])continue;if(!fsize(bc,&cs)){log_ascii("RESTORE: appended chunk backup missing");return 0;}if(ps!=st.pkgSize[i]+cs){log_ascii("RESTORE: unexpected package size; refused");log_num("  observed=",ps);log_num("  expected_baseline=",st.pkgSize[i]);log_num("  expected_with_tail=",st.pkgSize[i]+cs);return 0;}if(!tail_equals_file(pkg,st.pkgSize[i],bc)){log_ascii("RESTORE: appended tail mismatch; refused");return 0;}}
 if(!files_equal(live,bm)){if(!atomic_replace_from_file(bm,live)){log_ascii("RESTORE: manifest replacement failed");return 0;}log_ascii("RESTORE: original manifest restored");}else log_ascii("RESTORE: live manifest already baseline");
 for(i=0;i<4;i++){package_path(T[i].pi,pkg);ULONGLONG ps=0;fsize(pkg,&ps);if(ps>st.pkgSize[i]){if(!truncate_file(pkg,st.pkgSize[i])){log_ascii("RESTORE: package truncation failed");return 0;}}}
 if(!files_equal(live,bm)){log_ascii("RESTORE: manifest verification failed");return 0;}for(i=0;i<4;i++){package_path(T[i].pi,pkg);ULONGLONG ps=0;if(!fsize(pkg,&ps)||ps!=st.pkgSize[i]){log_ascii("RESTORE: final package size mismatch");return 0;}}
 log_ascii("V090_READY_R4_RESTORE_OK");remove_simple_dir(backup);return 1;
}

static int contains_ascii(const BYTE*b,DWORD n,const char*q){DWORD qn=0,i,j;while(q[qn])qn++;if(!qn||qn>n)return 0;for(i=0;i+qn<=n;i++){for(j=0;j<qn&&b[i+j]==(BYTE)q[j];j++){;}if(j==qn)return 1;}return 0;}
static int contains_ascii_range(const BYTE*b,DWORD n,DWORD start,DWORD end,const char*q){DWORD qn=0,i,j;while(q[qn])qn++;if(!qn||start>=n)return 0;if(end>n)end=n;if(end<start||end-start<qn)return 0;for(i=start;i+qn<=end;i++){for(j=0;j<qn&&b[i+j]==(BYTE)q[j];j++){;}if(j==qn)return 1;}return 0;}
static DWORD count_bytes_range(const BYTE*b,DWORD n,DWORD start,DWORD end,const BYTE*pat,DWORD pn){DWORD i,c=0;if(!b||!pat||!pn||start>=n)return 0;if(end>n)end=n;if(end<start||end-start<pn)return 0;for(i=start;i+pn<=end;i++)if(!memcmp(b+i,pat,pn))c++;return c;}
static int verify_v090_install(void){WCHAR st[4096],mm[4096],mp[4096];join(st,4096,gGame,V090_STATE_REL);join(mm,4096,gGame,V090_MAIN_MANIFEST_REL);join(mp,4096,gGame,V090_MAIN_PACKAGE_REL);log_ascii("=== V0.9.0 PUBLIC INSTALL CHECK ===");if(!file_exists(st)){log_ascii("BASELINE_V090: marker missing: LE2_FR_V0.9.0_STATE.txt");return 0;}if(!file_exists(mm)){log_ascii("BASELINE_V090: ff715342fa4b2d8f manifest missing");return 0;}if(!file_exists(mp)){log_ascii("BASELINE_V090: ff715342fa4b2d8f_0 package missing");return 0;}DWORD n=0;BYTE*b=read_all(st,&n);if(!b){log_ascii("BASELINE_V090: state file unreadable");return 0;}int ok=contains_ascii(b,n,"Version=V0.9.0");HeapFree(GetProcessHeap(),0,b);if(!ok){log_ascii("BASELINE_V090: state file does not contain Version=V0.9.0");return 0;}BYTE h[32];if(sha_file(mm,h))log_hash_line("BASELINE_V090: main manifest SHA256 follows",h);if(sha_file(mp,h))log_hash_line("BASELINE_V090: main package SHA256 follows",h);log_ascii("BASELINE_V090: official V0.9.0 marker and main files detected");return 1;}

static int do_install(void){
 log_ascii("LONE ECHO II - READY FIX FOR PUBLIC V0.9.0 - R4");
 log_ascii("MODE: INSTALL / FOUR-TARGET CONTENT VALIDATION");
 log_ascii("R4 validates all four locked records, offsets, exact Ready bytes and neighboring script context before any game write. Whole-PE SHA256 is not a blocking gate.");
 if(!verify_v090_install()){log_ascii("FATAL: public V0.9.0 installation not detected. No file was modified.");return 0;}
 WCHAR nb[4096];join(nb,4096,gGame,NATIVE_BACKUP_REL);if(dir_exists(nb)){log_ascii("FATAL: V0.9.0 READY R4 backup already exists. Use RESTORE first.");return 0;}
 WCHAR liveManifest[4096],decMan[4096],newDecMan[4096],newFrame[4096],newManifest[4096];join(liveManifest,4096,gGame,MANIFEST_REL);if(!file_exists(liveManifest)){log_ascii("FATAL: 6242 manifest missing. No file was modified.");return 0;}BYTE manifestSha[32];if(!sha_file(liveManifest,manifestSha)){log_ascii("FATAL: unable to hash live 6242 manifest. No file was modified.");return 0;}log_hash_line("BASELINE_6242: live manifest SHA256 follows (diagnostic only)",manifestSha);
 join(decMan,4096,gWork,L"manifest.dec");join(newDecMan,4096,gWork,L"manifest.new.dec");join(newFrame,4096,gWork,L"manifest.new.zst");join(newManifest,4096,gWork,L"6242ff7e5bc499ee.new");if(!expand_manifest(liveManifest,decMan)){log_ascii("FATAL: 6242 manifest decompression failed. No file was modified.");return 0;}
 DWORD mn=0;BYTE*mb=read_all(decMan,&mn);if(!mb){log_ascii("FATAL: decoded manifest read failed. No file was modified.");return 0;}DWORD secA,rowStart,rowCount;if(!parse_manifest(mb,mn,&secA,&rowStart,&rowCount)){HeapFree(GetProcessHeap(),0,mb);log_ascii("FATAL: decoded manifest structure mismatch. No file was modified.");return 0;}
 WCHAR oldDecoded[4][4096],newChunks[4][4096];DWORD newCS[4]={0};ULONGLONG basePkgSize[4]={0};int valid[4]={0,0,0,0};int i;int validCount=0;
 log_ascii("CHECKPOINT 03: VALIDATE_ALL_FOUR_BEGIN");log_ascii("=== TARGET CONTENT VERIFICATION (ALL 4) ===");
 for(i=0;i<4;i++){
   int ok=1;DWORD rp=rowStart+T[i].chunk*16;DWORD pi=rd32(mb,rp),off=rd32(mb,rp+4),cs=rd32(mb,rp+8),us=rd32(mb,rp+12);DWORD recp=secA+T[i].record*32;DWORD rchunk=rd32(mb,recp+16),aoff=rd32(mb,recp+20),asz=rd32(mb,recp+24),flags=rd32(mb,recp+28);WCHAR pkg[4096];package_path(T[i].pi,pkg);
   log_num("TARGET_BEGIN index=",i);
   if(!fsize(pkg,&basePkgSize[i])){log_ascii("  FAIL: target package missing/unreadable");ok=0;}
   log_target_diag(i,pi,off,cs,us,rchunk,aoff,asz,flags,basePkgSize[i]);
   if(pi!=T[i].pi||!cs||!us){log_ascii("  FAIL: manifest target row mismatch");ok=0;}
   if(rchunk!=T[i].chunk||aoff!=T[i].assetOff||asz!=T[i].assetSize){log_ascii("  FAIL: target record metadata mismatch");ok=0;}
   if(basePkgSize[i]>0xffffffffULL){log_ascii("  FAIL: package EOF exceeds manifest 32-bit offset range");ok=0;}
   if((ULONGLONG)off+cs>basePkgSize[i]){log_ascii("  FAIL: current manifest chunk range exceeds package size");ok=0;}
   WCHAR oldZ[4096],num[32];u32w(T[i].chunk,num,32);join(oldZ,4096,gWork,L"chunk_");wcat(oldZ,4096,num);wcat(oldZ,4096,L".zst");join(oldDecoded[i],4096,gWork,L"chunk_");wcat(oldDecoded[i],4096,num);wcat(oldDecoded[i],4096,L".dec");join(newChunks[i],4096,gWork,L"chunk_");wcat(newChunks[i],4096,num);wcat(newChunks[i],4096,L"_new.zst");
   if(ok){BYTE*cb=read_range(pkg,off,cs);if(!cb||!write_all(oldZ,cb,cs)){if(cb)HeapFree(GetProcessHeap(),0,cb);log_ascii("  FAIL: chunk extraction failed");ok=0;}else{HeapFree(GetProcessHeap(),0,cb);if(!zstd_decompress(oldZ,oldDecoded[i])){log_ascii("  FAIL: zstd chunk decompression failed");ok=0;}}}
   if(ok){DWORD dn=0;BYTE*db=read_all(oldDecoded[i],&dn);if(!db||dn!=us){if(db)HeapFree(GetProcessHeap(),0,db);log_ascii("  FAIL: decoded chunk size mismatch");ok=0;}else{
      ULONGLONG abs64=(ULONGLONG)T[i].assetOff+T[i].local;DWORD abs=(DWORD)abs64;DWORD astart=T[i].assetOff,aend=T[i].assetOff+T[i].assetSize;
      if(abs64+18>dn||abs<T[i].assetOff||abs+18>aend){log_ascii("  FAIL: target byte range outside locked asset");ok=0;}
      if(ok&&(db[T[i].assetOff+20]!=0x4D||db[T[i].assetOff+21]!=0x5A)){log_ascii("  FAIL: packed script PE MZ missing at locked asset start");ok=0;}
      if(ok&&(memcmp(db+abs,EN_READY,17)||db[abs+17]!=0)){log_ascii("  FAIL: exact English Ready bytes not found at locked offset");ok=0;}else if(ok)log_ascii("  exact Ready bytes = MATCH");
      if(ok){DWORD cnt=count_bytes_range(db,dn,astart,aend,EN_READY,17);log_num("  Ready occurrences inside locked asset=",cnt);if(cnt!=1){log_ascii("  FAIL: Ready occurrence count inside asset is not exactly 1");ok=0;}}
      if(ok){DWORD before=abs>128?abs-128:0;DWORD after=abs+420<dn?abs+420:dn;int c1=contains_ascii_range(db,dn,before,abs,"Blocking node (%%08x) used in Initialize thread");int c2=contains_ascii_range(db,dn,abs+17,after,"Node (%08x) had no execute function");int c3=contains_ascii_range(db,dn,abs+17,after,"self");int c4=contains_ascii_range(db,dn,abs+17,after,"juno");int c5=contains_ascii_range(db,dn,abs+17,after,"jack");log_ascii(c1?"  context.before.BlockingNode = MATCH":"  context.before.BlockingNode = MISSING");log_ascii(c2?"  context.after.NoExecute = MATCH":"  context.after.NoExecute = MISSING");log_ascii(c3?"  context.after.self = MATCH":"  context.after.self = MISSING");log_ascii(c4?"  context.after.juno = MATCH":"  context.after.juno = MISSING");log_ascii(c5?"  context.after.jack = MATCH":"  context.after.jack = MISSING");if(!(c1&&c2&&c3&&c4&&c5)){log_ascii("  FAIL: neighboring script context mismatch");ok=0;}}
      if(ok&&i==0&&!contains_ascii_range(db,dn,abs+17,abs+420<dn?abs+420:dn,"popcorn")){log_ascii("  FAIL: target-specific context popcorn missing");ok=0;}
      if(ok&&i==1&&(!contains_ascii_range(db,dn,abs+17,abs+420<dn?abs+420:dn,"computer")||!contains_ascii_range(db,dn,abs+17,abs+420<dn?abs+420:dn,"narrator"))){log_ascii("  FAIL: target-specific context computer/narrator missing");ok=0;}
      if(ok&&i==3&&!contains_ascii_range(db,dn,abs+17,abs+420<dn?abs+420:dn,"computer")){log_ascii("  FAIL: target-specific context computer missing");ok=0;}
      if(ok)log_ascii("  context = MATCH");HeapFree(GetProcessHeap(),0,db);
   }}
   valid[i]=ok;if(ok){validCount++;log_ascii("TARGET_RESULT = PASS");}else log_ascii("TARGET_RESULT = FAIL");
 }
 log_num("VALID_TARGET_COUNT=",validCount);log_ascii("CHECKPOINT 04: VALIDATE_ALL_FOUR_END");
 if(validCount!=4){log_ascii("FATAL: one or more locked targets failed. ALL FOUR were examined. No game file was modified.");goto fail;}
 log_ascii("PREWRITE_GATE_OK: 4/4 targets validated. Preparing patched chunks in temporary files only.");
 for(i=0;i<4;i++){
   DWORD dn=0;BYTE*db=read_all(oldDecoded[i],&dn);if(!db){log_ascii("FATAL: reread decoded chunk failed. No game file was modified.");goto fail;}DWORD abs=T[i].assetOff+T[i].local;BYTE*orig=(BYTE*)HeapAlloc(GetProcessHeap(),0,dn);if(!orig){HeapFree(GetProcessHeap(),0,db);log_ascii("FATAL: memory allocation failed. No game file was modified.");goto fail;}memcpy(orig,db,dn);memset(db+abs,0,17);memcpy(db+abs,FR_READY,13);DWORD diff=0,j;for(j=0;j<dn;j++)if(db[j]!=orig[j])diff++;HeapFree(GetProcessHeap(),0,orig);if(diff!=16){HeapFree(GetProcessHeap(),0,db);log_num("FATAL: unexpected changed-byte count=",diff);goto fail;}WCHAR newD[4096],num[32];u32w(T[i].chunk,num,32);join(newD,4096,gWork,L"chunk_");wcat(newD,4096,num);wcat(newD,4096,L"_new.dec");if(!write_all(newD,db,dn)){HeapFree(GetProcessHeap(),0,db);log_ascii("FATAL: write patched decoded chunk failed. No game file was modified.");goto fail;}HeapFree(GetProcessHeap(),0,db);if(!zstd_compress(newD,newChunks[i])){log_ascii("FATAL: zstd chunk compression failed. No game file was modified.");goto fail;}ULONGLONG ncs64=0;if(!fsize(newChunks[i],&ncs64)||ncs64>0xffffffffULL||basePkgSize[i]+ncs64>0xffffffffULL){log_ascii("FATAL: new chunk size/offset invalid. No game file was modified.");goto fail;}newCS[i]=(DWORD)ncs64;DWORD rp=rowStart+T[i].chunk*16;wr32(mb,rp+4,(DWORD)basePkgSize[i]);wr32(mb,rp+8,newCS[i]);log_ascii("  prepared patched chunk = OK");
 }
 log_ascii("CHECKPOINT 05: FOUR_PATCHED_CHUNKS_PREPARED_NO_GAME_WRITE_YET");
 if(!write_all(newDecMan,mb,mn)){log_ascii("FATAL: write new decoded manifest failed. No game file was modified.");goto fail;}if(!zstd_compress(newDecMan,newFrame)){log_ascii("FATAL: manifest compression failed. No game file was modified.");goto fail;}if(!build_manifest(liveManifest,mb,mn,newFrame,newManifest)){log_ascii("FATAL: build manifest failed. No game file was modified.");goto fail;}
 if(!ensure_dir(nb)){log_ascii("FATAL: create R4 backup dir failed. No game file was modified.");goto fail;}WCHAR bm[4096];join(bm,4096,nb,L"6242ff7e5bc499ee.original");if(!CopyFileW(liveManifest,bm,FALSE)||!files_equal(liveManifest,bm)){log_ascii("FATAL: backup manifest failed. No package was modified.");goto rollback_backup;}if(!save_backup_state(nb,basePkgSize,manifestSha)){log_ascii("FATAL: baseline state backup failed. No package was modified.");goto rollback_backup;}for(i=0;i<4;i++){WCHAR bc[4096];backup_chunk_path(nb,T[i].pi,bc);if(!CopyFileW(newChunks[i],bc,FALSE)||!files_equal(newChunks[i],bc)){log_ascii("FATAL: backup appended chunk failed. No package was modified.");goto rollback_backup;}}
 {WCHAR st[4096];join(st,4096,nb,L"state.txt");const char*x="Lone Echo II Ready Fix for public V0.9.0 - R4\r\nBaseline=official V0.9.0 + four-target contextual validation\r\nRestore=dynamic original manifest + dynamic original package sizes\r\n";DWORD sn=0;while(x[sn])sn++;write_all(st,(const BYTE*)x,sn);}
 log_ascii("CHECKPOINT 06: BACKUP_COMPLETE_BEGIN_GAME_WRITES");
 for(i=0;i<4;i++){WCHAR pkg[4096];package_path(T[i].pi,pkg);DWORD n=0;BYTE*b=read_all(newChunks[i],&n);if(!b||n!=newCS[i]||!append_bytes(pkg,b,n,basePkgSize[i])){if(b)HeapFree(GetProcessHeap(),0,b);log_ascii("INSTALL_ERROR: native package append failed");goto rollback;}HeapFree(GetProcessHeap(),0,b);WCHAR bc[4096];backup_chunk_path(nb,T[i].pi,bc);if(!tail_equals_file(pkg,basePkgSize[i],bc)){log_ascii("INSTALL_ERROR: appended tail verification failed");goto rollback;}log_num("Appended chunk at dynamic package EOF=",basePkgSize[i]);}
 if(!atomic_replace_from_file(newManifest,liveManifest)){log_ascii("INSTALL_ERROR: manifest commit failed");goto rollback;}log_ascii("Manifest commit OK.");
 {WCHAR vd[4096];join(vd,4096,gWork,L"verify_manifest.dec");if(!expand_manifest(liveManifest,vd)){log_ascii("INSTALL_ERROR: verify manifest decompression failed");goto rollback;}DWORD vn=0;BYTE*vb=read_all(vd,&vn);DWORD va,vr,vc;if(!vb||!parse_manifest(vb,vn,&va,&vr,&vc)){if(vb)HeapFree(GetProcessHeap(),0,vb);log_ascii("INSTALL_ERROR: verify manifest structure failed");goto rollback;}for(i=0;i<4;i++){DWORD rp=vr+T[i].chunk*16;if(rd32(vb,rp)!=T[i].pi||rd32(vb,rp+4)!=(DWORD)basePkgSize[i]||rd32(vb,rp+8)!=newCS[i]){HeapFree(GetProcessHeap(),0,vb);log_ascii("INSTALL_ERROR: live row redirect mismatch");goto rollback;}WCHAR pkg[4096],z[4096],d[4096],num[32];package_path(T[i].pi,pkg);u32w(T[i].chunk,num,32);join(z,4096,gWork,L"verify_");wcat(z,4096,num);wcat(z,4096,L".zst");join(d,4096,gWork,L"verify_");wcat(d,4096,num);wcat(d,4096,L".dec");BYTE*c=read_range(pkg,rd32(vb,rp+4),rd32(vb,rp+8));if(!c||!write_all(z,c,rd32(vb,rp+8))){if(c)HeapFree(GetProcessHeap(),0,c);HeapFree(GetProcessHeap(),0,vb);log_ascii("INSTALL_ERROR: live chunk read failed");goto rollback;}HeapFree(GetProcessHeap(),0,c);if(!zstd_decompress(z,d)){HeapFree(GetProcessHeap(),0,vb);log_ascii("INSTALL_ERROR: live chunk decompress failed");goto rollback;}DWORD dn=0;BYTE*db=read_all(d,&dn);DWORD abs=T[i].assetOff+T[i].local;if(!db||abs+17>dn||memcmp(db+abs,FR_READY,13)){if(db)HeapFree(GetProcessHeap(),0,db);HeapFree(GetProcessHeap(),0,vb);log_ascii("INSTALL_ERROR: live French Ready verification failed");goto rollback;}int zc=1,j;for(j=13;j<17;j++)if(db[abs+j]!=0)zc=0;if(!zc){HeapFree(GetProcessHeap(),0,db);HeapFree(GetProcessHeap(),0,vb);log_ascii("INSTALL_ERROR: French Ready null padding verification failed");goto rollback;}HeapFree(GetProcessHeap(),0,db);}HeapFree(GetProcessHeap(),0,vb);}
 HeapFree(GetProcessHeap(),0,mb);log_ascii("CHECKPOINT 07: LIVE_VERIFY_OK");log_ascii("INSTALL_OK: 4 packed Ready assets patched and verified in live data. Calibration No and RATIONS untouched.");return 1;
rollback:
 log_ascii("ROLLBACK: native rollback starting.");if(dir_exists(nb)){if(restore_backup_dir(nb,0)){log_ascii("ROLLBACK_OK");}else log_ascii("ROLLBACK_ERROR: automatic restore did not fully verify; backup was preserved.");}goto fail;
rollback_backup: remove_simple_dir(nb);
fail: if(mb)HeapFree(GetProcessHeap(),0,mb);return 0;
}

static int do_restore(void){log_ascii("LONE ECHO II - READY FIX FOR PUBLIC V0.9.0 - R4");log_ascii("MODE: RESTORE EXACT PRE-R4 BASELINE");WCHAR b[4096];join(b,4096,gGame,NATIVE_BACKUP_REL);if(!dir_exists(b)){log_ascii("RESTORE_FATAL: R4 backup not found.");return 0;}if(!restore_backup_dir(b,0))return 0;log_ascii("RESTORE_OK: exact pre-R4 manifest and package sizes restored.");return 1;}

static int parse_args(int* restore){LPWSTR c=GetCommandLineW();*restore=0;gGame[0]=0;gReportRoot[0]=0;while(*c){while(*c==L' ')c++;if(!*c)break;WCHAR tok[4096];int k=0,q=0;if(*c==L'\"'){q=1;c++;}while(*c&&((q&&*c!=L'\"')||(!q&&*c!=L' '))&&k<32767)tok[k++]=*c++;tok[k]=0;if(q&&*c==L'\"')c++;if(weq(tok,L"--restore")){*restore=1;continue;}if(weq(tok,L"--game")){while(*c==L' ')c++;k=0;q=0;if(*c==L'\"'){q=1;c++;}while(*c&&((q&&*c!=L'\"')||(!q&&*c!=L' '))&&k<32767)gGame[k++]=*c++;gGame[k]=0;if(q&&*c==L'\"')c++;continue;}if(weq(tok,L"--report-root")){while(*c==L' ')c++;k=0;q=0;if(*c==L'\"'){q=1;c++;}while(*c&&((q&&*c!=L'\"')||(!q&&*c!=L' '))&&k<32767)gReportRoot[k++]=*c++;gReportRoot[k]=0;if(q&&*c==L'\"')c++;continue;}}
 return gGame[0]&&gReportRoot[0];}

int WINAPI WinMainCRTStartup(void){int restore=0;WCHAR exe[4096],tmp[4096],pid[32];GetModuleFileNameW(NULL,exe,4096);wcopy(gExeDir,4096,exe);parent(gExeDir);join(gZstd,4096,gExeDir,L"zstd.exe");if(!parse_args(&restore))ExitProcess(2);ensure_dir(gReportRoot);join(gReport,4096,gReportRoot,L"Rapport_LoneEcho2_FR_ReadyFix_V0.9.0_R4.txt");DeleteFileW(gReport);log_ascii("CHECKPOINT 01: ENGINE_STARTED");GetTempPathW(4096,tmp);wcopy(gWork,4096,tmp);wcat(gWork,4096,L"LE2FR_V090_READY_R4_");u32w(GetCurrentProcessId(),pid,32);wcat(gWork,4096,pid);ensure_dir(gWork);if(!file_exists(gZstd)){log_ascii("FATAL: zstd.exe missing from native payload");ExitProcess(3);}log_ascii("CHECKPOINT 02: BEFORE_OPERATION");int ok=restore?do_restore():do_install();ExitProcess(ok?0:1);return 0;}
